<?php

/*
 *  ______   _____    ______  __   __  ______
 * /  ___/  /  ___|  / ___  \ \ \ / / |  ____|
 * | |___  | |      | |___| |  \ / /  | |____
 * \___  \ | |      |  ___  |   / /   |  ____|
 *  ___| | | |____  | |   | |  / / \  | |____
 * /_____/  \_____| |_|   |_| /_/ \_\ |______|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author Sunch233#3226 QQ2125696621 And KKK
 * @link https://github.com/ScaxeTeam/Scaxe/
 *
*/

namespace pocketmine\block;

use pocketmine\item\Item;

class UnpoweredComparator extends PoweredComparator{
    protected $id = self::UNPOWERED_COMPARATOR;

    public function getName() : string{
        return "Redstone Comparator";
    }

    public function getStrength(){
        return 0;
    }

    public function isActivated(Block $from = null){
        return false;
    }

    public function onBreak(Item $item){
        $this->getLevel()->setBlock($this, new Air(), true);
    }
}
