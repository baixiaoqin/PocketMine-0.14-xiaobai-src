<?php

/*
 *  ______   _____    ______  __   __  ______
 * /  ___/  /  ___|  / ___  \ \ \ / / |  ____|
 * | |___  | |      | |___| |  \ / /  | |____
 * \___  \ | |      |  ___  |   / /   |  ____|
 *  ___| | | |____  | |   | |  / / \  | |____
 * /_____/  \_____| |_|   |_| /_/ \_\ |______|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author Sunch233#3226 QQ2125696621 And KKK
 * @link https://github.com/ScaxeTeam/Scaxe/
 *
*/

namespace pocketmine\block;

use pocketmine\item\Item;
use pocketmine\level\Level;
use pocketmine\level\sound\ButtonClickSound;
use pocketmine\math\Vector3;
use pocketmine\Player;

class Lever extends RedstoneSource{
	protected $id = self::LEVER;

	public function __construct($meta = 0){
		$this->meta = $meta;
	}

	public function canBeActivated() : bool {
		return true;
	}

	public function getName() : string{
		return "Lever";
	}

	public function onUpdate($type){
		if($type === Level::BLOCK_UPDATE_NORMAL){
			$side = $this->getDamage();
			if($this->isActivated()) $side ^= 0x08;
			$faces = [
				5 => 0,
				6 => 0,
				3 => 2,
				1 => 4,
				4 => 3,
				2 => 5,
				0 => 1,
				7 => 1,
			];

			$block = $this->getSide($faces[$side]);
			if($block->isTransparent()){
				$this->getLevel()->useBreakOn($this);

				return Level::BLOCK_UPDATE_NORMAL;
			}
		}
		return false;
	}

	public function place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null){
		if($target->isTransparent() === false){
			$faces = [
				3 => 3,
				2 => 4,
				4 => 2,
				5 => 1,
			];
			if($face === 0){
				$to = $player instanceof Player ? $player->getDirection() : 0;
				$this->meta = ($to % 2 != 1 ? 0 : 7);
			}elseif($face === 1){
				$to = $player instanceof Player ? $player->getDirection() : 0;
				$this->meta = ($to % 2 != 1 ? 6 : 5);
			}else{
				$this->meta = $faces[$face];
			}
			$this->getLevel()->setBlock($block, $this, true, false);
			return true;
		}
		return false;
	}

	public function activate(array $ignore = []){
		parent::activate($ignore);
		$side = $this->meta;
		if($this->isActivated()) $side ^= 0x08;
		$faces = [
				5 => 0,
				6 => 0,
				3 => 2,
				1 => 4,
				4 => 3,
				2 => 5,
				0 => 1,
				7 => 1,
		];

		$attachedFace = $faces[$side];
		$attachedBlock = $this->getSide($attachedFace);
		
		// 原逻辑：向上方方块传播信号
		$block = $attachedBlock->getSide(Vector3::SIDE_UP);
		if(!$this->equals($block)){
			$this->activateBlock($block);
		}

		// 原逻辑：向背面传播信号
		if($side != 1){
			$block = $this->getSide($attachedFace, 2);
			$this->activateBlock($block);
		}

		// 新逻辑：向附着方块的左边和右边传播信号
		$this->activateSides($attachedBlock, $attachedFace);
		
		// 新增逻辑：向附着方块的下方传播信号
		$downBlock = $attachedBlock->getSide(Vector3::SIDE_DOWN);
		if(!$this->equals($downBlock)){
			$this->activateBlock($downBlock);
		}

		// 新增逻辑：向拉杆本体的上方传播信号
		$upBlock = $this->getSide(Vector3::SIDE_UP);
		if(!$this->equals($upBlock)){
			$this->activateBlock($upBlock);
		}

		$this->checkTorchOn($attachedBlock, [$this->getOppositeSide($attachedFace)]);
	}

	public function deactivate(array $ignore = []){
		parent::deactivate($ignore);
		$side = $this->meta;
		if($this->isActivated()) $side ^= 0x08;
		$faces = [
				5 => 0,
				6 => 0,
				3 => 2,
				1 => 4,
				4 => 3,
				2 => 5,
				0 => 1,
				7 => 1,
		];

		$attachedFace = $faces[$side];
		$attachedBlock = $this->getSide($attachedFace);
		
		// 原逻辑：向上方方块传播信号
		$block = $attachedBlock->getSide(Vector3::SIDE_UP);
		if(!$this->equals($block)){
			$this->deactivateBlock($block);
		}

		// 原逻辑：向背面传播信号
		if($side != 1){
			$this->deactivateBlock($this->getSide($attachedFace, 2));
		}

		// 新逻辑：向附着方块的左边和右边传播信号
		$this->deactivateSides($attachedBlock, $attachedFace);
		
		// 新增逻辑：向附着方块的下方传播信号
		$downBlock = $attachedBlock->getSide(Vector3::SIDE_DOWN);
		if(!$this->equals($downBlock)){
			$this->deactivateBlock($downBlock);
		}

		// 新增逻辑：向拉杆本体的上方传播信号
		$upBlock = $this->getSide(Vector3::SIDE_UP);
		if(!$this->equals($upBlock)){
			$this->deactivateBlock($upBlock);
		}

		$this->checkTorchOff($attachedBlock, [$this->getOppositeSide($attachedFace)]);
	}

	/**
	 * 激活附着方块的左边和右边的方块
	 */
	private function activateSides(Block $attachedBlock, int $attachedFace){
		// 根据附着面确定左右方向
		$leftRightFaces = $this->getLeftRightFaces($attachedFace);
		
		// 激活左边方块
		$leftBlock = $attachedBlock->getSide($leftRightFaces['left']);
		$this->activateBlock($leftBlock);
		
		// 激活右边方块
		$rightBlock = $attachedBlock->getSide($leftRightFaces['right']);
		$this->activateBlock($rightBlock);
	}

	/**
	 * 失活附着方块的左边和右边的方块
	 */
	private function deactivateSides(Block $attachedBlock, int $attachedFace){
		// 根据附着面确定左右方向
		$leftRightFaces = $this->getLeftRightFaces($attachedFace);
		
		// 失活左边方块
		$leftBlock = $attachedBlock->getSide($leftRightFaces['left']);
		$this->deactivateBlock($leftBlock);
		
		// 失活右边方块
		$rightBlock = $attachedBlock->getSide($leftRightFaces['right']);
		$this->deactivateBlock($rightBlock);
	}

	/**
	 * 根据附着面获取左右方向
	 */
	private function getLeftRightFaces(int $attachedFace): array{
		// 定义各个面的左右方向映射
		$leftRightMap = [
			// 下面 (0) -> 上面 (1) 的左右
			0 => ['left' => Vector3::SIDE_EAST, 'right' => Vector3::SIDE_WEST],
			1 => ['left' => Vector3::SIDE_WEST, 'right' => Vector3::SIDE_EAST],
			
			// 北面 (2) -> 南面 (3) 的左右
			2 => ['left' => Vector3::SIDE_WEST, 'right' => Vector3::SIDE_EAST],
			3 => ['left' => Vector3::SIDE_EAST, 'right' => Vector3::SIDE_WEST],
			
			// 西面 (4) -> 东面 (5) 的左右
			4 => ['left' => Vector3::SIDE_NORTH, 'right' => Vector3::SIDE_SOUTH],
			5 => ['left' => Vector3::SIDE_SOUTH, 'right' => Vector3::SIDE_NORTH],
		];
		
		return $leftRightMap[$attachedFace] ?? ['left' => Vector3::SIDE_WEST, 'right' => Vector3::SIDE_EAST];
	}

	public function onActivate(Item $item, Player $player = null){
		$this->meta ^= 0x08;
		$this->getLevel()->setBlock($this, $this, true, false);
		
		if($this->isActivated()) {
			// 点下去时使用高音
			$this->getLevel()->addSound(new ButtonClickSound($this, 0.6));
			$this->activate();
		} else {
			// 恢复时使用原音高（0.5）
			$this->getLevel()->addSound(new ButtonClickSound($this, 0.5));
			$this->deactivate();
		}
		return true;
	}

	public function onBreak(Item $item){
		if($this->isActivated()){
			$this->meta ^= 0x08;
			$this->getLevel()->setBlock($this, $this, true, false);
			$this->deactivate();
		}
		$this->getLevel()->setBlock($this, new Air(), true, false);
	}

	public function isActivated(Block $from = null){
		return (($this->meta & 0x08) === 0x08);
	}

	public function getHardness() {
		return 0.5;
	}

	public function getResistance(){
		return 2.5;
	}

	public function getDrops(Item $item) : array {
		return [
			[$this->id, 0 ,1],
		];
	}
}
