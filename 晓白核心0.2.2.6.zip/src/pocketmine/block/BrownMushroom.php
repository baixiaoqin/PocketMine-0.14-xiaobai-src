<?php

namespace pocketmine\block;

use pocketmine\item\Item;
use pocketmine\level\Level;
use pocketmine\level\generator\object\BrownMushroom as HugeBrownMushroom;
use pocketmine\Player;
use pocketmine\utils\Random;

class BrownMushroom extends Flowable{

	protected $id = self::BROWN_MUSHROOM;

	public function __construct($meta = 0){
		$this->meta = $meta;
	}

	public function getName() : string{
		return "Brown Mushroom";
	}

	public function getLightLevel(){
		return 1;
	}

	public function canBeActivated() : bool {
		return true;
	}

	public function onUpdate($type){
		if($type === Level::BLOCK_UPDATE_NORMAL){
			if($this->getSide(0)->isTransparent() === true){
				$this->getLevel()->useBreakOn($this);
				return Level::BLOCK_UPDATE_NORMAL;
			}
		}
		// 移除随机生长逻辑，蘑菇不再自然生长
		return false;
	}

	public function onActivate(Item $item, Player $player = null){
		if($item->getId() === Item::DYE and $item->getDamage() === 0x0F){ // Bonemeal
			// 40% 几率成功催熟
			if(mt_rand(1, 100) <= 40 && $this->grow()){
				if(($player->gamemode & 0x01) === 0){
					$item->count--;
				}
				return true;
			}
		}
		return false;
	}

	/**
	 * 尝试生长为巨型蘑菇
	 * @return bool 是否成功生成
	 */
	private function grow(): bool{
		$level = $this->getLevel();
		$x = $this->x;
		$y = $this->y;
		$z = $this->z;

		$random = new Random(mt_rand());
		$huge = new HugeBrownMushroom();
		if($huge->canPlaceObject($level, $x, $y, $z, $random)){
			// 临时移除当前蘑菇方块
			$level->setBlock($this, new Air(), false, false);
			// 放置巨型蘑菇结构
			$huge->placeObject($level, $x, $y, $z, $random);
			$level->updateAround($this);
			return true;
		}
		return false;
	}

	public function place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null){
		$down = $this->getSide(0);
		if($down->isTransparent() === false){
			$this->getLevel()->setBlock($block, $this, true, true);
			return true;
		}
		return false;
	}

	public function getBoundingBox(){
		return null;
	}

	public function getDrops(Item $item) : array{
		return [
			[$this->id, $this->meta & 0x07, 1],
		];
	}
}