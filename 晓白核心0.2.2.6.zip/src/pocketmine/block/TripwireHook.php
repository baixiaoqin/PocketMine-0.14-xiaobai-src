<?php

/*
 *  ______   _____    ______  __   __  ______
 * /  ___/  /  ___|  / ___  \ \ \ / / |  ____|
 * | |___  | |      | |___| |  \ / /  | |____
 * \___  \ | |      |  ___  |   / /   |  ____|
 *  ___| | | |____  | |   | |  / / \  | |____
 * /_____/  \_____| |_|   |_| /_/ \_\ |______|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author Sunch233#3226 QQ2125696621 And KKK
 * @link https://github.com/ScaxeTeam/Scaxe/
 *
*/

namespace pocketmine\block;

use pocketmine\item\Item;
use pocketmine\item\Tool;
use pocketmine\Player;

class TripwireHook extends Solid {

    protected $id = self::TRIPWIRE_HOOK;

    public function __construct($meta = 0){
        $this->meta = $meta;
    }

    public function getName() : string {
        return "Tripwire Hook";
    }

    public function getHardness() {
        return 0;
    }

    public function getResistance(){
        return 0;
    }
    
    public function getToolType(){
        return Tool::TYPE_SHEARS;
    }

    public function place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null){
        // 绊线钩方向：面向玩家的反方向
        $faces = [
            0 => 1, // 
            1 => 2, // 
            2 => 3, // 
            3 => 0, // 
        ];
        
        // 设置绊线钩的方向（只使用低2位存储方向信息）
        $this->meta = $faces[$player instanceof Player ? $player->getDirection() : 0] & 0x03;
        $this->getLevel()->setBlock($block, $this, true, true);

        return true;
    }

    public function getDrops(Item $item) : array {
        return [
            [Item::TRIPWIRE_HOOK, 0, 1],
        ];
    }
}
