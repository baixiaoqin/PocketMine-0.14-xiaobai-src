<?php

/*
 *  ______   _____    ______  __   __  ______
 * /  ___/  /  ___|  / ___  \ \ \ / / |  ____|
 * | |___  | |      | |___| |  \ / /  | |____
 * \___  \ | |      |  ___  |   / /   |  ____|
 *  ___| | | |____  | |   | |  / / \  | |____
 * /_____/  \_____| |_|   |_| /_/ \_\ |______|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author Sunch233#3226 QQ2125696621 And KKK
 * @link https://github.com/ScaxeTeam/Scaxe/
 *
*/

namespace pocketmine\block;

use pocketmine\item\Item;
use pocketmine\item\Tool;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\tile\Tile;
use pocketmine\tile\MobSpawner;
use pocketmine\Player;

class MonsterSpawner extends Solid{

	protected $id = self::MONSTER_SPAWNER;

	public function __construct($meta = 0){
		$this->meta = $meta;
	}

	public function getHardness() {
		return 5;
	}

	public function getToolType(){
		return Tool::TYPE_PICKAXE;
	}

	public function getName() : string{
		return "Monster Spawner";
	}

	public function canBeActivated() : bool {
		return true;
	}

	public function onActivate(Item $item, Player $player = null){
		if($this->getDamage() == 0){
			if($item->getId() == Item::SPAWN_EGG){
				$tile = $this->getLevel()->getTile($this);
				
				// 如果Tile不存在，先创建Tile
				if(!($tile instanceof MobSpawner)){
					$nbt = new CompoundTag("", [
						new StringTag("id", Tile::MOB_SPAWNER),
						new IntTag("x", $this->x),
						new IntTag("y", $this->y),
						new IntTag("z", $this->z),
						new IntTag("EntityId", $item->getDamage()),
					]);
					
					$tile = Tile::createTile(Tile::MOB_SPAWNER, $this->getLevel()->getChunk($this->x >> 4, $this->z >> 4), $nbt);
				}
				
				if($tile instanceof MobSpawner){
					$this->meta = $item->getDamage();
					$tile->setEntityId($this->meta);
				}
				return true;
			}
		}
		return false;
	}

	public function place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null){
		$this->getLevel()->setBlock($block, $this, true, true);
		
		// 只在有自定义方块数据时才创建Tile（表示有预设的生物类型）
		if($item->hasCustomBlockData()){
			$nbt = new CompoundTag("", [
				new StringTag("id", Tile::MOB_SPAWNER),
				new IntTag("x", $block->x),
				new IntTag("y", $block->y),
				new IntTag("z", $block->z),
				new IntTag("EntityId", 0),
			]);
			
			foreach($item->getCustomBlockData() as $key => $v){
				$nbt->{$key} = $v;
			}
			
			Tile::createTile(Tile::MOB_SPAWNER, $this->getLevel()->getChunk($this->x >> 4, $this->z >> 4), $nbt);
		}
		// 如果没有自定义数据，不创建Tile，避免空刷怪笼产生粒子
		
		return true;
	}

	public function getDrops(Item $item) : array {
		return [];
	}
    
    /**
     * 当方块被破坏时的处理
     */
    public function onBreak(Item $item, Player $player = null) : bool{
        $tile = $this->getLevel()->getTile($this);
        // 如果存在Tile，先移除Tile
        if($tile instanceof MobSpawner){
            $tile->close();
        }
        return parent::onBreak($item, $player);
    }
}
