<?php

namespace pocketmine\block;

use pocketmine\entity\Entity;
use pocketmine\item\Item;
use pocketmine\math\Math;
use pocketmine\math\Vector3;
use pocketmine\level\Level;
use pocketmine\level\sound\ButtonClickSound;
use pocketmine\Player;

class PressurePlate extends RedstoneSource{
	protected $activateTime = 0;
	protected $canActivate = true;

	public function __construct($meta = 0){
		$this->meta = $meta;
	}

	public function hasEntityCollision(){
		return true;
	}

	public function onEntityCollide(Entity $entity){
		if($this->getLevel()->getServer()->redstoneEnabled and $this->canActivate){
			if(!$this->isActivated()){
				$this->meta = 1;
				$this->getLevel()->setBlock($this, $this, true, false);
				// 点下去时播放音高0.6的声音
				$this->getLevel()->addSound(new ButtonClickSound($this, 0.6));
			}
			if(!$this->isActivated() or ($this->isActivated() and ($this->getLevel()->getServer()->getTick() % 30) == 0)){
				$this->activate();
			}
		}
	}

	public function isActivated(Block $from = null){
		return ($this->meta == 0) ? false : true;
	}

	public function onUpdate($type){
		if($type === Level::BLOCK_UPDATE_NORMAL){
			$below = $this->getSide(Vector3::SIDE_DOWN);
			if($below instanceof Transparent){
				$this->getLevel()->useBreakOn($this);
				return Level::BLOCK_UPDATE_NORMAL;
			}
		}
		return true;
	}

	public function checkActivation(){
		if($this->isActivated()){
			if((($this->getLevel()->getServer()->getTick() - $this->activateTime)) >= 3){
				$this->meta = 0;
				$this->getLevel()->setBlock($this, $this, true, false);
				// 恢复原音高（0.5）
				$this->getLevel()->addSound(new ButtonClickSound($this, 0.5));
				$this->deactivate();
			}
		}
	}

	public function place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null){
		$below = $this->getSide(Vector3::SIDE_DOWN);
		if($below instanceof Transparent) return;
		else $this->getLevel()->setBlock($block, $this, true, false);
	}

	public function onBreak(Item $item){
		if($this->isActivated()){
			$this->meta = 0;
			$this->deactivate();
		}
		$this->canActivate = false;
		$this->getLevel()->setBlock($this, new Air(), true);
	}

	public function activate(array $ignore = []){
		parent::activate($ignore);
		
		// 压力板的附着面是下方
		$attachedFace = Vector3::SIDE_DOWN;
		$attachedBlock = $this->getSide($attachedFace);
		
		// 向上方方块传播信号
		$block = $this->getSide(Vector3::SIDE_UP);
		if(!$this->equals($block)){
			$this->activateBlock($block);
		}

		// 向压力板本体的四周传播信号
		$this->activateSides($this, Vector3::SIDE_DOWN);
		
		// 向附着方块的左边和右边传播信号
		$this->activateSides($attachedBlock, $attachedFace);
		
		// 向附着方块的下方传播信号
		$downBlock = $attachedBlock->getSide(Vector3::SIDE_DOWN);
		if(!$this->equals($downBlock)){
			$this->activateBlock($downBlock);
		}

		$this->checkTorchOn($attachedBlock, [$this->getOppositeSide($attachedFace)]);
	}

	public function deactivate(array $ignore = []){
		parent::deactivate($ignore);
		
		// 压力板的附着面是下方
		$attachedFace = Vector3::SIDE_DOWN;
		$attachedBlock = $this->getSide($attachedFace);
		
		// 失活上方方块
		$block = $this->getSide(Vector3::SIDE_UP);
		if(!$this->equals($block)){
			$this->deactivateBlock($block);
		}

		// 失活压力板本体的四周
		$this->deactivateSides($this, Vector3::SIDE_DOWN);
		
		// 失活附着方块的左边和右边
		$this->deactivateSides($attachedBlock, $attachedFace);
		
		// 失活附着方块的下方
		$downBlock = $attachedBlock->getSide(Vector3::SIDE_DOWN);
		if(!$this->equals($downBlock)){
			$this->deactivateBlock($downBlock);
		}

		$this->checkTorchOff($attachedBlock, [$this->getOppositeSide($attachedFace)]);
	}

	/**
	 * 激活方块的左边和右边的方块
	 */
	private function activateSides(Block $block, int $attachedFace){
		// 根据附着面确定左右方向
		$leftRightFaces = $this->getLeftRightFaces($attachedFace);
		
		// 激活左边方块
		$leftBlock = $block->getSide($leftRightFaces['left']);
		$this->activateBlock($leftBlock);
		
		// 激活右边方块
		$rightBlock = $block->getSide($leftRightFaces['right']);
		$this->activateBlock($rightBlock);
	}

	/**
	 * 失活方块的左边和右边的方块
	 */
	private function deactivateSides(Block $block, int $attachedFace){
		// 根据附着面确定左右方向
		$leftRightFaces = $this->getLeftRightFaces($attachedFace);
		
		// 失活左边方块
		$leftBlock = $block->getSide($leftRightFaces['left']);
		$this->deactivateBlock($leftBlock);
		
		// 失活右边方块
		$rightBlock = $block->getSide($leftRightFaces['right']);
		$this->deactivateBlock($rightBlock);
	}

	/**
	 * 根据附着面获取左右方向
	 */
	private function getLeftRightFaces(int $attachedFace): array{
		// 定义各个面的左右方向映射
		$leftRightMap = [
			// 下面 (0) -> 上面 (1) 的左右
			0 => ['left' => Vector3::SIDE_EAST, 'right' => Vector3::SIDE_WEST],
			1 => ['left' => Vector3::SIDE_WEST, 'right' => Vector3::SIDE_EAST],
			
			// 北面 (2) -> 南面 (3) 的左右
			2 => ['left' => Vector3::SIDE_WEST, 'right' => Vector3::SIDE_EAST],
			3 => ['left' => Vector3::SIDE_EAST, 'right' => Vector3::SIDE_WEST],
			
			// 西面 (4) -> 东面 (5) 的左右
			4 => ['left' => Vector3::SIDE_NORTH, 'right' => Vector3::SIDE_SOUTH],
			5 => ['left' => Vector3::SIDE_SOUTH, 'right' => Vector3::SIDE_NORTH],
		];
		
		return $leftRightMap[$attachedFace] ?? ['left' => Vector3::SIDE_WEST, 'right' => Vector3::SIDE_EAST];
	}

	public function getHardness() {
		return 0.5;
	}

	public function getResistance(){
		return 2.5;
	}
}
