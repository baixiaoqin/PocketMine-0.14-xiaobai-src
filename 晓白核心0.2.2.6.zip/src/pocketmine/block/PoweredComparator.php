<?php

/*
 *  ______   _____    ______  __   __  ______
 * /  ___/  /  ___|  / ___  \ \ \ / / |  ____|
 * | |___  | |      | |___| |  \ / /  | |____
 * \___  \ | |      |  ___  |   / /   |  ____|
 *  ___| | | |____  | |   | |  / / \  | |____
 * /_____/  \_____| |_|   |_| /_/ \_\ |______|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author Sunch233#3226 QQ2125696621 And KKK
 * @link https://github.com/ScaxeTeam/Scaxe/
 *
*/

namespace pocketmine\block;

use pocketmine\item\Item;
use pocketmine\level\Level;
use pocketmine\level\sound\ButtonClickSound;
use pocketmine\math\Vector3;
use pocketmine\Player;

class PoweredComparator extends RedstoneSource{
    protected $id = self::POWERED_COMPARATOR;

    const ACTION_ACTIVATE = "Comparator Activate";
    const ACTION_DEACTIVATE = "Comparator Deactivate";
    
    // 比较器模式常量
    const MODE_COMPARE = 0;
    const MODE_SUBTRACT = 1;

    public function __construct($meta = 0){
        $this->meta = $meta;
    }

    public function getName() : string{
        return "Powered Redstone Comparator";
    }

    public function canBeActivated() : bool{
        return true;
    }

    public function getStrength(){
        return 15;
    }

    public function getDirection() : int{
        $direction = 0;
        switch($this->meta & 0x03){ // 只取低2位表示方向
            case 0:
                $direction = 3;
                break;
            case 1:
                $direction = 4;
                break;
            case 2:
                $direction = 2;
                break;
            case 3:
                $direction = 5;
                break;
        }
        return $direction;
    }
    
    public function getOppositeDirection() : int{
        return $this->getOppositeSide($this->getDirection());
    }

    /**
     * 获取比较器模式
     * @return int 0=比较模式, 1=减法模式
     */
    public function getMode() : int{
        return ($this->meta & 0x04) >> 2; // 第3位表示模式
    }

    /**
     * 获取侧面输入信号强度
     */
    public function getSideInputStrength() : int{
        $sideDirection = $this->getDirection() - 1; // 左侧
        if($sideDirection < 2) $sideDirection += 4;
        
        $sideBlock = $this->getSide($sideDirection);
        $strength = $this->getWeakPower($sideBlock);
        
        // 检查右侧
        $sideDirection = $this->getDirection() + 1; // 右侧
        if($sideDirection > 5) $sideDirection -= 4;
        
        $sideBlock2 = $this->getSide($sideDirection);
        $strength2 = $this->getWeakPower($sideBlock2);
        
        return max($strength, $strength2);
    }

    /**
     * 获取后端输入信号强度
     */
    public function getBackInputStrength() : int{
        $backBlock = $this->getSide($this->getOppositeDirection());
        return $this->getWeakPower($backBlock);
    }

    public function isActivated(Block $from = null){
        if(!$from instanceof Block){
            return false;
        }
        
        $backStrength = $this->getBackInputStrength();
        $sideStrength = $this->getSideInputStrength();
        
        if($this->getMode() == self::MODE_COMPARE){
            // 比较模式：后端信号 >= 侧面信号时输出
            return $backStrength >= $sideStrength && $backStrength > 0;
        } else {
            // 减法模式：后端信号 - 侧面信号（最小为0）
            $output = max(0, $backStrength - $sideStrength);
            return $output > 0;
        }
    }

    public function activate(array $ignore = []){
        if($this->canCalc()){
            if($this->id != self::POWERED_COMPARATOR){
                $this->id = self::POWERED_COMPARATOR;
                $this->getLevel()->setBlock($this, $this, true, false);
            }
            $this->getLevel()->setBlockTempData($this, self::ACTION_ACTIVATE);
            $this->getLevel()->scheduleUpdate($this, 2); // 固定1红石刻延迟
        }
    }

    public function deactivate(array $ignore = []){
        if($this->canCalc()){
            if($this->id != self::UNPOWERED_COMPARATOR){
                $this->id = self::UNPOWERED_COMPARATOR;
                $this->getLevel()->setBlock($this, $this, true, false);
            }
            $this->getLevel()->setBlockTempData($this, self::ACTION_DEACTIVATE);
            $this->getLevel()->scheduleUpdate($this, 2);
        }
    }

    public function deactivateImmediately(){
        $this->deactivateBlock($this->getSide($this->getOppositeDirection()));
        $this->deactivateBlock($this->getSide(Vector3::SIDE_DOWN, 2));
    }

    public function onUpdate($type){
        if($type == Level::BLOCK_UPDATE_SCHEDULED){
            if($this->getLevel()->getBlockTempData($this) == self::ACTION_ACTIVATE){
                $this->activateBlock($this->getSide($this->getOppositeDirection()));
                $this->activateBlock($this->getSide(Vector3::SIDE_DOWN, 2));
            }elseif($this->getLevel()->getBlockTempData($this) == self::ACTION_DEACTIVATE){
                $this->deactivateImmediately();
            }
            $this->getLevel()->setBlockTempData($this);
        }
        return $type;
    }

    public function onActivate(Item $item, Player $player = null){
        // 切换比较器模式（切换第3位）
        $this->meta ^= 0x04;
        $this->getLevel()->setBlock($this, $this, true, false);
        
        // 播放模式切换声音
        $pitch = $this->getMode() == self::MODE_COMPARE ? 0.5 : 0.55;
        $this->getLevel()->addSound(new ButtonClickSound($this, $pitch));
        
        // 重新计算红石信号
        if($this->isActivated()){
            $this->activate();
        } else {
            $this->deactivate();
        }
        
        return true;
    }

    public function place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null){
        if($player instanceof Player){
            $this->meta = ((int) $player->getDirection() + 5) % 4;
        }
        $this->getLevel()->setBlock($block, $this, true, false);
        
        // 检查是否需要激活
        $backStrength = $this->getBackInputStrength();
        $sideStrength = $this->getSideInputStrength();
        
        if($this->getMode() == self::MODE_COMPARE){
            if($backStrength >= $sideStrength && $backStrength > 0){
                $this->activate();
            }
        } else {
            if(max(0, $backStrength - $sideStrength) > 0){
                $this->activate();
            }
        }
    }

    public function onBreak(Item $item){
        $this->deactivateImmediately();
        $this->getLevel()->setBlock($this, new Air(), true, false);
        $this->getLevel()->setBlockTempData($this);
    }

    public function getDrops(Item $item) : array{
        return [
            [Item::COMPARATOR, 0, 1]
        ];
    }
}
