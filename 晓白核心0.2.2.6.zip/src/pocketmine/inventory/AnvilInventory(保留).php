<?php

/*
 *  ______   _____    ______  __   __  ______
 * /  ___/  /  ___|  / ___  \ \ \ / / |  ____|
 * | |___  | |      | |___| |  \ / /  | |____
 * \___  \ | |      |  ___  |   / /   |  ____|
 *  ___| | | |____  | |   | |  / / \  | |____
 * /_____/  \_____| |_|   |_| /_/ \_\ |______|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author Sunch233#3226 QQ2125696621 And KKK
 * @link https://github.com/ScaxeTeam/Scaxe/
 * 修复工具还未完善
 */

namespace pocketmine\inventory;

use pocketmine\level\Position;
use pocketmine\Player;
use pocketmine\item\Item;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\block\Block;
use pocketmine\block\Anvil as AnvilBlock;
use pocketmine\item\EnchantedBook;
use pocketmine\event\inventory\AnvilProcessEvent;
use pocketmine\Server;

class AnvilInventory extends ContainerInventory{
    
    const TARGET = 0;
    const SACRIFICE = 1;
    const RESULT = 2;
    private $Customitem;
    
    protected $wordsBanned = ["服务器","axe","生存斧","傻逼","端口","19132","19133","scf"];
    
    // 可修复物品的最大耐久度映射（0表示满耐久，数值越大表示损坏越严重）
    private $maxDurability = [
        // 木制工具 (ID: 268-271, 290)
        268 => 59,   // 木剑
        269 => 59,   // 木锹锹
        270 => 59,   // 木镐镐
        271 => 59,   // 木斧
        290 => 59,   // 木锄
        
        // 石制工具 (ID: 272-275, 291)
        272 => 131,  // 石剑
        273 => 131,  // 石锹锹
        274 => 131,  // 石镐镐
        275 => 131,  // 石斧
        291 => 131,  // 石锄
        
        // 铁制工具 (ID: 256-258, 267, 292)
        256 => 250,  // 铁锹锹
        257 => 250,  // 铁镐镐
        258 => 250,  // 铁斧
        267 => 250,  // 铁剑
        292 => 250,  // 铁锄
        
        // 钻石工具 (ID: 276-279, 293)
        276 => 1561, // 钻石剑
        277 => 1561, // 钻石锹锹
        278 => 1561, // 钻石镐镐
        279 => 1561, // 钻石斧
        293 => 1561, // 钻石锄
        
        // 金制工具 (ID: 283-286, 294)
        283 => 32,   // 金剑
        284 => 32,   // 金锹锹
        285 => 32,   // 金镐镐
        286 => 32,   // 金斧
        294 => 32,   // 金锄
        
        // 其他工具
        259 => 64,   // 打火石
        261 => 384,  // 弓
        346 => 384,  // 钓鱼竿
        359 => 238,  // 剪刀
        
        // 皮革盔甲 (ID: 298-301)
        298 => 55,   // 皮革帽子
        299 => 80,   // 皮革上衣
        300 => 75,   // 皮革裤子
        301 => 65,   // 皮革靴子
        
        // 金盔甲 (ID: 314-317)
        314 => 77,   // 金头盔
        315 => 112,  // 金胸甲
        316 => 105,  // 金护腿
        317 => 91,   // 金靴子
        
        // 铁/链甲 (ID: 302-309)
        302 => 165,  // 链甲头盔
        303 => 240,  // 链甲胸甲
        304 => 225,  // 链甲护腿
        305 => 195,  // 链甲靴子
        306 => 165,  // 铁头盔
        307 => 240,  // 铁胸甲
        308 => 225,  // 铁护腿
        309 => 195,  // 铁靴子
        
        // 钻石盔甲 (ID: 310-313)
        310 => 363,  // 钻石头盔
        311 => 528,  // 钻石胸甲
        312 => 495,  // 钻石护腿
        313 => 429,  // 钻石靴子
    ];
    
    // 修复材料映射：原材料ID => 可修复的物品ID数组
    private $repairMaterials = [
        // 木材/木板修复木制工具
        5 => [268, 269, 270, 271, 290, 291, 292, 293, 294], // 木板
        280 => [268, 269, 270, 271, 290, 291, 292, 293, 294], // 木棍
        
        // 圆石修复石制工具
        4 => [272, 273, 274, 275, 291], // 圆石
        
        // 铁锭修复铁制工具、盔甲和链甲
        265 => [256, 257, 258, 267, 292, 306, 307, 308, 309, 302, 303, 304, 305], // 铁锭
        
        // 金锭修复金制工具和盔甲
        266 => [283, 284, 285, 286, 294, 314, 315, 316, 317], // 金锭
        
        // 钻石修复钻石工具和盔甲
        264 => [276, 277, 278, 279, 293, 310, 311, 312, 313], // 钻石
        
        // 皮革修复皮革盔甲
        334 => [298, 299, 300, 301], // 皮革
    ];
    
    public function __construct(Position $pos){
        parent::__construct(new FakeBlockMenu($this, $pos), InventoryType::get(InventoryType::ANVIL));
    }

    /**
     * @return FakeBlockMenu
     */
    public function getHolder(){
        return $this->holder;
    }
    
    
    public function getResultSlotIndex(){
        return self::RESULT;
    }
    
    public function finishRename(Player $player, $type){
        if(!isset($this->Customitem)){
            return;
        }
        if($this->Customitem->hasCustomName()){
            if($this->hasBannedWord($this->Customitem->getCustomName())){
                $player->getServer()->getLogger()->notice($player->getName()."在改名时触发违禁词：".$this->Customitem->getCustomName());
                $item = $this->Customitem->setCustomName("§c检测到违禁词");
                $player->sendMessage("§c改名期间检测到违禁词");
                $this->Customitem = $item;
            }
            if($this->have_emoji($this->Customitem->getCustomName())){
                $item = $this->Customitem->setCustomName("§c不允许emoji");
            }
        }
        
        $targetItem = $this->getItem(self::TARGET);
        $sacrificeItem = $this->getItem(self::SACRIFICE);
        
        // 检查是否是附魔书操作
        if($sacrificeItem instanceof EnchantedBook && $sacrificeItem->hasEnchantments()){
            $this->processEnchanting($player, $targetItem, $sacrificeItem);
            return;
        }
        
        // 原有的经验扣除逻辑
        $level = $player->getExpLevel();
        $count = 1; // 基础经验消耗
        if($level < $count){
            return false;
        }
        $le = $level - $count;
        $player->setExpLevel($le);
        $this->clearAll();
        $player->getInventory()->addItem($this->Customitem);
        
        /*********************** 修改点：铁砧砧使用受损机制与音效控制 ***********************/
        // 应用铁砧砧受损逻辑，并获取是否破碎的状态
        $isAnvilDestroyed = $this->applyAnvilDamage($player);
        
        // 只有当铁砧砧没有因为本次操作而破碎时，才播放"使用"音效
        if (!$isAnvilDestroyed) {
            $player->getLevel()->addSound(new AnvilUseSound($player));
        }
        // 如果铁砧砧破碎了，Anvil.php中的onBreak方法已经播放了AnvilBreakSound，此处不再播放AnvilUseSound。
        /*******************************************************************/
        
        $this->Customitem = null;
    }
    
    /**
     * 处理附魔书附魔操作
     */
    private function processEnchanting(Player $player, Item $target, Item $sacrifice){
        $resultItem = clone $target;
        
        // 调用附魔处理事件
        Server::getInstance()->getPluginManager()->callEvent($ev = new AnvilProcessEvent($this));
        if($ev->isCancelled()){
            $this->clearAll();
            return false;
        }
        
        if($sacrifice instanceof EnchantedBook && $sacrifice->hasEnchantments()){
            // 附魔书：将附魔添加到目标物品
            foreach($sacrifice->getEnchantments() as $enchant){
                $resultItem->addEnchantment($enchant);
            }

            // 检查经验是否足够 - 修复：使用自定义的计算方法而不是getRepairCost()
            $repairCost = $this->calculateRepairCost($resultItem);
            if($player->getExpLevel() < $repairCost){
                return false;
            }
            
            // 扣除经验
            $player->setExpLevel($player->getExpLevel() - $repairCost);

            $this->clearAll();
            if(!$player->getServer()->allowInventoryCheats and !$player->isCreative()){
                if(!$player->getInventory()->canAddItem($resultItem)){
                    return false;
                }
                $player->getInventory()->addItem($resultItem);
            }
            
            // 应用铁砧受损逻辑
            $isAnvilDestroyed = $this->applyAnvilDamage($player);
            if (!$isAnvilDestroyed) {
                $player->getLevel()->addSound(new AnvilUseSound($player));
            }
            
            return true;
        }
        
        return false;
    }
    
    /**
     * 计算修复/附魔成本（自定义实现，避免使用不存在的getRepairCost方法）
     */
    private function calculateRepairCost(Item $item){
        $cost = 0;
        
        // 基础成本
        $cost += 1;
        
        // 如果物品有附魔，增加成本
        if($item->hasEnchantments()){
            $enchantments = $item->getEnchantments();
            $cost += count($enchantments) * 2;
            
            // 高等级附魔增加更多成本
            foreach($enchantments as $enchant){
                $level = $enchant->getLevel();
                if($level > 1){
                    $cost += $level - 1;
                }
            }
        }
        
        // 如果物品有损坏，增加成本
        if($item->getDamage() > 0){
            $maxDurability = $this->getMaxDurability($item);
            if($maxDurability > 0){
                $damagePercent = $item->getDamage() / $maxDurability;
                $cost += ceil($damagePercent * 5);
            }
        }
        
        // 如果物品有自定义名称，增加成本
        if($item->hasCustomName()){
            $cost += 1;
        }
        
        return max(1, $cost); // 最少1级经验
    }
    
    /**
     * 应用铁砧砧使用受损机制。
     * 每当玩家成功完成一次铁砧砧操作（修复或重命名），铁砧砧有概率受损。
     * 受损状态：正常(0) -> 轻微受损(4) -> 严重受损(8) -> 破碎消失。
     * 概率参考原版设定，约为12%。
     * @param Player $player 操作铁砧砧的玩家
     * @return bool 返回true表示铁砧砧已因本次操作而破碎消失；false表示未破碎或未受损。
     */
    private function applyAnvilDamage(Player $player) {
        // 1. 获取当前铁砧砧方块
        $holderPos = $this->getHolder();
        if (!$holderPos instanceof Position) {
            return false;
        }
        $block = $player->getLevel()->getBlock($holderPos);
        if (!($block instanceof AnvilBlock)) {
            return false; // 所在位置不是铁砧砧方块，不应该发生，安全处理。
        }
        
        // 2. 决定是否受损（约12%概率，即约每8.3次操作受损一次）
        // mt_rand(1, 100) 生成1到100的整数，小于等于12时触发受损
        if (mt_rand(1, 100) > 12) {
            return false; // 本次使用未受损
        }
        
        // 3. 获取当前受损状态 (meta值的高4位代表受损状态，见Anvil.php)
        $currentDamageState = $block->getDamage() & 0x0c; // 使用掩码0x0c获取受损位
        
        // 4. 根据当前状态决定下一步
        switch ($currentDamageState) {
            case AnvilBlock::NORMAL: // 正常 -> 变为轻微受损
                $newDamageState = AnvilBlock::SLIGHTLY_DAMAGED;
                $player->getLevel()->setBlock($block, Block::get(Block::ANVIL, $newDamageState | ($block->getDamage() & 0x03)), true, true); // 保留方向位(低2位)
                // 可以在这里添加一个"铁砧砧受损"的音效或粒子效果以提供视觉/听觉反馈（如果服务器有相关资源）
                $player->getLevel()->addSound(new AnvilUseSound($block)); // 复用使用音效或寻找受损音效
                return false; // 未破碎
                
            case AnvilBlock::SLIGHTLY_DAMAGED: // 轻微受损 -> 变为严重受损
                $newDamageState = AnvilBlock::VERY_DAMAGED;
                $player->getLevel()->setBlock($block, Block::get(Block::ANVIL, $newDamageState | ($block->getDamage() & 0x03)), true, true);
                return false; // 未破碎
                
            case AnvilBlock::VERY_DAMAGED: // 严重受损 -> 破碎消失
            default: // 理论上不会进入default，但安全处理
                // 破碎：破坏方块，播放破碎音效，并掉落一个严重受损的铁砧砧物品（或根据原版逻辑无掉落）。
                // 调用方块的onBreak方法可以确保触发正确的破坏逻辑和音效。
                $block->onBreak(Item::get(Item::AIR)); // 使用空气作为"破坏工具"
                // onBreak方法会处理掉落物和音效。根据Anvil.php的getDrops方法，只有用镐镐挖掘才会掉落铁砧砧自身。
                // 因此，因使用而破碎时，将不会掉落任何铁砧砧物品，模拟原版行为。
                return true; // 已破碎
        }
    }
    
    /**
     * 检查物品是否可以被修复
     */
    private function canBeRepaired(Item $item){
        $id = $item->getId();
        return isset($this->maxDurability[$id]);
    }
    
    /**
     * 获取物品的最大耐久度
     */
    private function getMaxDurability(Item $item){
        $id = $item->getId();
        if(isset($this->maxDurability[$id])){
            return $this->maxDurability[$id];
        }
        return 0; // 不可修复的物品
    }
    
    /**
     * 检查牺牲物品是否是目标物品的修复材料
     */
    private function isRepairMaterial(Item $target, Item $sacrifice){
        $targetId = $target->getId();
        $sacrificeId = $sacrifice->getId();
        
        // 1. 同类物品可以合并修复
        if($targetId == $sacrificeId){
            return true;
        }
        
        // 2. 链甲可以用铁锭修复
        if(($targetId >= 302 && $targetId <= 305) && $sacrificeId == 265){
            return true;
        }
        
        // 3. 检查修复材料映射表
        if(isset($this->repairMaterials[$sacrificeId])){
            return in_array($targetId, $this->repairMaterials[$sacrificeId]);
        }
        
        return false;
    }
    
    /**
     * 计算原材料修复的耐久度恢复值
     * 每个原材料修复最大耐久的25%（向下取整）
     */
    private function calculateMaterialRepairAmount(Item $target){
        $maxDurability = $this->getMaxDurability($target);
        return floor($maxDurability * 0.25);
    }
    
    /**
     * 计算合并修复的耐久度恢复值
     * 公式：目标剩余耐久 + 牺牲剩余耐久 + 修复加成(最大耐久×12%)
     */
    private function calculateMergeRepairAmount(Item $target, Item $sacrifice){
        $maxDurability = $this->getMaxDurability($target);
        $targetRemaining = $maxDurability - $target->getDamage();
        $sacrificeRemaining = $maxDurability - $sacrifice->getDamage();
        $repairBonus = floor($maxDurability * 0.12); // 12%修复加成
        
        return $targetRemaining + $sacrificeRemaining + $repairBonus;
    }
    
/**
 * 执行物品修复并返回结果物品（完整附魔合并）
 */
private function performRepair(Item $target, Item $sacrifice){
    $resultItem = clone $target;
    $maxDurability = $this->getMaxDurability($target);
    $currentDamage = $target->getDamage();
    
    if($target->getId() == $sacrifice->getId()){
        // 同类物品合并修复
        $totalRemaining = $this->calculateMergeRepairAmount($target, $sacrifice);
        $newDamage = max(0, $maxDurability - min($totalRemaining, $maxDurability));
        
        // 修复点：完整的附魔合并逻辑
        if($sacrifice->hasEnchantments()){
            foreach($sacrifice->getEnchantments() as $sacrificeEnchant){
                $found = false;
                $targetEnchants = $resultItem->getEnchantments();
                
                // 检查目标物品是否已有相同附魔
                foreach($targetEnchants as $targetEnchant){
                    if($targetEnchant->getId() === $sacrificeEnchant->getId()){
                        // 相同附魔，取最高等级
                        if($sacrificeEnchant->getLevel() > $targetEnchant->getLevel()){
                            $resultItem->addEnchantment($sacrificeEnchant);
                        }
                        $found = true;
                        break;
                    }
                }
                
                // 如果没有相同附魔，直接添加
                if(!$found){
                    $resultItem->addEnchantment($sacrificeEnchant);
                }
            }
        }
    } else {
        // 原材料修复（只修复耐久，不合并附魔）
        $repairAmount = $this->calculateMaterialRepairAmount($target);
        $newDamage = max(0, $currentDamage - $repairAmount);
    }
    
    // 设置修复后的耐久度
    $resultItem->setDamage($newDamage);
    
    return $resultItem;
}
    
    /**
     * 更新铁砧砧界面显示的结果物品
     */
    /**
 * 更新铁砧界面显示的结果物品
 */
private function updateResultItem(){
    $targetItem = $this->getItem(self::TARGET);
    $sacrificeItem = $this->getItem(self::SACRIFICE);
    
    // 清空结果槽
    $this->clear(self::RESULT);
    
    // 检查附魔书操作
    if($targetItem !== null && $sacrificeItem instanceof EnchantedBook && $sacrificeItem->hasEnchantments()){
        $resultItem = clone $targetItem;
        
        // 添加附魔书的附魔到目标物品
        foreach($sacrificeItem->getEnchantments() as $enchant){
            $resultItem->addEnchantment($enchant);
        }
        
        $this->setItem(self::RESULT, $resultItem);
        $this->Customitem = $resultItem;
        return true;
    }
    
    // 检查是否可以修复
    if($targetItem !== null && $sacrificeItem !== null && $this->canBeRepaired($targetItem)){
        if($this->isRepairMaterial($targetItem, $sacrificeItem)){
            // 执行修复并显示结果（使用修复后的方法）
            $repairedItem = $this->performRepair($targetItem, $sacrificeItem);
            $this->setItem(self::RESULT, $repairedItem);
            $this->Customitem = $repairedItem;
            return true;
        }
    }
    
    return false;
}
    
    public function onRename(Player $player, $slot, $sourceItem, $resultItem){
    if(!isset($resultItem)){
        return;
    }
    
    $targetItem = $this->getItem(self::TARGET);
    $sacrificeItem = $this->getItem(self::SACRIFICE);
    
    // 检查是否是附魔书操作
    if($targetItem !== null && $sacrificeItem instanceof EnchantedBook && $sacrificeItem->hasEnchantments()){
        // 附魔书操作已在processEnchanting方法中处理
        return true;
    }
    
    // 检查是否是修复操作
    if($targetItem !== null && $sacrificeItem !== null && $this->canBeRepaired($targetItem)){
        // 检查牺牲物品是否是有效的修复材料
        if($this->isRepairMaterial($targetItem, $sacrificeItem)){
            // 执行修复（使用修复后的方法）
            $repairedItem = $this->performRepair($targetItem, $sacrificeItem);
            
            // 如果同时有重命名，应用新名称
            if($resultItem->hasCustomName()){
                $repairedItem->setCustomName($resultItem->getCustomName());
            }
            
            $this->Customitem = $repairedItem;
            return true;
        }
    }
    
    // 原有的重命名逻辑
    if(!$resultItem->deepEquals($this->getItem(self::TARGET), true, false, true)){
        //Item does not match target item. Everything must match except the tags.
        return false;
    }
    
    $this->Customitem = $resultItem;
    return true;
}
    
    /**
     * 当物品栏内容变化时更新结果
     */
    public function onSlotChange($index, $before){
        parent::onSlotChange($index, $before);
        
        // 如果目标槽或牺牲槽发生变化，更新结果物品
        if($index == self::TARGET || $index == self::SACRIFICE){
            $this->updateResultItem();
        }
    }
    
    public function hasBannedWord($message)
    {
        $wordfound = false;
        $words     = \explode(" ", $message);
        
        if( !isset( $this->wordsBanned ) )
        {
            return $wordfound;
        }
        /* check for the first word banned word occurance */
        foreach( $this->wordsBanned as $bannedWord )
        {
            // breaks on the first inappropriate word encountered
            
            // verify word is set
            if( !isset( $bannedWord[0] ) )
            {
                break;
            }
            // complete word match?
            if( $bannedWord[0] === '\\' )
            {
                $bannedWord = \substr($bannedWord,1);
                foreach( $words as $word )
                {   
                    if( \strcasecmp($word,$bannedWord) === 0 )
                    {
                        $wordfound = true;
                        break 2;
                    }
                } /* foreach( $words as $word */
            }   
                
            // substring match?
            else if( \stripos($message,$bannedWord) !== false )
            {
                $wordfound = true;
                break;
            }
            
        } /* foreach( $this->wordsBanned as $bannedWord ) */
        
        return $wordfound;
    }
    
    /**
     * 检查字符串是否包含emoji
     */
    function have_emoji($str){
        $mat = [];
        preg_match_all('/./u', $str, $mat);
        foreach ($mat[0] as $v){
            if(strlen($v) > 3){
                return true;
            }
        }
        return false;
    }
    
    public function processSlotChange(Transaction $transaction): bool{
        if($transaction->getSlot() === $this->getResultSlotIndex()){
            return false;
        }
        return true;
    }

    public function onClose(Player $who){
        $who->updateExperience();
        parent::onClose($who);

        // 掉落物品
        $this->getHolder()->getLevel()->dropItem($this->getHolder()->add(0.5, 0.5, 0.5), $this->getItem(self::SACRIFICE));
        $this->getHolder()->getLevel()->dropItem($this->getHolder()->add(0.5, 0.5, 0.5), $this->getItem(self::TARGET));
        
        $who->usingAnvil = false;
        
        // 清空所有槽位
        $this->clear(self::TARGET);
        $this->clear(self::SACRIFICE);
        $this->clear(self::RESULT);
    }

    /**
     * 统一处理所有类型的铁砧交易（重命名、修复、附魔）
     */
    public function processTransaction(Player $player){
        $target = $this->getItem(self::TARGET);
        $sacrifice = $this->getItem(self::SACRIFICE);
        $result = $this->getItem(self::RESULT);
        
        if($target === null || $result === null){
            return false;
        }
        
        // 检查是否是附魔书操作
        if($sacrifice !== null && $sacrifice instanceof EnchantedBook && $sacrifice->hasEnchantments()){
            return $this->processEnchantTransaction($player, $target, $sacrifice, $result);
        }
        
        // 检查是否是修复操作
        if($sacrifice !== null && $this->canBeRepaired($target) && $this->isRepairMaterial($target, $sacrifice)){
            return $this->processRepairTransaction($player, $target, $sacrifice, $result);
        }
        
        // 默认是重命名操作
        return $this->processRenameTransaction($player, $target, $result);
    }
    
    /**
     * 处理附魔交易
     */
    private function processEnchantTransaction(Player $player, Item $target, Item $sacrifice, Item $result){
        // 检查经验是否足够
        $cost = $this->calculateRepairCost($result);
        if($player->getExpLevel() < $cost){
            $player->sendMessage("经验不足！需要 " . $cost . " 级经验");
            return false;
        }
        
        // 调用事件
        $event = new AnvilProcessEvent($this, $target, $sacrifice, $result, $player, $cost);
        $player->getServer()->getPluginManager()->callEvent($event);
        
        if($event->isCancelled()){
            return false;
        }
        
        // 扣除经验
        $player->setExpLevel($player->getExpLevel() - $cost);
        
        // 移除消耗的物品
        $target->setCount($target->getCount() - 1);
        $sacrifice->setCount($sacrifice->getCount() - 1);
        
        $this->setItem(self::TARGET, $target->getCount() > 0 ? $target : Item::get(Item::AIR));
        $this->setItem(self::SACRIFICE, $sacrifice->getCount() > 0 ? $sacrifice : Item::get(Item::AIR));
        
        // 给予结果物品
        if(!$player->getInventory()->canAddItem($result)){
            $player->getLevel()->dropItem($player, $result);
        } else {
            $player->getInventory()->addItem($result);
        }
        
        // 清空结果槽
        $this->setItem(self::RESULT, Item::get(Item::AIR));
        
        // 播放音效
        $player->getLevel()->addSound(new AnvilUseSound($player));
        
        // 应用铁砧受损逻辑
        $this->applyAnvilDamage($player);
        
        return true;
    }

    /**
     * 处理修复交易
     */
    private function processRepairTransaction(Player $player, Item $target, Item $sacrifice, Item $result){
        // 检查是否可以修复
        if(!$this->canBeRepaired($target) || !$this->isRepairMaterial($target, $sacrifice)){
            return false;
        }
        
        // 检查经验是否足够
        $cost = $this->calculateRepairCost($result);
        if($player->getExpLevel() < $cost){
            $player->sendMessage("经验不足！需要 " . $cost . " 级经验");
            return false;
        }
        
        // 调用事件
        $event = new AnvilProcessEvent($this, $target, $sacrifice, $result, $player, $cost);
        $player->getServer()->getPluginManager()->callEvent($event);
        
        if($event->isCancelled()){
            return false;
        }
        
        // 扣除经验
        $player->setExpLevel($player->getExpLevel() - $cost);
        
        // 移除消耗的物品
        $target->setCount($target->getCount() - 1);
        $sacrifice->setCount($sacrifice->getCount() - 1);
        
        $this->setItem(self::TARGET, $target->getCount() > 0 ? $target : Item::get(Item::AIR));
        $this->setItem(self::SACRIFICE, $sacrifice->getCount() > 0 ? $sacrifice : Item::get(Item::AIR));
        
        // 给予修复后的物品
        if(!$player->getInventory()->canAddItem($result)){
            $player->getLevel()->dropItem($player, $result);
        } else {
            $player->getInventory()->addItem($result);
        }
        
        // 清空结果槽
        $this->setItem(self::RESULT, Item::get(Item::AIR));
        
        // 播放音效
        $player->getLevel()->addSound(new AnvilUseSound($player));
        
        // 应用铁砧受损逻辑
        $this->applyAnvilDamage($player);
        
        return true;
    }

    /**
     * 处理重命名交易
     */
    private function processRenameTransaction(Player $player, Item $target, Item $result){
        // 检查名称是否有效
        if($result->hasCustomName()){
            $name = $result->getCustomName();
            if($this->hasBannedWord($name)){
                $player->sendMessage("名称包含违禁词！");
                return false;
            }
            if($this->have_emoji($name)){
                $player->sendMessage("名称不能包含emoji！");
                return false;
            }
        }
        
        // 重命名成本
        $cost = 1;
        
        // 检查经验是否足够
        if($player->getExpLevel() < $cost){
            $player->sendMessage("经验不足！需要 " . $cost . " 级经验");
            return false;
        }
        
        // 调用事件
        $event = new AnvilProcessEvent($this, $target, Item::get(Item::AIR), $result, $player, $cost);
        $player->getServer()->getPluginManager()->callEvent($event);
        
        if($event->isCancelled()){
            return false;
        }
        
        // 扣除经验
        $player->setExpLevel($player->getExpLevel() - $cost);
        
        // 移除消耗的物品
        $target->setCount($target->getCount() - 1);
        $this->setItem(self::TARGET, $target->getCount() > 0 ? $target : Item::get(Item::AIR));
        
        // 给予重命名后的物品
        if(!$player->getInventory()->canAddItem($result)){
            $player->getLevel()->dropItem($player, $result);
        } else {
            $player->getInventory()->addItem($result);
        }
        
        // 清空结果槽
        $this->setItem(self::RESULT, Item::get(Item::AIR));
        
        // 播放音效
        $player->getLevel()->addSound(new AnvilUseSound($player));
        
        // 应用铁砧受损逻辑
        $this->applyAnvilDamage($player);
        
        return true;
    }
}
