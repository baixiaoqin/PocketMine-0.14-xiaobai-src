<?php

/*
 *  ______   _____    ______  __   __  ______
 * /  ___/  /  ___|  / ___  \ \ \ / / |  ____|
 * | |___  | |      | |___| |  \ / /  | |____
 * \___  \ | |      |  ___  |   / /   |  ____|
 *  ___| | | |____  | |   | |  / / \  | |____
 * /_____/  \_____| |_|   |_| /_/ \_\ |______|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author Sunch233#3226 QQ2125696621 And KKK
 * @link https://github.com/ScaxeTeam/Scaxe/
 * 修复工具还未完善
 */

namespace pocketmine\inventory;

use pocketmine\level\Position;
use pocketmine\Player;
use pocketmine\item\Item;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\block\Block;
use pocketmine\block\Anvil as AnvilBlock;
use pocketmine\item\EnchantedBook;
use pocketmine\event\inventory\AnvilProcessEvent;
use pocketmine\Server;

class AnvilInventory extends ContainerInventory{
    
    const TARGET = 0;
    const SACRIFICE = 1;
    const RESULT = 2;
    private $Customitem;
    
    protected $wordsBanned = ["服务器","axe","生存斧","傻逼","端口","19132","19133","scf"];
    
    // 可修复物品的最大耐久度映射
    private $maxDurability = [
        // 木制工具
        268 => 59, 269 => 59, 270 => 59, 271 => 59, 290 => 59,
        // 石制工具
        272 => 131, 273 => 131, 274 => 131, 275 => 131, 291 => 131,
        // 铁制工具
        256 => 250, 257 => 250, 258 => 250, 267 => 250, 292 => 250,
        // 钻石工具
        276 => 1561, 277 => 1561, 278 => 1561, 279 => 1561, 293 => 1561,
        // 金制工具
        283 => 32, 284 => 32, 285 => 32, 286 => 32, 294 => 32,
        // 其他工具
        259 => 64, 261 => 384, 346 => 384, 359 => 238,
        // 皮革盔甲
        298 => 55, 299 => 80, 300 => 75, 301 => 65,
        // 金盔甲
        314 => 77, 315 => 112, 316 => 105, 317 => 91,
        // 铁/链甲
        302 => 165, 303 => 240, 304 => 225, 305 => 195,
        306 => 165, 307 => 240, 308 => 225, 309 => 195,
        // 钻石盔甲
        310 => 363, 311 => 528, 312 => 495, 313 => 429,
    ];
    
    // 修复材料映射：原材料ID => 可修复的物品ID数组
    private $repairMaterials = [
        5 => [268, 269, 270, 271, 290, 291, 292, 293, 294],
        280 => [268, 269, 270, 271, 290, 291, 292, 293, 294],
        4 => [272, 273, 274, 275, 291],
        265 => [256, 257, 258, 267, 292, 306, 307, 308, 309, 302, 303, 304, 305],
        266 => [283, 284, 285, 286, 294, 314, 315, 316, 317],
        264 => [276, 277, 278, 279, 293, 310, 311, 312, 313],
        334 => [298, 299, 300, 301],
    ];
    
    public function __construct(Position $pos){
        parent::__construct(new FakeBlockMenu($this, $pos), InventoryType::get(InventoryType::ANVIL));
    }

    /**
     * @return FakeBlockMenu
     */
    public function getHolder(){
        return $this->holder;
    }
    
    
    public function getResultSlotIndex(){
        return self::RESULT;
    }

    /**
     * 更新铁砧界面显示的结果物品
     */
    private function updateResultItem(){
        $targetItem = $this->getItem(self::TARGET);
        $sacrificeItem = $this->getItem(self::SACRIFICE);

        $this->clear(self::RESULT);

        // 附魔书合并
        if($targetItem !== null && $sacrificeItem instanceof EnchantedBook && $sacrificeItem->hasEnchantments()){
            $resultItem = clone $targetItem;
            foreach($sacrificeItem->getEnchantments() as $enchant){
                $resultItem->addEnchantment($enchant);
            }
            $this->setItem(self::RESULT, $resultItem);
            $this->Customitem = $resultItem;
            return true;
        }
        // 修复功能
        if($targetItem !== null && $sacrificeItem !== null && $this->canBeRepaired($targetItem)){
            if($this->isRepairMaterial($targetItem, $sacrificeItem)){
                $repairedItem = $this->performRepair($targetItem, $sacrificeItem);
                $this->setItem(self::RESULT, $repairedItem);
                $this->Customitem = $repairedItem;
                return true;
            }
        }

        // 仅改名时，直接显示槽1物品
        if($targetItem !== null && $sacrificeItem === null && $targetItem->hasCustomName()){
            $this->setItem(self::RESULT, $targetItem);
            $this->Customitem = $targetItem;
            return true;
        }

        return false;
    }

    public function onSlotChange($index, $before){
        parent::onSlotChange($index, $before);
        if($index == self::TARGET || $index == self::SACRIFICE){
            $this->updateResultItem();
        }
    }

    /**
     * 检查物品是否可以被修复
     */
    private function canBeRepaired(Item $item){
        $id = $item->getId();
        return isset($this->maxDurability[$id]);
    }
    
    /**
     * 获取物品的最大耐久度
     */
    private function getMaxDurability(Item $item){
        $id = $item->getId();
        if(isset($this->maxDurability[$id])){
            return $this->maxDurability[$id];
        }
        return 0; // 不可修复的物品
    }
    
    /**
     * 检查牺牲物品是否是目标物品的修复材料
     */
    private function isRepairMaterial(Item $target, Item $sacrifice){
        $targetId = $target->getId();
        $sacrificeId = $sacrifice->getId();
        if($targetId == $sacrificeId){
            return true;
        }
        // 链甲可以用铁锭修复
        if(($targetId >= 302 && $targetId <= 305) && $sacrificeId == 265){
            return true;
        }
        // 检查映射
        if(isset($this->repairMaterials[$sacrificeId])){
            return in_array($targetId, $this->repairMaterials[$sacrificeId]);
        }
        return false;
    }

    /**
     * 合并修复时的耐久恢复
     */
    private function calculateMergeRepairAmount(Item $target, Item $sacrifice){
        $maxDurability = $this->getMaxDurability($target);
        $targetRemaining = $maxDurability - $target->getDamage();
        $sacrificeRemaining = $maxDurability - $sacrifice->getDamage();
        $repairBonus = floor($maxDurability * 0.12);
        return $targetRemaining + $sacrificeRemaining + $repairBonus;
    }
    
    /**
     * 原材料修复时的耐久恢复
     */
    private function calculateMaterialRepairAmount(Item $target){
        $maxDurability = $this->getMaxDurability($target);
        return floor($maxDurability * 0.25);
    }
    
    /**
     * 执行物品修复并返回结果物品（附魔合并）
     */
    private function performRepair(Item $target, Item $sacrifice){
        $resultItem = clone $target;
        $maxDurability = $this->getMaxDurability($target);
        $currentDamage = $target->getDamage();
        if($target->getId() == $sacrifice->getId()){
            $totalRemaining = $this->calculateMergeRepairAmount($target, $sacrifice);
            $newDamage = max(0, $maxDurability - min($totalRemaining, $maxDurability));
            // 附魔合并
            if($sacrifice->hasEnchantments()){
                foreach($sacrifice->getEnchantments() as $sacrificeEnchant){
                    $found = false;
                    foreach($resultItem->getEnchantments() as $targetEnch){
                        if($targetEnch->getId() === $sacrificeEnchant->getId()){
                            if($sacrificeEnchant->getLevel() > $targetEnch->getLevel()){
                                $resultItem->addEnchantment($sacrificeEnchant);
                            }
                            $found = true;
                            break;
                        }
                    }
                    if(!$found){
                        $resultItem->addEnchantment($sacrificeEnchant);
                    }
                }
            }
        } else {
            $repairAmount = $this->calculateMaterialRepairAmount($target);
            $newDamage = max(0, $currentDamage - $repairAmount);
        }
        $resultItem->setDamage($newDamage);
        return $resultItem;
    }
    
    /**
     * 费用计算（经验等级数量）
     */
    private function calculateRepairCost(Item $item){
        $cost = 1;
        if($item->hasEnchantments()){
            $enchantments = $item->getEnchantments();
            $cost += count($enchantments) * 2;
            foreach($enchantments as $enchant){
                $level = $enchant->getLevel();
                if($level > 1){
                    $cost += $level - 1;
                }
            }
        }
        if($item->getDamage() > 0){
            $maxDurability = $this->getMaxDurability($item);
            if($maxDurability > 0){
                $damagePercent = $item->getDamage() / $maxDurability;
                $cost += ceil($damagePercent * 5);
            }
        }
        if($item->hasCustomName()){
            $cost += 1;
        }
        return max(1, $cost);
    }

    /**
     * 受损逻辑（有概率损坏/破坏铁砧），返回true表示铁砧已粉碎
     */
    private function applyAnvilDamage(Player $player) {
        $holderPos = $this->getHolder();
        if (!$holderPos instanceof Position) return false;
        $block = $player->getLevel()->getBlock($holderPos);
        if (!($block instanceof AnvilBlock)) return false;
        if (mt_rand(1, 100) > 12) return false;
        $currentDamageState = $block->getDamage() & 0x0c;
        switch ($currentDamageState) {
            case AnvilBlock::NORMAL:
                $newDamageState = AnvilBlock::SLIGHTLY_DAMAGED;
                $player->getLevel()->setBlock($block, Block::get(Block::ANVIL, $newDamageState | ($block->getDamage() & 0x03)), true, true);
                $player->getLevel()->addSound(new AnvilUseSound($block));
                return false;
            case AnvilBlock::SLIGHTLY_DAMAGED:
                $newDamageState = AnvilBlock::VERY_DAMAGED;
                $player->getLevel()->setBlock($block, Block::get(Block::ANVIL, $newDamageState | ($block->getDamage() & 0x03)), true, true);
                return false;
            case AnvilBlock::VERY_DAMAGED:
            default:
                $block->onBreak(Item::get(Item::AIR));
                return true;
        }
    }
    
    public function finishRename(Player $player, $type){
        if(!isset($this->Customitem)){
            return;
        }
        if($this->Customitem->hasCustomName()){
            if($this->hasBannedWord($this->Customitem->getCustomName())){
                $player->getServer()->getLogger()->notice($player->getName()."在改名时触发违禁词：".$this->Customitem->getCustomName());
                $item = $this->Customitem->setCustomName("§c检测到违禁词");
                $player->sendMessage("§c改名期间检测到违禁词");
                $this->Customitem = $item;
            }
            if($this->have_emoji($this->Customitem->getCustomName())){
                $item = $this->Customitem->setCustomName("§c不允许emoji");
            }
        }
        $targetItem = $this->getItem(self::TARGET);
        $sacrificeItem = $this->getItem(self::SACRIFICE);
        // 优先处理附魔书
        if($targetItem !== null && $sacrificeItem instanceof EnchantedBook && $sacrificeItem->hasEnchantments()){
            // 调用完整流程，扣经验与受损
            $level = $player->getExpLevel();
            $cost = $this->calculateRepairCost($this->Customitem);
            if($level < $cost){
                $player->sendMessage("经验不足！需要 {$cost} 级");
                return false;
            }
            $player->setExpLevel($level - $cost);
            $this->clearAll();
            $player->getInventory()->addItem($this->Customitem);
            $isAnvilDestroyed = $this->applyAnvilDamage($player);
            if (!$isAnvilDestroyed) {
                $player->getLevel()->addSound(new AnvilUseSound($player));
            }
            $this->Customitem = null;
            return true;
        }
        // 修复功能
        if($targetItem !== null && $sacrificeItem !== null && $this->canBeRepaired($targetItem) && $this->isRepairMaterial($targetItem, $sacrificeItem)){
            $level = $player->getExpLevel();
            $cost = $this->calculateRepairCost($this->Customitem);
            if($level < $cost){
                $player->sendMessage("经验不足！需要 {$cost} 级");
                return false;
            }
            $player->setExpLevel($level - $cost);
            $this->clearAll();
            $player->getInventory()->addItem($this->Customitem);
            $isAnvilDestroyed = $this->applyAnvilDamage($player);
            if (!$isAnvilDestroyed) {
                $player->getLevel()->addSound(new AnvilUseSound($player));
            }
            $this->Customitem = null;
            return true;
        }
        // 仅重命名
        if($this->Customitem->hasCustomName()){
            $level = $player->getExpLevel();
            $cost = 1;
            if($level < $cost){
                $player->sendMessage("经验不足！需要 {$cost} 级");
                return false;
            }
            $player->setExpLevel($level - $cost);
        }
        $this->clearAll();
        $player->getInventory()->addItem($this->Customitem);
        $isAnvilDestroyed = $this->applyAnvilDamage($player);
        if (!$isAnvilDestroyed) {
            $player->getLevel()->addSound(new AnvilUseSound($player));
        }
        $this->Customitem = null;
        return true;
    }
    
    public function onRename(Player $player, $slot, $sourceItem, $resultItem){
        if(!isset($resultItem)){
            return;
        }
        $targetItem = $this->getItem(self::TARGET);
        $sacrificeItem = $this->getItem(self::SACRIFICE);
        // 附魔书
        if($targetItem !== null && $sacrificeItem instanceof EnchantedBook && $sacrificeItem->hasEnchantments()){
            return true;
        }
        // 修复
        if($targetItem !== null && $sacrificeItem !== null && $this->canBeRepaired($targetItem) && $this->isRepairMaterial($targetItem, $sacrificeItem)){
            $repairedItem = $this->performRepair($targetItem, $sacrificeItem);
            if($resultItem->hasCustomName()){
                $repairedItem->setCustomName($resultItem->getCustomName());
            }
            $this->Customitem = $repairedItem;
            return true;
        }
        // 改名
        if(!$resultItem->deepEquals($this->getItem(self::TARGET), true, false, true)){
            return false;
        }
        $this->Customitem = $resultItem;
        return true;
    }

    public function processSlotChange(Transaction $transaction): bool{
        if($transaction->getSlot() === $this->getResultSlotIndex()){
            return false;
        }
        return true;
    }

    public function onClose(Player $who){
        $who->updateExperience();
        parent::onClose($who);
        $this->getHolder()->getLevel()->dropItem($this->getHolder()->add(0.5, 0.5, 0.5), $this->getItem(self::SACRIFICE));
        $this->getHolder()->getLevel()->dropItem($this->getHolder()->add(0.5, 0.5, 0.5), $this->getItem(self::TARGET));
        $who->usingAnvil = false;
        $this->clear(self::TARGET);
        $this->clear(self::SACRIFICE);
        $this->clear(self::RESULT);
    }

    public function hasBannedWord($message){
        $wordfound = false;
        $words     = \explode(" ", $message);
        if( !isset( $this->wordsBanned ) ) return $wordfound;
        foreach( $this->wordsBanned as $bannedWord ){
            if( !isset( $bannedWord[0] ) ) break;
            if( $bannedWord[0] === '\\' ){
                $bannedWord = \substr($bannedWord,1);
                foreach( $words as $word ){   
                    if( \strcasecmp($word,$bannedWord) === 0 ){
                        $wordfound = true;
                        break 2;
                    }
                }
            }
            else if( \stripos($message,$bannedWord) !== false ){
                $wordfound = true;
                break;
            }
        }
        return $wordfound;
    }
    
    function have_emoji($str){
        $mat = [];
        preg_match_all('/./u', $str, $mat);
        foreach ($mat[0] as $v){
            if(strlen($v) > 3){
                return true;
            }
        }
        return false;
    }
}