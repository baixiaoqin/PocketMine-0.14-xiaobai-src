<?php

/*
 *
 *    _______                    _
 *   |__   __|                  (_)
 *      | |_   _ _ __ __ _ _ __  _  ___
 *      | | | | | '__/ _` | '_ \| |/ __|
 *      | | |_| | | | (_| | | | | | (__
 *      |_|\__,_|_|  \__,_|_| |_|_|\___|
 *
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author TuranicTeam
 * @link https://github.com/TuranicTeam/Turanic
 * SCAXE 核心加以改进
*/

namespace pocketmine\entity\ai\behavior;

use pocketmine\entity\Mob;
use pocketmine\math\Vector3;
use pocketmine\block\Air;
use pocketmine\block\Block;

class StrollBehavior extends Behavior{

    public $duration;
    public $timeLeft;
    public $speed;
    public $speedMultiplier;

    public function __construct(Mob $entity, int $duration = 80, float $speed = 0.25, float $speedMultiplier = 0.75){
        parent::__construct($entity);

        $this->duration = $duration;
        $this->speed = $speed;
        $this->speedMultiplier = $speedMultiplier;
        $this->timeLeft = $duration;
    }

    public function getName() : string{
        return "行走";
    }

    public function shouldStart() : bool{
        return mt_rand(0,10) == 0;
    }

    public function canContinue() : bool{
        return $this->timeLeft-- > 0;
    }

    /**
     * 沿移动方向进行射线步进碰撞检测
     * 检测从实体脚部位置开始，沿移动方向，以固定步长检测，直到目标点。
     * 返回检测到的第一个碰撞方块的坐标（Vector3），若无碰撞返回null。
     *
     * @param Vector3 $start 起始坐标（通常是实体脚部位置）
     * @param Vector3 $direction 移动方向向量（已标准化）
     * @param float $distance 检测总距离
     * @param float $step 检测步长，越小越密集，防止高速穿墙
     * @return Vector3|null
     */
    private function rayTraceCollision(Vector3 $start, Vector3 $direction, float $distance, float $step = 0.2) : ?Vector3 {
        $level = $this->entity->getLevel();
        $currentPos = new Vector3($start->x, $start->y, $start->z);
        $stepVector = $direction->multiply($step);
        $steps = ceil($distance / $step);

        for($i = 0; $i < $steps; ++$i){
            // 检测当前点及其上方一格（针对高实体）
            $blockFoot = $level->getBlock($currentPos);
            $blockHead = $level->getBlock($currentPos->add(0, 1, 0));

            if($this->isImpassable($blockFoot) || ($this->entity->height >= 1 && $this->isImpassable($blockHead))){
                return $currentPos->floor();
            }
            // 检查上方第二格（针对跳跃或2格高实体）
            if($this->entity->height > 1){
                $blockHead2 = $level->getBlock($currentPos->add(0, 2, 0));
                if($this->isImpassable($blockHead2)){
                    return $currentPos->floor();
                }
            }
            $currentPos = $currentPos->add($stepVector);
        }
        return null; // 路径上未检测到碰撞
    }

    /**
     * 判断一个方块是否是不可通行的。
     * 包括所有固体方块、栅栏、墙、关闭的栅栏门。
     *
     * @param Block $block
     * @return bool
     */
    private function isImpassable(Block $block) : bool {
        if($block->isSolid()){
            return true;
        }
        $blockId = $block->getId();
        $meta = $block->getDamage();

        // 栅栏 (ID:85) 和 原石墙/苔石墙 (ID:139)
        $isFenceOrWall = ($blockId === 85 || $blockId === 139);

        // 检查是否为关闭的栅栏门
        $isClosedFenceGate = false;
        $fenceGateIds = [107, 183, 184, 185, 186, 187];
        if(in_array($blockId, $fenceGateIds, true)){
            // 检查栅栏门状态：元数据的第2位为0表示关闭
            if(($meta & 0x04) === 0){
                $isClosedFenceGate = true;
            }
        }

        return $isFenceOrWall || $isClosedFenceGate;
    }

    public function onTick(){
        $speedFactor = (float) ($this->speed * $this->speedMultiplier * 0.7 * ($this->entity->isInsideOfWater() ? 0.3 : 0.4));
        $level = $this->entity->getLevel();
        $coordinates = $this->entity->getPosition(); // 实体中心坐标
        $direction = $this->entity->getDirectionVector();
        $direction->y = 0;
        $entity = $this->entity;

        // 防止走出边界或踩空
        $blockDown = $level->getBlock($coordinates->add(0, -1, 0));
        if ($entity->getMotion()->y < 0 && $blockDown instanceof Air){
            // 脚下是空气，可能即将掉落，中止本次移动
            // $this->timeLeft = 0; // 可选：立即结束行为
            $this->entity->yaw += 180; // 简单转向
            $this->swimming();
            return;
        }

        // --- 关键修改：移动前进行路径碰撞预检测 ---
        $startCheckPos = $coordinates->floor(); // 检测起始点（脚部）
        $startCheckPos->y = (int) $startCheckPos->y;
        $moveDistance = $speedFactor + 0.5; // 检测距离略大于移动距离，包含“缓冲区”
        $collisionPos = $this->rayTraceCollision($startCheckPos, $direction->normalize(), $moveDistance, 0.2);

        if($collisionPos !== null){
            // 在路径上检测到不可通行的方块
            $blockAtCollision = $level->getBlock($collisionPos);
            $blockId = $blockAtCollision->getId();

            $isFenceOrWall = ($blockId === 85 || $blockId === 139);
            $isClosedFenceGate = false;
            $fenceGateIds = [107, 183, 184, 185, 186, 187];
            if(in_array($blockId, $fenceGateIds, true)){
                if(($blockAtCollision->getDamage() & 0x04) === 0){
                    $isClosedFenceGate = true;
                }
            }

            if($isFenceOrWall || $isClosedFenceGate){
                // 遇到栅栏、墙或关闭的栅栏门，直接转向
                $entity->yaw += 180;
            } else {
                // 遇到其他固体方块，尝试跳跃
                $blockUp = $level->getBlock($collisionPos->add(0,1,0));
                $blockUpUp = $level->getBlock($collisionPos->add(0,2,0));
                if(!$blockUp->isSolid() && !($entity->height > 1 && $blockUpUp->isSolid()) && mt_rand(0,5) != 0){
                    $entity->motionY = 0.42; // 实体跳跃
                } else {
                    $entity->yaw += 180; // 无法跳跃，转向
                }
            }
            // 检测到碰撞，本次Tick不施加水平移动力，仅处理转向或跳跃
            $this->swimming();
            return;
        }
        // --- 碰撞预检测结束 ---

        // 路径畅通，执行移动
        $targetCoord = $coordinates->add($direction->multiply($speedFactor));
        $motion = $direction->multiply($speedFactor);
        $currentMotion = $entity->getMotion();

        // 叠加移动速度，但限制最大速度
        if ($currentMotion->length() < $motion->length()){
            $newMotionX = $currentMotion->x + ($motion->x - $currentMotion->x) * 0.5; // 平滑插值
            $newMotionZ = $currentMotion->z + ($motion->z - $currentMotion->z) * 0.5;
            $entity->setMotion(new Vector3($newMotionX, $currentMotion->y, $newMotionZ));
        } else {
            $entity->setMotion(new Vector3($motion->x, $currentMotion->y, $motion->z));
        }

        $this->swimming();
    }

    public function onEnd(){
        $this->timeLeft = $this->duration;
        $this->entity->setMotion(new Vector3(0,0,0));
    }
}
