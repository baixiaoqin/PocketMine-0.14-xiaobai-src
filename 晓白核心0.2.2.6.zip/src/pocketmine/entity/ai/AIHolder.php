<?php
namespace pocketmine\entity\ai;

use pocketmine\event\entity\EntityGenerateEvent;
use pocketmine\level\Position;
use pocketmine\level\Level;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\entity\Entity;
use pocketmine\level\format\FullChunk;
use pocketmine\scheduler\CallbackTask;
use pocketmine\event\entity\EntityDeathEvent;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\scheduler\TaskHandler;
use pocketmine\Server;
use pocketmine\entity\Creeper;
use pocketmine\entity\Skeleton;
use pocketmine\entity\Cow;
use pocketmine\entity\Pig;
use pocketmine\entity\Sheep;
use pocketmine\entity\Spider;
use pocketmine\entity\Chicken;
use pocketmine\entity\Mooshroom;
use pocketmine\entity\Ocelot;
use pocketmine\entity\PigZombie;
use pocketmine\entity\Wolf;
use pocketmine\entity\Zombie;
use pocketmine\entity\Blaze;
use pocketmine\entity\Ghast;
use pocketmine\entity\LavaSlime; // 添加岩浆史莱姆
use pocketmine\entity\Squid;     // 添加鱿鱼

class AIHolder {
    public $ChickenAI;
    public $CowAI;
    public $CreeperAI;
    public $PigAI;
    public $SheepAI;
    public $SkeletonAI;
    public $SpiderAI;
    public $ZombieAI;
    public $DefultAI;
    public $Zombie = [];
    public $Creeper = [];
    public $Skeleton = [];
    public $Cow = [];
    public $Pig = [];
    public $Sheep = [];
    public $Spider = [];
    public $Chicken = [];
    public $Defult = [];
    public $PigZombie = [];
    public $Blaze = [];
    public $Ghast = [];
    public $LavaSlime = []; // 添加岩浆史莱姆数组
    public $Squid = [];      // 添加鱿鱼数组
    public $birth_r = 30;
    public $tasks = [];
    public $server;
    
    public function getServer() {
        return $this->server;
    }
    
    public function __construct(Server $server) {
        $this->server = $server;
        if($this->server->aiConfig["mobgenerate"]) {
            $this->tasks['ZombieGenerate'] = $this->getServer()->getScheduler()->scheduleRepeatingTask(new CallbackTask([
                            $this,
                            "MobGenerate"
                        ]), 20 * 60);
        }
        $this->getServer()->getScheduler()->scheduleRepeatingTask(new CallbackTask([
                    $this,
                    "TimeFix"
                ]), 20);
        $this->getServer()->getScheduler()->scheduleRepeatingTask(new CallbackTask ([$this, "RotationTimer"]), 2);
        /*$this->ZombieAI = new ZombieAI($this);
        $this->CowAI = new CowAI($this);
        $this->PigAI = new PigAI($this);
        $this->SheepAI = new SheepAI($this);
        $this->ChickenAI = new ChickenAI($this);
        $this->SpiderAI = new SpiderAI($this);*/
        $this->CreeperAI = new CreeperAI($this);
        //$this->SkeletonAI = new SkeletonAI($this);
    }
    
    /*
     ************ API 部分 ************************************
     */
    /**
     * @param $r
     * 设置僵尸仇恨半径
     */
    public function setZombieHatred_r($r) {
        $this->ZombieAI->hatred_r = $r;
    }
    
    /**
     * @param $r
     * 设置夜晚刷僵尸范围（以每个玩家为中心）
     */
    public function setZombieBirth_r($r) {
        $this->birth_r = $r;
    }
    
    /**
     * @param $v
     * 设置僵尸仇恨模式下的走路速度
     */
    public function setZombieHate_v($v) {
        $this->ZombieAI->zo_hate_v = $v;
    }
    
    /**
     * @param $tick
     * @return bool
     * 重新启动刷怪计时器
     * （可用于更改刷怪时间间隔）
     */
    public function RestartSpawnTimer($tick = 1200) {
        $task = $this->tasks['ZombieGenerate'];
        if($task instanceof TaskHandler) {
            //TODO 没试验过是否有效。。。
            $task->cancel();
            $task->run($tick);
            return true;
        } else {
            return false;
        }
    }
    
    public function TimeFix() {
        $mode = $this->mode();
        foreach($this->getServer()->getLevels() as $level) {
            foreach($level->getEntities() as $entity) {
                if($entity instanceof Zombie) {
                    $this->ahurt($entity,$mode);
                }
                if($entity instanceof Spider or $entity instanceof CaveSpider) {
                    $this->bhurt($entity,$mode);
                }
            }
            if($level->getTime() > 24000) {
                $level->setTime(0);
            }
        }
    }
    
    public function mode() {
        $mode = 1;
        switch($this->getServer()->getDifficulty()) {
            case 0:
            case 1:
                $mode = 1;
                break;
            case 2:
                $mode = 2;
                break;
            case 3:
                $mode = 3;
                break;
        }
        return $mode;
    }
    
    public function ahurt($e,$mode) {
        switch($mode) {
            case 1:
                $hurt = 5;
                break;
            case 2:
                $hurt = 6;
                break;
            case 3:
                $hurt = 8;
                break;
        }
        return $e->setHurt($hurt);
    }
    
    public function bhurt($e,$mode) {
        switch($mode) {
            case 1:
                $hurt = 5;
                break;
            case 2:
                $hurt = 6;
                break;
            case 3:
                $hurt = 6;
                break;
        }
        return $e->setHurt($hurt);
    }
    
    public function spawnZombie(Position $pos, $maxHealth = 20, $health = 20) {
        $chunk = $pos->level->getChunk($pos->x >> 4, $pos->z >> 4, false);
        $nbt = $this->getNBT();
        $zo = new Zombie($chunk, $nbt);
        $zo->setPosition($pos);
        $zo->setMaxHealth($maxHealth);
        $zo->setHealth($health);
        $zo->spawnToAll();
    }
    
    public function spawnCreeper(Position $pos, $maxHealth = 20, $health = 20) {
        $chunk = $pos->level->getChunk($pos->x >> 4, $pos->z >> 4, false);
        $nbt = $this->getNBT();
        $co = new Creeper($chunk, $nbt);
        $co->setPosition($pos);
        $co->setMaxHealth($maxHealth);
        $co->setHealth($health);
        $co->spawnToAll();
    }
    
    public function spawnSkeleton(Position $pos, $maxHealth = 20, $health = 20) {
        $chunk = $pos->level->getChunk($pos->x >> 4, $pos->z >> 4, false);
        $nbt = $this->getNBT();
        $so = new Skeleton($chunk, $nbt);
        $so->setPosition($pos);
        $so->setMaxHealth($maxHealth);
        $so->setHealth($health);
        $so->spawnToAll();
    }
    
    public function spawnSpider(Position $pos, $maxHealth = 16, $health = 16) {
        $chunk = $pos->level->getChunk($pos->x >> 4, $pos->z >> 4, false);
        $nbt = $this->getNBT();
        $so = new Spider($chunk, $nbt);
        $so->setPosition($pos);
        $so->setMaxHealth($maxHealth);
        $so->setHealth($health);
        $so->spawnToAll();
    }
    
    public function spawnCow(Position $pos, $maxHealth = 8, $health = 8) {
        $chunk = $pos->level->getChunk($pos->x >> 4, $pos->z >> 4, false);
        $nbt = $this->getNBT();
        $coo = new Cow($chunk, $nbt);
        $coo->setPosition($pos);
        $coo->setMaxHealth($maxHealth);
        $coo->setHealth($health);
        $coo->spawnToAll();
    }
    
    public function spawnPig(Position $pos, $maxHealth = 10, $health = 10) {
        $chunk = $pos->level->getChunk($pos->x >> 4, $pos->z >> 4, false);
        $nbt = $this->getNBT();
        $po = new Pig($chunk, $nbt);
        $po->setPosition($pos);
        $po->setMaxHealth($maxHealth);
        $po->setHealth($health);
        $po->spawnToAll();
    }
    
    public function spawnSheep(Position $pos, $maxHealth = 8, $health = 8) {
        $chunk = $pos->level->getChunk($pos->x >> 4, $pos->z >> 4, false);
        $nbt = $this->getNBT();
        $sho = new Sheep($chunk, $nbt);
        $sho->setPosition($pos);
        $sho->setMaxHealth($maxHealth);
        $sho->setHealth($health);
        $sho->spawnToAll();
    }
    
    public function spawnChicken(Position $pos, $maxHealth = 4, $health = 4) {
        $chunk = $pos->level->getChunk($pos->x >> 4, $pos->z >> 4, false);
        $nbt = $this->getNBT();
        $cho = new Chicken($chunk, $nbt);
        $cho->setPosition($pos);
        $cho->setMaxHealth($maxHealth);
        $cho->setHealth($health);
        $cho->spawnToAll();
    }
    
    // 添加猪人生成函数
    public function spawnPigZombie(Position $pos, $maxHealth = 20, $health = 20) {
        $chunk = $pos->level->getChunk($pos->x >> 4, $pos->z >> 4, false);
        $nbt = $this->getNBT();
        $pz = new PigZombie($chunk, $nbt);
        $pz->setPosition($pos);
        $pz->setMaxHealth($maxHealth);
        $pz->setHealth($health);
        $pz->spawnToAll();
    }
    
    // 添加烈焰人生成函数
    public function spawnBlaze(Position $pos, $maxHealth = 20, $health = 20) {
        $chunk = $pos->level->getChunk($pos->x >> 4, $pos->z >> 4, false);
        $nbt = $this->getNBT();
        $blaze = new Blaze($chunk, $nbt);
        $blaze->setPosition($pos);
        $blaze->setMaxHealth($maxHealth);
        $blaze->setHealth($health);
        $blaze->spawnToAll();
    }
    
    // 添加恶魂生成函数
    public function spawnGhast(Position $pos, $maxHealth = 10, $health = 10) {
        $chunk = $pos->level->getChunk($pos->x >> 4, $pos->z >> 4, false);
        $nbt = $this->getNBT();
        $ghast = new Ghast($chunk, $nbt);
        $ghast->setPosition($pos);
        $ghast->setMaxHealth($maxHealth);
        $ghast->setHealth($health);
        $ghast->spawnToAll();
    }
    
    // 添加岩浆史莱姆生成函数（使用LavaSlime类）
    public function spawnLavaSlime(Position $pos, $maxHealth = 16, $health = 16) {
        $chunk = $pos->level->getChunk($pos->x >> 4, $pos->z >> 4, false);
        $nbt = $this->getNBT();
        $lavaSlime = new LavaSlime($chunk, $nbt);
        $lavaSlime->setPosition($pos);
        $lavaSlime->setMaxHealth($maxHealth);
        $lavaSlime->setHealth($health);
        $lavaSlime->spawnToAll();
    }
    
    // 添加鱿鱼生成函数
    public function spawnSquid(Position $pos, $maxHealth = 10, $health = 10) {
        $chunk = $pos->level->getChunk($pos->x >> 4, $pos->z >> 4, false);
        $nbt = $this->getNBT();
        $squid = new Squid($chunk, $nbt);
        $squid->setPosition($pos);
        $squid->setMaxHealth($maxHealth);
        $squid->setHealth($health);
        $squid->spawnToAll();
    }
    
    /**
     * @param Player $player
     * @param        $damage
     * @return float
     * 根据玩家的装备获取玩家应受到的伤害值
     */
    public function getPlayerDamage(Player $player, $damage) {
        $armorValues = [
                    Item::LEATHER_CAP => 1,
                    Item::LEATHER_TUNIC => 3,
                    Item::LEATHER_PANTS => 2,
                    Item::LEATHER_BOOTS => 1,
                    Item::CHAIN_HELMET => 1,
                    Item::CHAIN_CHESTPLATE => 5,
                    Item::CHAIN_LEGGINGS => 4,
                    Item::CHAIN_BOOTS => 1,
                    Item::GOLD_HELMET => 1,
                    Item::GOLD_CHESTPLATE => 5,
                    Item::GOLD_LEGGINGS => 3,
                    Item::GOLD_BOOTS => 1,
                    Item::IRON_HELMET => 2,
                    Item::IRON_CHESTPLATE => 6,
                    Item::IRON_LEGGINGS => 5,
                    Item::IRON_BOOTS => 2,
                    Item::DIAMOND_HELMET => 3,
                    Item::DIAMOND_CHESTPLATE => 8,
                    Item::DIAMOND_LEGGINGS => 6,
                    Item::DIAMOND_BOOTS => 3,
                ];
        $points = 0;
        foreach($player->getInventory()->getArmorContents() as $index => $i) {
            if(isset($armorValues[$i->getId()])) {
                $points += $armorValues[$i->getId()];
            }
        }
        $damage = floor($damage - $points * 0.04);
        if($damage < 0) {
            $damage = 0;
        }
        return $damage;
    }
    
    /**
     * @return CompoundTag
     * 返回一个空的实体通用NBT
     */
    public function getNBT() : CompoundTag {
        $nbt = new CompoundTag("", [
                    "Pos" => new ListTag("Pos", [
                        new DoubleTag("", 0),
                        new DoubleTag("", 0),
                        new DoubleTag("", 0)
                    ]),
                    "Motion" => new ListTag("Motion", [
                        new DoubleTag("", 0),
                        new DoubleTag("", 0),
                        new DoubleTag("", 0)
                    ]),
                    "Rotation" => new ListTag("Rotation", [
                        new FloatTag("", 0),
                        new FloatTag("", 0)
                    ]),
                ]);
        return $nbt;
    }
    
    /**
     * @param Position $pos
     * @return int
     * 获取某坐标(位置)的亮度
     */
    public function getLight(Position $pos) {
        $chunk = $pos->getLevel()->getChunk($pos->x >> 4, $pos->z >> 4, false);
        $l = 0;
        if($chunk instanceof FullChunk) {
            $l = $chunk->getBlockSkyLight($pos->x & 0x0f, $pos->y & 0x7f, $pos->z & 0x0f);
            if($l < 15) {
                $l = $chunk->getBlockLight($pos->x & 0x0f, $pos->y & 0x7f, $pos->z & 0x0f);
            }
        }
        return $l;
    }
    
    /******** API结束 以下为计时器 *****************************/
    /**
     * @param Entity $entity
     * @return bool
     * 判断某生物周边32格内是否有玩家存在
     * 控制僵尸是否移动（自由行走模式）
     */
    public function willMove(Entity $entity) {
        foreach($entity->getViewers() as $viewer) {
            if($entity->distance($viewer->getLocation()) <= 32) return true;
        }
        return false;
    }
    
    public function RotationTimer() {
        foreach($this->getServer()->getLevels() as $level) {
            foreach($level->getEntities() as $entity) {
                if($entity instanceof Zombie || $entity instanceof Creeper || $entity instanceof Skeleton || 
                   $entity instanceof Cow || $entity instanceof Pig || $entity instanceof Sheep || 
                   $entity instanceof Chicken || $entity instanceof Spider ||
                   $entity instanceof PigZombie || $entity instanceof Blaze ||
                   $entity instanceof Ghast || $entity instanceof LavaSlime || $entity instanceof Squid) {
                   
                    if(count($entity->getViewers()) != 0) {
                        if($entity instanceof Zombie) {
                            $array = &$this->Zombie;
                        } elseif($entity instanceof Creeper) {
                            $array = &$this->Creeper;
                        } elseif($entity instanceof Skeleton) {
                            $array = &$this->Skeleton;
                        } elseif($entity instanceof Cow) {
                            $array = &$this->Cow;
                        } elseif($entity instanceof Pig) {
                            $array = &$this->Pig;
                        } elseif($entity instanceof Sheep) {
                            $array = &$this->Sheep;
                        } elseif($entity instanceof Chicken) {
                            $array = &$this->Chicken;
                        } elseif($entity instanceof Spider) {
                            $array = &$this->Spider;
                        } elseif($entity instanceof PigZombie) {
                            $array = &$this->PigZombie;
                        } elseif($entity instanceof Blaze) {
                            $array = &$this->Blaze;
                        } elseif($entity instanceof Ghast) {
                            $array = &$this->Ghast;
                        } elseif($entity instanceof LavaSlime) {
                            $array = &$this->LavaSlime;
                        } elseif($entity instanceof Squid) {
                            $array = &$this->Squid;
                        }
                        
                        if(isset($array[$entity->getId()])) {
                            $yaw0 = $entity->yaw;
                            $yaw = $array[$entity->getId()]['yaw'];
                            
                            if(abs($yaw0 - $yaw) <= 180) {
                                if($yaw0 <= $yaw) {
                                    if($yaw - $yaw0 <= 15) {
                                        $yaw0 = $yaw;
                                    } else {
                                        $yaw0 += 15;
                                    }
                                } else {
                                    if($yaw0 - $yaw <= 15) {
                                        $yaw0 = $yaw;
                                    } else {
                                        $yaw0 -= 15;
                                    }
                                }
                            } else {
                                if($yaw0 >= $yaw) {
                                    if((180 - $yaw0) + ($yaw + 180) <= 15) {
                                        $yaw0 = $yaw;
                                    } else {
                                        $yaw0 += 15;
                                        if($yaw0 >= 180) $yaw0 = $yaw0 - 360;
                                    }
                                } else {
                                    if((180 - $yaw) - ($yaw0 + 180) <= 15) {
                                        $yaw0 = $yaw;
                                    } else {
                                        $yaw0 -= 15;
                                        if($yaw0 <= 180) $yaw0 = $yaw0 + 360;
                                    }
                                }
                            }
                            
                            $pitch0 = $entity->pitch;
                            $pitch = $array[$entity->getId()]['pitch'];
                            
                            if(abs($pitch0 - $pitch) <= 15) {
                                $pitch0 = $pitch;
                            } elseif($pitch > $pitch0) {
                                $pitch0 += 10;
                            } elseif($pitch < $pitch0) {
                                $pitch0 -= 10;
                            }
                            
                            $entity->setRotation($yaw0, $pitch0);
                        }
                    }
                }
            }
        }
    }
    
    /**
     * @param $mx
     * @param $mz
     * @return float|int
     * 获取yaw角度
     */
    public function getyaw($mx, $mz) {
        if($mz == 0) {
            if($mx < 0) {
                $yaw = -90;
            } else {
                $yaw = 90;
            }
        } else {
            if($mx >= 0 and $mz > 0) {
                $atan = atan($mx / $mz);
                $yaw = rad2deg($atan);
            } elseif($mx >= 0 and $mz < 0) {
                $atan = atan($mx / abs($mz));
                $yaw = 180 - rad2deg($atan);
            } elseif($mx < 0 and $mz < 0) {
                $atan = atan($mx / $mz);
                $yaw = -(180 - rad2deg($atan));
            } elseif($mx < 0 and $mz > 0) {
                $atan = atan(abs($mx) / $mz);
                $yaw = -(rad2deg($atan));
            } else {
                $yaw = 0;
            }
        }
        $yaw = -$yaw;
        return $yaw;
    }
    
    /**
     * @param Vector3 $from
     * @param Vector3 $to
     * @return float|int
     * 获取pitch角度
     */
    public function getpitch(Vector3 $from, Vector3 $to) {
        $distance = $from->distance($to);
        $height = $to->y - $from->y;
        if($height > 0) {
            return -rad2deg(asin($height / $distance));
        } elseif($height < 0) {
            return rad2deg(asin(-$height / $distance));
        } else {
            return 0;
        }
    }
    
    /**
     * @param Level $level
     * @param Vector3 $v3
     * @param bool $hate
     * @param bool $reason
     * @return bool|float|string
     * 判断某坐标是否可以行走
     * 并给出原因
     */
    public function ifjump(Level $level, Vector3 $v3, $hate = false, $reason = false) {
        $x = floor($v3->getX());
        $y = floor($v3->getY());
        $z = floor($v3->getZ());
        
        if ($this->whatBlock($level,new Vector3($x,$y,$z)) == "air") {
            if ($this->whatBlock($level,new Vector3($x,$y-1,$z)) == "block" or $this->whatBlock($level,new Vector3($x,$y-1,$z)) == "climb") {
                if ($this->whatBlock($level,new Vector3($x,$y+1,$z)) == "block" or $this->whatBlock($level,new Vector3($x,$y+1,$z)) == "half" or $this->whatBlock($level,new Vector3($x,$y+1,$z)) == "high") {
                    if ($reason) return 'up!';
                    return false;
                } else {
                    if ($reason) return 'GO';
                    return $y;
                }
                    } elseif ($this->whatBlock($level,new Vector3($x,$y-1,$z)) == "water") {
            if ($reason) return 'swim';
            return $y-1;
        } elseif ($this->whatBlock($level,new Vector3($x,$y-1,$z)) == "half") {
            if ($reason) return 'half';
            return $y-0.5;
        } elseif ($this->whatBlock($level,new Vector3($x,$y-1,$z)) == "lava") {
            if ($reason) return 'lava';
            return false;
        } elseif ($this->whatBlock($level,new Vector3($x,$y-1,$z)) == "air") {
            if ($this->whatBlock($level,new Vector3($x,$y-2,$z)) == "block") {
                if ($reason) return 'down';
                return $y-1;
            } else {
                if ($reason) return 'fall';
                if ($hate === false) {
                    return false;
                } else {
                    return $y-1;
                }
            }
        }
    } elseif ($this->whatBlock($level,new Vector3($x,$y,$z)) == "water") {
        if ($this->whatBlock($level,new Vector3($x,$y+1,$z)) == "water") {
            if ($reason) return 'inwater';
            return $y+1;
        } elseif ($this->whatBlock($level,new Vector3($x,$y+1,$z)) == "block" or $this->whatBlock($level,new Vector3($x,$y+1,$z)) == "half") {
            if ($this->whatBlock($level,new Vector3($x,$y-1,$z)) == "block" or $this->whatBlock($level,new Vector3($x,$y-1,$z)) == "half") {
                if ($reason) return 'up!_down!';
                return false;
            } else {
                if ($reason) return 'up!';
                return $y-1;
            }
        } else {
            return $y;
        }
    } elseif ($this->whatBlock($level,new Vector3($x,$y,$z)) == "half") {
        if ($this->whatBlock($level,new Vector3($x,$y+1,$z)) == "block" or $this->whatBlock($level,new Vector3($x,$y+1,$z)) == "half" or $this->whatBlock($level,new Vector3($x,$y+1,$z)) == "high") {
        } else {
            if ($reason) return 'halfGO';
            return $y+0.5;
        }
    } elseif ($this->whatBlock($level,new Vector3($x,$y,$z)) == "lava") {
        if ($reason) return 'lava';
        return false;
    } elseif ($this->whatBlock($level,new Vector3($x,$y,$z)) == "high") {
        if ($reason) return 'high';
        return false;
    } elseif ($this->whatBlock($level,new Vector3($x,$y,$z)) == "climb") {
        if ($reason) return 'climb';
        if ($hate) {
            return $y + 0.7;
        } else {
            return $y + 0.5;
        }
    } else {
        if ($this->whatBlock($level,new Vector3($x,$y+1,$z)) != "air") {
            if ($reason) return 'wall';
            return false;
        } else {
            if ($this->whatBlock($level,new Vector3($x,$y+2,$z)) == "block" or $this->whatBlock($level,new Vector3($x,$y+2,$z)) == "half" or $this->whatBlock($level,new Vector3($x,$y+2,$z)) == "high") {
                if ($reason) return 'up2!';
                return false;
            } else {
                if ($reason) return 'upGO';
                return $y+1;
            }
        }
    }
    return false;
}

public function whatBlock(Level $level, $v3) {
    $block = $level->getBlock($v3);
    $id = $block->getID();
    $damage = $block->getDamage();
    switch ($id) {
        case 0:
        case 6:
        case 27:
        case 30:
        case 31:
        case 37:
        case 38:
        case 39:
        case 40:
        case 50:
        case 51:
        case 63:
        case 66:
        case 68:
        case 78:
        case 111:
        case 141:
        case 142:
        case 171:
        case 175:
        case 244:
        case 323:
            return "air";
            break;
        case 8:
        case 9:
            return "water";
            break;
        case 10:
        case 11:
            return "lava";
            break;
        case 44:
        case 158:
            if ($damage >= 8) {
                return "block";
            } else {
                return "half";
            }
            break;
        case 64:
            if (($damage & 0x08) === 0x08) {
                return "air";
            } else {
                return "block";
            }
            break;
        case 85:
        case 107:
        case 139:
            return "high";
            break;
        case 65:
        case 106:
            return "climb";
            break;
        default:
            return "block";
            break;
    }
}

public function MobDeath(EntityDeathEvent $event) {
    $entity = $event->getEntity();
    if($entity instanceof Zombie) {
        $eid = $entity->getID();
        if(isset($this->Zombie[$eid])) {
            unset($this->Zombie[$eid]);
        }
    }
    if($entity instanceof Creeper) {
    $eid = $entity->getID();
    if(isset($this->Creeper[$eid])) {
        // 检查 boomed 键是否存在，避免警告
        if(isset($this->Creeper[$eid]['boomed']) && $this->Creeper[$eid]['boomed'] == true){
            $event->setDrops([]);
        }
        unset($this->Creeper[$eid]);
    }
}
    if($entity instanceof Skeleton) {
        $eid = $entity->getID();
        if(isset($this->Skeleton[$eid])) {
            unset($this->Skeleton[$eid]);
        }
    }
    if($entity instanceof Spider) {
        $eid = $entity->getID();
        if(isset($this->Spider[$eid])) {
            unset($this->Spider[$eid]);
        }
    }
    if($entity instanceof Sheep) {
        $eid = $entity->getID();
        if(isset($this->Sheep[$eid])) {
            unset($this->Sheep[$eid]);
        }
    }
    if($entity instanceof Cow) {
        $eid = $entity->getID();
        if(isset($this->Cow[$eid])) {
            unset($this->Cow[$eid]);
        }
    }
    if($entity instanceof Pig) {
        $eid = $entity->getID();
        if(isset($this->Pig[$eid])) {
            unset($this->Pig[$eid]);
        }
    }
    if($entity instanceof Chicken) {
        $eid = $entity->getID();
        if(isset($this->Chicken[$eid])) {
            unset($this->Chicken[$eid]);
        }
    }
    if($entity instanceof Defult) {
        $eid = $entity->getID();
        if(isset($this->Defult[$eid])) {
            unset($this->Defult[$eid]);
        }
    }
    if($entity instanceof PigZombie) {
        $eid = $entity->getID();
        if(isset($this->PigZombie[$eid])) {
            unset($this->PigZombie[$eid]);
        }
    }
    if($entity instanceof Blaze) {
        $eid = $entity->getID();
        if(isset($this->Blaze[$eid])) {
            unset($this->Blaze[$eid]);
        }
    }
    if($entity instanceof Ghast) {
        $eid = $entity->getID();
        if(isset($this->Ghast[$eid])) {
            unset($this->Ghast[$eid]);
        }
    }
    if($entity instanceof LavaSlime) {
        $eid = $entity->getID();
        if(isset($this->LavaSlime[$eid])) {
            unset($this->LavaSlime[$eid]);
        }
    }
    if($entity instanceof Squid) {
        $eid = $entity->getID();
        if(isset($this->Squid[$eid])) {
            unset($this->Squid[$eid]);
        }
    }
}

/**
 * 优化后的生物生成计时器
 */
public function MobGenerate() {
    foreach ($this->getServer()->getOnlinePlayers() as $player) {
        $this->generateMobsForPlayer($player);
    }
}

/**
 * 为单个玩家生成生物
 */
private function generateMobsForPlayer(Player $player) {
    $level = $player->getLevel();
    $maxMobsPerType = 5; // 每种生物的最大数量
    
    // 生成随机位置
    $spawnPos = $this->getRandomSpawnPosition($player);
    if ($spawnPos === null) return;
    
    // 检查世界类型
    $isNether = $this->isNetherWorld($level);
    
    // 获取有效的生成位置
    $validSpawnPos = $this->findValidSpawnPosition($level, $spawnPos, $player->getY());
    if ($validSpawnPos === null) return;
    
    if ($isNether) {
        $this->generateNetherMobs($level, $validSpawnPos, $maxMobsPerType);
    } else {
        $this->generateOverworldMobs($level, $validSpawnPos, $maxMobsPerType, $player);
    }
}

/**
 * 获取随机生成位置
 */
private function getRandomSpawnPosition(Player $player): ?Vector3 {
    $x = $player->getX() + mt_rand(-$this->birth_r, $this->birth_r);
    $z = $player->getZ() + mt_rand(-$this->birth_r, $this->birth_r);
    
    return new Vector3($x, $player->getY(), $z);
}

/**
 * 判断是否为地狱世界
 */
private function isNetherWorld(Level $level): bool {
    $worldName = $level->getName();
    return stripos($worldName, 'nether') !== false || 
           stripos($worldName, '地狱') !== false || 
           $level->getDimension() === Level::DIMENSION_NETHER;
}

/**
 * 寻找有效的生成位置
 */
private function findValidSpawnPosition(Level $level, Vector3 $startPos, float $playerY): ?Vector3 {
    // 在玩家Y坐标上下15格范围内搜索
    for ($y = $playerY - 15; $y <= $playerY + 15; $y++) {
        $checkPos = new Vector3($startPos->x, $y, $startPos->z);
        
        // 检查当前位置是否为固体方块
        if ($this->whatBlock($level, $checkPos) !== "block") {
            continue;
        }
        
        // 检查上方2格是否可生成
        $above1 = new Vector3($startPos->x, $y + 1, $startPos->z);
        $above2 = new Vector3($startPos->x, $y + 2, $startPos->z);
        
        $blockAbove1 = $level->getBlock($above1);
        $blockAbove2 = $level->getBlock($above2);
        
        // 上方必须为空方块
        if ($blockAbove1->getID() === 0 && $blockAbove2->getID() === 0) {
            return new Vector3($startPos->x, $y + 1, $startPos->z);
        }
    }
    
    return null;
}

/**
 * 生成地狱生物
 */
private function generateNetherMobs(Level $level, Vector3 $spawnPos, int $maxMobs) {
    $random = mt_rand(0, 8);
    $entityCounts = $this->countEntitiesByType($level, [
        PigZombie::class, Blaze::class,
        Ghast::class, LavaSlime::class
    ]);
    
    switch ($random) {
        case 0:
        case 1:
        case 2:
        case 3:
            // 猪人生成 (40% 几率)
            $this->trySpawnMob($level, $spawnPos, PigZombie::class, $entityCounts[PigZombie::class], $maxMobs);
            break;
            
        case 4:
        case 5:
            // 烈焰人生成 (20% 几率)
            $this->trySpawnMob($level, $spawnPos, Blaze::class, $entityCounts[Blaze::class], $maxMobs);
            break;
            
        case 6:
        case 7:
            // 岩浆史莱姆生成 (20% 几率)
            $this->trySpawnMob($level, $spawnPos, LavaSlime::class, $entityCounts[LavaSlime::class], $maxMobs);
            break;
            
        case 8:
    // 恶魂生成 (10% 几率) - 只在高处生成
    $onlinePlayers = $this->getServer()->getOnlinePlayers();
    if (!empty($onlinePlayers)) {
        $playerY = $onlinePlayers[0]->getY(); // 取第一个在线玩家的Y坐标作为参考
        if ($spawnPos->y > $playerY + 10) {
            $ghastPos = new Vector3($spawnPos->x, $spawnPos->y + 5, $spawnPos->z);
            $this->trySpawnMob($level, $ghastPos, Ghast::class, $entityCounts[Ghast::class], 2);
        }
    }
    break;
    }
}

/**
 * 生成主世界生物
 */
private function generateOverworldMobs(Level $level, Vector3 $spawnPos, int $maxMobs, Player $player) {
    $random = mt_rand(0, 9);
    $isNight = $level->getTime() >= 13500;
    
    $entityCounts = $this->countEntitiesByType($level, [
        Zombie::class, Skeleton::class, Creeper::class, Spider::class,
        Cow::class, Sheep::class, Pig::class, Chicken::class, Squid::class
    ]);
    
    // 检查是否为水域（用于鱿鱼生成）
    $isWater = $this->isWaterBlock($level, $spawnPos);
    
    if ($isNight) {
        // 夜晚生成敌对生物
        switch ($random) {
            case 0:
                $this->trySpawnMob($level, $spawnPos, Zombie::class, $entityCounts[Zombie::class], $maxMobs);
                break;
            case 1:
                $this->trySpawnMob($level, $spawnPos, Skeleton::class, $entityCounts[Skeleton::class], $maxMobs);
                break;
            case 2:
                $this->trySpawnMob($level, $spawnPos, Creeper::class, $entityCounts[Creeper::class], $maxMobs);
                break;
            case 3:
                $this->trySpawnMob($level, $spawnPos, Spider::class, $entityCounts[Spider::class], $maxMobs);
                break;
            default:
                // 其他情况生成友好生物或鱿鱼
                $this->generatePassiveMobs($level, $spawnPos, $maxMobs, $entityCounts, $isWater);
                break;
        }
    } else {
        // 白天只生成友好生物和鱿鱼
        $this->generatePassiveMobs($level, $spawnPos, $maxMobs, $entityCounts, $isWater);
    }
}

/**
 * 生成友好生物
 */
private function generatePassiveMobs(Level $level, Vector3 $spawnPos, int $maxMobs, array $entityCounts, bool $isWater) {
    $random = mt_rand(0, 8);
    
    switch ($random) {
        case 0:
            if ($isWater) {
                $this->trySpawnMob($level, $spawnPos, Squid::class, $entityCounts[Squid::class], $maxMobs);
            }
            break;
        case 1:
        case 2:
            $this->trySpawnMob($level, $spawnPos, Chicken::class, $entityCounts[Chicken::class], $maxMobs);
            break;
        case 3:
        case 4:
            $this->trySpawnMob($level, $spawnPos, Sheep::class, $entityCounts[Sheep::class], $maxMobs);
            break;
        case 5:
        case 6:
            $this->trySpawnMob($level, $spawnPos, Pig::class, $entityCounts[Pig::class], $maxMobs);
            break;
        case 7:
        case 8:
            $this->trySpawnMob($level, $spawnPos, Cow::class, $entityCounts[Cow::class], $maxMobs);
            break;
    }
}

/**
 * 尝试生成生物
 */
private function trySpawnMob(Level $level, Vector3 $spawnPos, string $entityClass, int $currentCount, int $maxCount) {
    if ($currentCount >= $maxCount) {
        $this->removeExcessEntities($level, $entityClass, $currentCount - $maxCount);
        return;
    }
    
    $position = new Position($spawnPos->x, $spawnPos->y, $spawnPos->z, $level);
    $networkId = constant($entityClass . '::NETWORK_ID');
    
    $event = new EntityGenerateEvent($position, $networkId, EntityGenerateEvent::CAUSE_AI_HOLDER);
    $this->server->getPluginManager()->callEvent($event);
    
    if (!$event->isCancelled()) {
        $this->spawnEntityByType($entityClass, $event->getPosition());
    }
}

/**
 * 根据类型生成生物
 */
private function spawnEntityByType(string $entityClass, Position $position) {
    $spawnMethod = 'spawn' . (new \ReflectionClass($entityClass))->getShortName();
    if (method_exists($this, $spawnMethod)) {
        $this->$spawnMethod($position);
    }
}

/**
 * 统计各类实体数量
 */
private function countEntitiesByType(Level $level, array $entityClasses): array {
    $counts = [];
    foreach ($entityClasses as $class) {
        $counts[$class] = 0;
    }
    
    foreach ($level->getEntities() as $entity) {
        foreach ($entityClasses as $class) {
            if ($entity instanceof $class) {
                $counts[$class]++;
                break;
            }
        }
    }
    
    return $counts;
}

/**
 * 移除过多的实体
 */
private function removeExcessEntities(Level $level, string $entityClass, int $excessCount) {
    $entities = [];
    foreach ($level->getEntities() as $entity) {
        if ($entity instanceof $entityClass) {
            $entities[] = $entity;
        }
    }
    
    for ($i = 0; $i < min($excessCount, count($entities)); $i++) {
        $entities[$i]->kill();
    }
}

/**
 * 检查是否为水方块
 */
private function isWaterBlock(Level $level, Vector3 $pos): bool {
    $block = $level->getBlock($pos);
    return $block->getID() == 8 || $block->getID() == 9;
}

public function EntityDamage(EntityDamageEvent $event) {
    if($event instanceof EntityDamageByEntityEvent) {
        $p = $event->getDamager();
        $entity = $event->getEntity();
        if($entity instanceof Zombie) {
            $array = &$this->Zombie;
        } elseif($entity instanceof Creeper) {
            $array = &$this->Creeper;
        } elseif($entity instanceof Cow) {
            $array = &$this->Cow;
        } elseif($entity instanceof Pig) {
            $array = &$this->Pig;
        } elseif($entity instanceof Sheep) {
            $array = &$this->Sheep;
        } elseif($entity instanceof Chicken) {
            $array = &$this->Chicken;
        } elseif($entity instanceof Skeleton) {
            $array = &$this->Skeleton;
        } elseif($entity instanceof Spider) {
            $array = &$this->Spider;
        } elseif($entity instanceof Defult) {
            $array = &$this->Defult;
        } elseif($entity instanceof PigZombie) {
            $array = &$this->PigZombie;
        } elseif($entity instanceof Blaze) {
            $array = &$this->Blaze;
        } elseif($entity instanceof Ghast) {
            $array = &$this->Ghast;
        } elseif($entity instanceof LavaSlime) {
            $array = &$this->LavaSlime;
        } elseif($entity instanceof Squid) {
            $array = &$this->Squid;
        } else {
            $array = [];
        }
        
        if(isset($array[$entity->getId()])) {
            if($p instanceof Player and ($array[$entity->getId()]['canAttack'] == 0)) {
                $weapon = $p->getInventory()->getItemInHand()->getID();
                $high = 0;
                if($weapon == 258 or $weapon == 271 or $weapon == 275) {
                    $back = 1.5;
                } elseif($weapon == 267 or $weapon == 272 or $weapon == 279 or $weapon == 283 or $weapon == 286) {
                    $back = 3;
                } elseif($weapon == 276) {
                    $back = 4;
                } elseif($weapon == 292) {
                    $back = 8;
                    $high = 3;
                } else {
                    $back = 1;
                }
                
                $array[$entity->getId()]['x'] = $array[$entity->getId()]['x'] - $array[$entity->getId()]['xxx'] * $back;
                $array[$entity->getId()]['y'] = $entity->getY() + $high;
                $array[$entity->getId()]['z'] = $array[$entity->getId()]['z'] - $array[$entity->getId()]['zzz'] * $back;
                $entity->knockBack($entity, 0, $array[$entity->getId()]['xxx'] * $back, $array[$entity->getId()]['zzz'] * $back);
                
                if(isset($array[$entity->getId()])) {
                    $zom = &$array[$entity->getId()];
                    $zom['IsChasing'] = $p->getName();
                }
            }
        }
    }
}

/**
 * 获取生物生成的网络ID常量名称
 */
private function getEntityNetworkId(string $entityClass): int {
    $networkIds = [
        Zombie::class => Zombie::NETWORK_ID,
        Creeper::class => Creeper::NETWORK_ID,
        Skeleton::class => Skeleton::NETWORK_ID,
        Spider::class => Spider::NETWORK_ID,
        Cow::class => Cow::NETWORK_ID,
        Pig::class => Pig::NETWORK_ID,
        Sheep::class => Sheep::NETWORK_ID,
        Chicken::class => Chicken::NETWORK_ID,
        PigZombie::class => PigZombie::NETWORK_ID,
        Blaze::class => Blaze::NETWORK_ID,
        Ghast::class => Ghast::NETWORK_ID,
        LavaSlime::class => LavaSlime::NETWORK_ID,
        Squid::class => Squid::NETWORK_ID,
    ];
    
    return $networkIds[$entityClass] ?? 0;
}

public function knockBackover(Entity $entity, Vector3 $v3) {
    if($entity instanceof Entity) {
        if(isset($this->Zombie[$entity->getId()])) {
            $entity->setPosition($v3);
            $this->Zombie[$entity->getId()]['knockBack'] = false;
        }
        if(isset($this->Cow[$entity->getId()])) {
            $entity->setPosition($v3);
            $this->Cow[$entity->getId()]['knockBack'] = false;
        }
        if(isset($this->Pig[$entity->getId()])) {
            $entity->setPosition($v3);
            $this->Pig[$entity->getId()]['knockBack'] = false;
        }
                if(isset($this->Sheep[$entity->getId()])) {
            $entity->setPosition($v3);
            $this->Sheep[$entity->getId()]['knockBack'] = false;
        }
        if(isset($this->Chicken[$entity->getId()])) {
            $entity->setPosition($v3);
            $this->Chicken[$entity->getId()]['knockBack'] = false;
        }
        if(isset($this->Skeleton[$entity->getId()])) {
            $entity->setPosition($v3);
            $this->Skeleton[$entity->getId()]['knockBack'] = false;
        }
        if(isset($this->Creeper[$entity->getId()])) {
            $entity->setPosition($v3);
            $this->Creeper[$entity->getId()]['knockBack'] = false;
        }
        if(isset($this->Spider[$entity->getId()])) {
            $entity->setPosition($v3);
            $this->Spider[$entity->getId()]['knockBack'] = false;
        }
        if(isset($this->Defult[$entity->getId()])) {
            $entity->setPosition($v3);
            $this->Defult[$entity->getId()]['knockBack'] = false;
        }
        if(isset($this->PigZombie[$entity->getId()])) {
            $entity->setPosition($v3);
            $this->PigZombie[$entity->getId()]['knockBack'] = false;
        }
        if(isset($this->Blaze[$entity->getId()])) {
            $entity->setPosition($v3);
            $this->Blaze[$entity->getId()]['knockBack'] = false;
        }
        if(isset($this->Ghast[$entity->getId()])) {
            $entity->setPosition($v3);
            $this->Ghast[$entity->getId()]['knockBack'] = false;
        }
        if(isset($this->LavaSlime[$entity->getId()])) {
            $entity->setPosition($v3);
            $this->LavaSlime[$entity->getId()]['knockBack'] = false;
        }
        if(isset($this->Squid[$entity->getId()])) {
            $entity->setPosition($v3);
            $this->Squid[$entity->getId()]['knockBack'] = false;
        }
    }
}
}
