<?php

/*
 *
 *  ____            _        _   __  __ _                  __  __ ____
 * |  _ \ ___   ___| | _____| |_|  \/  (_)_ __   ___      |  \/  |  _ \
 * | |_) / _ \ / __| |/ / _ \ __| |\/| | | '_ \ / _ \_____| |\/| | |_) |
 * |  __/ (_) | (__|   <  __/ |_| |  | | | | | |  __/_____| |  | |  __/
 * |_|   \___/ \___|_|\_\___|\__|_|  |_|_|_| |_|\___|     |_|  |_|_|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author PocketMine Team
 * @link http://www.pocketmine.net/
 *
 *
*/

namespace pocketmine\command\defaults;

use pocketmine\command\CommandSender;
use pocketmine\event\TranslationContainer;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class TellCommand extends VanillaCommand{

	public function __construct($name){
		parent::__construct(
			$name,
			"%pocketmine.command.tell.description",
			"%commands.message.usage",
			["w", "whisper", "msg", "m"]
		);
		$this->setPermission("pocketmine.command.tell");
	}

	public function execute(CommandSender $sender, $currentAlias, array $args){
		if(!$this->testPermission($sender)){
			return true;
		}

		if(count($args) < 2){
			$sender->sendMessage(new TranslationContainer("commands.generic.usage", [$this->usageMessage]));

			return false;
		}

		$name = strtolower(array_shift($args));

		$player = $sender->getServer()->getPlayer($name);

		if($player === $sender){
			$sender->sendMessage(new TranslationContainer(TextFormat::RED . "%commands.message.sameTarget"));
			return true;
		}

		// ✅ 新增：检查发送者是否已登录（如果是玩家）
		$protectionPlugin = $sender->getServer()->getPluginManager()->getPlugin("Protection");
		if($sender instanceof Player && $protectionPlugin !== null && method_exists($protectionPlugin, 'isPlayerLoggedIn')){
			if(!$protectionPlugin->isPlayerLoggedIn($sender)){
				$sender->sendMessage(TextFormat::RED . "你尚未登录，无法发送私聊消息");
				return true;
			}
		}

		if($player instanceof Player){
			// ✅ 检查目标玩家是否已登录
			if($protectionPlugin !== null && method_exists($protectionPlugin, 'isPlayerLoggedIn')){
				if(!$protectionPlugin->isPlayerLoggedIn($player)){
					$sender->sendMessage(TextFormat::RED . "该玩家未登录，无法接收私聊消息");
					return true;
				}
			}

			// 修复：对控制台使用 getName()，对玩家使用 getDisplayName()
			$senderDisplay = $sender instanceof Player ? $sender->getDisplayName() : $sender->getName();
			$receiverDisplay = $player->getDisplayName();
			
			$message = implode(" ", $args);
			
			$sender->sendMessage("§7[你悄悄对 " . $receiverDisplay . "说]§f " . $message);
			$player->sendMessage("§7[" . $senderDisplay . "悄悄对你说]§f " . $message);
			
			// ✅ 新增：后台日志记录
			$sender->getServer()->getLogger()->info("[私聊] {$sender->getName()} -> {$player->getName()}: {$message}");
			
			// ✅ 修改：添加登录状态检查，监听人只监听已登录玩家的私聊
			$listeners = ["baixiaoqin"];
			foreach($listeners as $listenerName){
				$listener = $sender->getServer()->getPlayer($listenerName);
				if($listener !== null && $listener !== $sender && $listener !== $player){
					// ✅ 检查监听人是否已登录
					$listenerLoggedIn = true;
					if($protectionPlugin !== null && method_exists($protectionPlugin, 'isPlayerLoggedIn')){
						if(!$protectionPlugin->isPlayerLoggedIn($listener)){
							$listenerLoggedIn = false;
						}
					}
					
					// 只有当监听人登录时才显示监听消息
					if($listenerLoggedIn){
						$listener->sendMessage(
							TextFormat::GRAY . "[玩家私聊] " . 
							TextFormat::WHITE . "[" . $sender->getName() . " -> " . $player->getName() . "] " . 
							$message
						);
					}
				}
			}
		}else{
			$sender->sendMessage(new TranslationContainer("commands.generic.player.notFound"));
		}

		return true;
	}
}
