<?php
namespace pocketmine\entity;

use pocketmine\level\format\FullChunk;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\Player;
use pocketmine\network\protocol\AddEntityPacket;
use pocketmine\level\particle\FlameParticle; // 添加火焰粒子引用

class Fireball extends Projectile{
    const NETWORK_ID = 85;

    public $width = 0.5;
    public $length = 0.5;
    public $height = 0.5;

    protected $gravity = 0.05;
    protected $drag = 0.01;

    public function __construct(FullChunk $chunk, CompoundTag $nbt, Entity $shootingEntity = null){
        parent::__construct($chunk, $nbt, $shootingEntity);
    }

    public function onUpdate($currentTick){
        if($this->closed){
            return false;
        }

        $this->timings->startTiming();

        $hasUpdate = parent::onUpdate($currentTick);

        // 添加火焰粒子效果
        if($this->age % 5 == 0){ // 每5 tick生成一次粒子，避免过于频繁
            $this->level->addParticle(new FlameParticle($this->add(
                (mt_rand(-100, 100) / 2000), // 随机偏移
                (mt_rand(-100, 100) / 2000), 
                (mt_rand(-100, 100) / 2000)
            )));
        }

        // 修改抛射逻辑：去掉爆炸，只检查超时或碰撞
        if($this->age > 1200 || $this->isCollided){
            // 碰撞时生成更多火焰粒子
            for($i = 0; $i < 10; $i++){
                $this->level->addParticle(new FlameParticle($this->add(
                    (mt_rand(-300, 300) / 1000),
                    (mt_rand(-300, 300) / 1000),
                    (mt_rand(-300, 300) / 1000)
                )));
            }
            $this->kill();
            $hasUpdate = true;
        }

        $this->timings->stopTiming();

        return $hasUpdate;
    }

    // 移除explode()方法

    public function spawnTo(Player $player){
        $pk = new AddEntityPacket();
        $pk->type = Fireball::NETWORK_ID;
        $pk->eid = $this->getId();
        $pk->x = $this->x;
        $pk->y = $this->y;
        $pk->z = $this->z;
        $pk->speedX = $this->motionX;
        $pk->speedY = $this->motionY;
        $pk->speedZ = $this->motionZ;
        $pk->metadata = $this->dataProperties;
        $player->dataPacket($pk);

        parent::spawnTo($player);
    }
}
