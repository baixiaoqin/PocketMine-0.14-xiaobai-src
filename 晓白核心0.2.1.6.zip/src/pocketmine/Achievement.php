<?php

/*
 *
 *  ____            _        _   __  __ _                  __  __ ____
 * |  _ \ ___   ___| | _____| |_|  \/  (_)_ __   ___      |  \/  |  _ \
 * | |_) / _ \ / __| |/ / _ \ __| |\/| | | '_ \ / _ \_____| |\/| | |_) |
 * |  __/ (_) | (__|   <  __/ |_| |  | | | | | |  __/_____| |  | |  __/
 * |_|   \___/ \___|_|\_\___|\__|_|  |_|_|_| |_|\___|     |_|  |_|_|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author PocketMine Team
 * @link http://www.pocketmine.net/
 *
 *
*/

namespace pocketmine;

use pocketmine\event\TranslationContainer;
use pocketmine\utils\TextFormat;

/**
 * 处理成就列表及相关功能
 */
abstract class Achievement{
    /**
     * @var array[]
     */
    public static $list = [
        /*"openInventory" => array(
            "name" => "打开物品栏",
            "requires" => [],
        ),*/
        "mineWood" => [
            "name" => "获得木头",
            "requires" => [ //"openInventory",
            ],
        ],
        "buildWorkBench" => [
            "name" => "工作台",
            "requires" => [
                "mineWood",
            ],
        ],
        "buildPickaxe" => [
            "name" => "是时候挖矿了！",
            "requires" => [
                "buildWorkBench",
            ],
        ],
        "buildFurnace" => [
            "name" => "“热门话题”",
            "requires" => [
                "buildPickaxe",
            ],
        ],
        "acquireIron" => [
            "name" => "获得铁锭",
            "requires" => [
                "buildFurnace",
            ],
        ],
        "buildHoe" => [
            "name" => "是时候耕种了！",
            "requires" => [
                "buildWorkBench",
            ],
        ],
        "makeBread" => [
            "name" => "烤面包",
            "requires" => [
                "buildHoe",
            ],
        ],
        "bakeCake" => [
            "name" => "蛋糕是个谎言",
            "requires" => [
                "buildHoe",
            ],
        ],
        "buildBetterPickaxe" => [
            "name" => "获得升级",
            "requires" => [
                "buildPickaxe",
            ],
        ],
        "buildSword" => [
            "name" => "是时候攻击了！",
            "requires" => [
                "buildWorkBench",
            ],
        ],
        "diamonds" => [
            "name" => "钻石！",
            "requires" => [
                "acquireIron",
            ],
        ],

    ];


    public static function broadcast(Player $player, $achievementId){
        if(isset(Achievement::$list[$achievementId])){
            $translation = new TranslationContainer("chat.type.achievement", [$player->getDisplayName(), TextFormat::GREEN . Achievement::$list[$achievementId]["name"]]);
            if(Server::getInstance()->getConfigString("announce-player-achievements", true) === true){
                Server::getInstance()->broadcastMessage($translation);
            }else{
                $player->sendMessage($translation);
            }

            return true;
        }

        return false;
    }

    public static function add($achievementId, $achievementName, array $requires = []){
        if(!isset(Achievement::$list[$achievementId])){
            Achievement::$list[$achievementId] = [
                "name" => $achievementName,
                "requires" => $requires,
            ];

            return true;
        }

        return false;
    }
}