<?php

/*
 *  ______   _____    ______  __   __  ______
 * /  ___/  /  ___|  / ___  \ \ \ / / |  ____|
 * | |___  | |      | |___| |  \ / /  | |____
 * \___  \ | |      |  ___  |   / /   |  ____|
 *  ___| | | |____  | |   | |  / / \  | |____
 * /_____/  \_____| |_|   |_| /_/ \_\ |______|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author Sunch233#3226 QQ2125696621 And KKK
 * @link https://github.com/ScaxeTeam/Scaxe/
 *
*/

namespace pocketmine\block;

use pocketmine\event\block\BlockSpreadEvent;
use pocketmine\item\Item;
use pocketmine\item\Tool;
use pocketmine\item\enchantment\enchantment;
use pocketmine\level\generator\object\TallGrass as TallGrassObject;
use pocketmine\level\Level;
use pocketmine\math\Vector3;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\utils\Random;

class Grass extends Solid{

	protected $id = self::GRASS;

	public function __construct(){
		
	}

	public function canBeActivated() : bool{
		return true;
	}

	public function getName() : string{
		return "Grass";
	}

	public function getHardness(){
		return 0.6;
	}

	public function getToolType(){
		return Tool::TYPE_SHOVEL;
	}

	public function getDrops(Item $item) : array{
		if($item->getEnchantmentLevel(Enchantment::TYPE_MINING_SILK_TOUCH) > 0){
			return [
				[Item::GRASS, 0, 1],
			];
		}else{
			return [
				[Item::DIRT, 0, 1],
			];
		}
	}

	public function onUpdate($type){
		if($type === Level::BLOCK_UPDATE_RANDOM){
			/*$block = $this->getLevel()->getBlock(new Vector3($this->x, $this->y, $this->z));
			if($block->getSide(1)->getLightLevel() < 4){
				Server::getInstance()->getPluginManager()->callEvent($ev = new BlockSpreadEvent($block, $this, new Dirt()));
			}elseif($block->getSide(1)->getLightLevel() >= 9){
				for($l = 0; $l < 4; ++$l){
					$x = mt_rand($this->x - 1, $this->x + 1);
					$y = mt_rand($this->y - 2, $this->y + 2);
					$z = mt_rand($this->z - 1, $this->z + 1);
					$block = $this->getLevel()->getBlock(new Vector3($x, $y, $z));
					if($block->getId() === Block::DIRT && $block->getDamage() === 0x0F && $block->getSide(1)->getLightLevel() >= 4 && $block->z <= 2){
						Server::getInstance()->getPluginManager()->callEvent($ev = new BlockSpreadEvent($block, $this, new Grass()));
						if(!$ev->isCancelled()){
							$this->getLevel()->setBlock($block, $ev->getNewState());
						}
					}
				}
			}*/
			if(mt_rand(0, 1) == 1){
				$lightAbove = $this->level->getFullLightAt($this->x, $this->y + 1, $this->z);
				//echo($lightAbove."阳光强度\n");
				if($lightAbove < 4 and Block::$lightFilter[$this->level->getBlockIdAt($this->x, $this->y + 1, $this->z)] >= 3){ //2 plus 1 standard filter amount
					//grass dies
					$this->level->getServer()->getPluginManager()->callEvent($ev = new BlockSpreadEvent($this, $this, new Dirt()));
					if(!$ev->isCancelled()){
						$this->level->setBlock($this, $ev->getNewState(), false, false);
					}

					return Level::BLOCK_UPDATE_RANDOM;
				}elseif($lightAbove >= 9){
					//try grass spread
					for($i = 0; $i < 4; ++$i){
						$x = mt_rand($this->x - 1, $this->x + 1);
						$y = mt_rand($this->y - 3, $this->y + 1);
						$z = mt_rand($this->z - 1, $this->z + 1);
						if(
							$this->level->getBlockIdAt($x, $y, $z) !== Block::DIRT or
							$this->level->getBlockDataAt($x, $y, $z) === 1 or
							$this->level->getFullLightAt($x, $y + 1, $z) < 4 or
							Block::$lightFilter[$this->level->getBlockIdAt($x, $y + 1, $z)] >= 3
						){
							continue;
						}
						$block = $this->getLevel()->getBlock(new Vector3($x, $y, $z));
						if($block->getSide(1)->getID() == 0){
							$this->level->getServer()->getPluginManager()->callEvent($ev = new BlockSpreadEvent($block, $this, new Grass()));
							if(!$ev->isCancelled()){
								$this->level->setBlock($block, $ev->getNewState(), false, false);
							}
						}
					}

					return Level::BLOCK_UPDATE_RANDOM;
				}
			}
		}
		
	}

	public function onActivate(Item $item, Player $player = null){
		if($item->getId() === Item::DYE and $item->getDamage() === 0x0F){
			$item->count--;
			TallGrassObject::growGrass($this->getLevel(), $this, new Random(mt_rand()), 8, 2);

			return true;
		}elseif($item->isHoe()){
			$item->useOn($this, 2);
			$this->getLevel()->setBlock($this, new Farmland());

			return true;
		}elseif($item->isShovel() and $this->getSide(1)->getId() === Block::AIR){
			$item->useOn($this, 2);
			$this->getLevel()->setBlock($this, new GrassPath());

			return true;
		}

		return false;
	}
}
