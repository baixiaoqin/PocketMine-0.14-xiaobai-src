<?php

/*
 *  ______   _____    ______  __   __  ______
 * /  ___/  /  ___|  / ___  \ \ \ / / |  ____|
 * | |___  | |      | |___| |  \ / /  | |____
 * \___  \ | |      |  ___  |   / /   |  ____|
 *  ___| | | |____  | |   | |  / / \  | |____
 * /_____/  \_____| |_|   |_| /_/ \_\ |______|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author Sunch233#3226 QQ2125696621 And KKK
 * @link https://github.com/ScaxeTeam/Scaxe/
 *
*/

namespace pocketmine\block;

class RedSandstone extends Sandstone{
	protected $id = Block::RED_SANDSTONE;
	
	public function getName() : string{
		static $names = [
			0 => "Red Sandstone",
			1 => "Chiseled Red Sandstone",
			2 => "Smooth Red Sandstone",
			3 => "",
		];
		return $names[$this->meta & 0x03];
	}
}