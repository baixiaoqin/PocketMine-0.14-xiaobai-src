<?php

/*
 *  ______   _____    ______  __   __  ______
 * /  ___/  /  ___|  / ___  \ \ \ / / |  ____|
 * | |___  | |      | |___| |  \ / /  | |____
 * \___  \ | |      |  ___  |   / /   |  ____|
 *  ___| | | |____  | |   | |  / / \  | |____
 * /_____/  \_____| |_|   |_| /_/ \_\ |______|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author Sunch233#3226 QQ2125696621 And KKK
 * @link https://github.com/ScaxeTeam/Scaxe/
 *
*/

namespace pocketmine\block;

use pocketmine\item\Item;
use pocketmine\item\Tool;
use pocketmine\level\Level;
use pocketmine\Player;

class TallGrass extends Flowable{

    protected $id = self::TALL_GRASS;

    public function __construct($meta = 1){
        $this->meta = $meta;
    }

    public function canBeReplaced(){
        return true;
    }

    public function getName() : string{
        static $names = [
            0 => "Dead Shrub",
            1 => "Tall Grass",
            2 => "Fern",
            3 => ""
        ];
        return $names[$this->meta & 0x03];
    }

    public function getBurnChance() : int{
        return 60;
    }

    public function getBurnAbility() : int{
        return 100;
    }

    public function place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null){
        $down = $this->getSide(0);
        if($down->getId() === self::GRASS || $down->getId() === self::DIRT){
            $this->getLevel()->setBlock($block, $this, true);
            return true;
        }

        return false;
    }

    public function onUpdate($type){
        if($type === Level::BLOCK_UPDATE_NORMAL){
            if($this->getSide(0)->isTransparent() === true){
                $this->getLevel()->setBlock($this, new Air(), false, false);
                return Level::BLOCK_UPDATE_NORMAL;
            }
        }

        return false;
    }

    public function getToolType(){
        return Tool::TYPE_SHEARS;
    }

    public function getHardness(){
        return 0.1; // 降低硬度，使徒手也能破坏
    }

    public function getResistance(){
        return 0.5;
    }

    public function getDrops(Item $item) : array {
        // 使用剪刀破坏时掉落高草本身
        if($item->getId() === Item::SHEARS){
            return [
                [Item::TALL_GRASS, $this->meta & 0x03, 1]
            ];
        }
        
        // 非剪刀破坏时，随机掉落种子（原版概率约为12.5%）
        if(mt_rand(0, 7) === 0){
            return [
                [Item::WHEAT_SEEDS, 0, 1]
            ];
        }

        return [];
    }

    /**
     * 重写此方法确保任何工具（包括徒手）都能破坏方块
     */
    public function isCompatibleWithTool(Item $tool) : bool{
        // 允许任何工具（包括徒手）破坏高草
        return true;
    }
    
    /**
     * 获取最佳工具类型
     */
    public function getHarvestTool() : int{
        return Tool::TYPE_SHEARS; // 最佳工具是剪刀
    }
    
    /**
     * 获取最佳工具等级
     */
    public function getHarvestLevel() : int{
        return 0; // 任何等级的剪刀都可以
    }
}
