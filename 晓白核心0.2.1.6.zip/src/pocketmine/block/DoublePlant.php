<?php

namespace pocketmine\block;

use pocketmine\item\Item;
use pocketmine\level\Level;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\item\Tool;

class DoublePlant extends Flowable{

    protected $id = self::DOUBLE_PLANT;

    public function __construct($meta = 0){
        $this->meta = $meta;
    }

    public function canBeReplaced(){
        return true;
    }

    public function getName() : string{
        static $names = [
            0 => "Sunflower",
            1 => "Lilac", 
            2 => "Double Tallgrass",
            3 => "Large Fern",
            4 => "Rose Bush",
            5 => "Peony"
        ];
        return $names[$this->meta & 0x07];
    }

    public function onUpdate($type){
        if($type === Level::BLOCK_UPDATE_NORMAL){
            if($this->getSide(Vector3::SIDE_DOWN)->isTransparent() && !$this->getSide(Vector3::SIDE_DOWN) instanceof DoublePlant){
                $this->getLevel()->setBlock($this, new Air(), false, false);
                return Level::BLOCK_UPDATE_NORMAL;
            }
        }
        return false;
    }

    public function place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null){
        $down = $this->getSide(Vector3::SIDE_DOWN);
        $up = $this->getSide(Vector3::SIDE_UP);
        
        if($down->getId() === self::GRASS || $down->getId() === self::DIRT){
            if($up->canBeReplaced()){
                $this->getLevel()->setBlock($block, $this, true);
                $this->getLevel()->setBlock($up, Block::get($this->id, $this->meta ^ 0x08), true);
                return true;
            }
        }
        return false;
    }

    public function onBreak(Item $item){
        $up = $this->getSide(Vector3::SIDE_UP);
        $down = $this->getSide(Vector3::SIDE_DOWN);
        
        if(($this->meta & 0x08) === 0x08){ // 顶部部分
            if($down->getId() === $this->id && ($down->meta & 0x08) === 0x00){
                $this->getLevel()->setBlock($down, new Air(), true, true);
            }
        }else{ // 底部部分
            if($up->getId() === $this->id && ($up->meta & 0x08) === 0x08){
                $this->getLevel()->setBlock($up, new Air(), true, true);
            }
        }
        
        $this->getLevel()->setBlock($this, new Air(), true, true);
        return true;
    }

    public function getDrops(Item $item) : array{
        // 只有底部部分才有掉落
        if(($this->meta & 0x08) === 0x08){
            return [];
        }

        $plantType = $this->meta & 0x07;
        
        // 高草丛（Double Tallgrass）和大型蕨（Large Fern）需要剪刀才能掉落
        if($plantType === 2 || $plantType === 3){ // 2 = Double Tallgrass, 3 = Large Fern
            if($item->getId() === Item::SHEARS){ // 使用剪刀破坏
                return [[Item::DOUBLE_PLANT, $plantType, 1]];
            }else{ // 非剪刀破坏，不掉落任何东西
                return [];
            }
        }
        
        // 其他双高植物正常掉落
        return [[Item::DOUBLE_PLANT, $plantType, 1]];
    }

    /**
     * 获取适当的硬度
     */
    public function getHardness(){
        return 0.0;
    }

    /**
     * 获取适当的工具类型
     */
    public function getToolType(){
        return Tool::TYPE_SHEARS;
    }

    /**
     * 获取破坏所需的最低工具层级
     */
    public function getToolHarvestLevel(){
        return 0;
    }
}
