<?php

/*
 *  ______   _____    ______  __   __  ______
 * /  ___/  /  ___|  / ___  \ \ \ / / |  ____|
 * | |___  | |      | |___| |  \ / /  | |____
 * \___  \ | |      |  ___  |   / /   |  ____|
 *  ___| | | |____  | |   | |  / / \  | |____
 * /_____/  \_____| |_|   |_| /_/ \_\ |______|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author Sunch233#3226 QQ2125696621 And KKK
 * @author PocketMine Team
 * @link https://github.com/ScaxeTeam/Scaxe/
 * @link http://www.pocketmine.net/
 *
*/

namespace pocketmine\block;

use pocketmine\entity\Entity;
use pocketmine\item\Item;
use pocketmine\level\Level;
use pocketmine\level\sound\TNTPrimeSound;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\Player;
use pocketmine\utils\Random;

class TNT extends Solid implements ElectricalAppliance{

    protected $id = self::TNT;

    public function __construct(){
        // 构造函数
    }

    public function getName() : string{
        return "TNT";
    }

    public function getHardness(){
        return 0;
    }

    public function canBeActivated() : bool{
        return true;
    }

    public function getBurnChance() : int{
        return 15;
    }

    public function getBurnAbility() : int{
        return 100;
    }

    /**
     * 引爆TNT
     * @param Player|null $player 引爆炸药的玩家（用于判断创造模式）
     */
    public function prime(Player $player = null){
        $this->meta = 1;
        
        // 判断是否掉落物品：创造模式不掉落，生存模式掉落
        $dropItem = !($player !== null && $player->isCreative());
        
        // 生成随机运动方向
        $mot = (new Random())->nextSignedFloat() * M_PI * 2;
        
        // 创建TNT实体
        $tnt = Entity::createEntity("PrimedTNT", $this->getLevel()->getChunk($this->x >> 4, $this->z >> 4), new CompoundTag("", [
            "Pos" => new ListTag("Pos", [
                new DoubleTag("", $this->x + 0.5),
                new DoubleTag("", $this->y),
                new DoubleTag("", $this->z + 0.5)
            ]),
            "Motion" => new ListTag("Motion", [
                new DoubleTag("", -sin($mot) * 0.02),
                new DoubleTag("", 0.2),
                new DoubleTag("", -cos($mot) * 0.02)
            ]),
            "Rotation" => new ListTag("Rotation", [
                new FloatTag("", 0),
                new FloatTag("", 0)
            ]),
            "Fuse" => new ByteTag("Fuse", 80)
        ]), $dropItem);

        if($tnt !== null){
            $tnt->spawnToAll();
            $this->level->addSound(new TNTPrimeSound($this));
        }
    }

    public function onUpdate($type){
        if($type == Level::BLOCK_UPDATE_SCHEDULED){
            // 检查周围6个方向的红石信号
            $sides = [Vector3::SIDE_DOWN, Vector3::SIDE_UP, Vector3::SIDE_NORTH, Vector3::SIDE_SOUTH, Vector3::SIDE_WEST, Vector3::SIDE_EAST];
            
            foreach($sides as $side){
                $block = $this->getSide($side);
                if($block instanceof RedstoneSource && $block->isActivated($this)){
                    $this->prime();
                    $this->getLevel()->setBlock($this, new Air(), true);
                    break;
                }
            }
            return Level::BLOCK_UPDATE_SCHEDULED;
        }
        return false;
    }

    public function place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null){
        $this->getLevel()->setBlock($this, $this, true, false);
        // 安排更新检查，延迟40tick
        $this->getLevel()->scheduleUpdate($this, 40);
        return true;
    }

    public function onActivate(Item $item, Player $player = null){
        if($item->getId() === Item::FLINT_STEEL){
            $this->prime($player);
            $this->getLevel()->setBlock($this, new Air(), true);
            
            // 使用打火石，消耗耐久度
            $item->useOn($this, 2);
            
            return true;
        }

        return false;
    }

    /**
     * 获取TNT的爆炸抗性
     */
    public function getBlastResistance() : float{
        return 0;
    }
}
