<?php
/*⏩bai制作⏪*/
namespace pocketmine\command\defaults;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\TranslationContainer;
use pocketmine\Player;
use pocketmine\utils\TextFormat;
use pocketmine\math\Vector3;
use pocketmine\item\ItemBlock;
use pocketmine\item\Item;
use pocketmine\level\Level;

class FillCommand extends VanillaCommand{

    private $selection = [];

    public function __construct($name){
        parent::__construct(
            $name,
            "%pocketmine.command.fill.description",
            "%commands.fill.usage"
        );
        $this->setPermission("pocketmine.command.fill");
    }

    public function execute(CommandSender $sender, $label, array $args){
        if(!$this->testPermission($sender)){
            return true;
        }

        if(count($args) === 0){
            $this->showHelp($sender);
            return true;
        }

        if(count($args) >= 7 && is_numeric($args[0]) && is_numeric($args[1]) && is_numeric($args[2]) && 
           is_numeric($args[3]) && is_numeric($args[4]) && is_numeric($args[5])){
            return $this->handleTraditionalFormat($sender, $args);
        }

        $subCommand = strtolower(array_shift($args));
        switch($subCommand){
            case "帮助":
                $this->showHelp($sender);
                return true;
                
            case "add1":
                if($sender instanceof Player){
                    $this->selection[$sender->getName()]["pos1"] = $sender->getPosition();
                    $sender->sendMessage(TextFormat::GREEN . "起点已设置为: " . $this->formatVector($sender->getPosition()));
                    return true;
                }else{
                    $sender->sendMessage(TextFormat::RED . "此命令只能在游戏中使用");
                    return false;
                }
                
            case "add2":
                if($sender instanceof Player){
                    $this->selection[$sender->getName()]["pos2"] = $sender->getPosition();
                    $sender->sendMessage(TextFormat::GREEN . "终点已设置为: " . $this->formatVector($sender->getPosition()));
                    return true;
                }else{
                    $sender->sendMessage(TextFormat::RED . "此命令只能在游戏中使用");
                    return false;
                }
                
            case "del":
                if(isset($this->selection[$sender->getName()])){
                    unset($this->selection[$sender->getName()]);
                    $sender->sendMessage(TextFormat::GREEN . "已取消选择");
                }else{
                    $sender->sendMessage(TextFormat::RED . "没有选择可取消");
                }
                return true;
                
            case "set":
                if(!$sender instanceof Player){
                    $sender->sendMessage(TextFormat::RED . "此命令只能在游戏中使用");
                    return false;
                }
                
                if(!isset($this->selection[$sender->getName()]["pos1"]) || !isset($this->selection[$sender->getName()]["pos2"])){
                    $sender->sendMessage(TextFormat::RED . "请先设置起点和终点");
                    return false;
                }
                
                if(count($args) < 1){
                    $sender->sendMessage(TextFormat::RED . "请指定方块ID");
                    return false;
                }
                
                // 支持带冒号的方块ID格式
                $input = $args[0];
                $meta = 0;
                
                // 检查是否包含冒号格式
                if(strpos($input, ':') !== false){
                    $parts = explode(':', $input, 2);
                    $input = $parts[0];
                    $meta = (int)$parts[1];
                }
                // 如果单独提供了数据值参数，覆盖冒号格式的值
                if(isset($args[1])){
                    $meta = (int)$args[1];
                }
                
                $item = Item::fromString($input);
                if(!$item instanceof ItemBlock){
                    $sender->sendMessage(TextFormat::RED . $input . " 不是有效的方块");
                    return false;
                }
                
                return $this->fillArea(
                    $sender,
                    $this->selection[$sender->getName()]["pos1"],
                    $this->selection[$sender->getName()]["pos2"],
                    $item,
                    $meta
                );
                
            default:
                $this->showHelp($sender);
                return false;
        }
    }
    
    // 修复传统格式支持
    private function handleTraditionalFormat(CommandSender $sender, array $args){
        $x1 = (int)$args[0];
        $y1 = (int)$args[1];
        $z1 = (int)$args[2];
        $x2 = (int)$args[3];
        $y2 = (int)$args[4];
        $z2 = (int)$args[5];
        
        // 支持带冒号的方块ID格式
        $input = $args[6];
        $meta = 0;
        
        // 检查是否包含冒号格式
        if(strpos($input, ':') !== false){
            $parts = explode(':', $input, 2);
            $input = $parts[0];
            $meta = (int)$parts[1];
        }
        // 如果单独提供了数据值参数，覆盖冒号格式的值
        if(isset($args[7])){
            $meta = (int)$args[7];
        }
        
        // 获取方块
        $item = Item::fromString($input);
        if(!$item instanceof ItemBlock){
            $sender->sendMessage(TextFormat::RED . $input . " 不是有效的方块");
            return false;
        }
        
        $pos1 = new Vector3($x1, $y1, $z1);
        $pos2 = new Vector3($x2, $y2, $z2);
        
        // 如果是控制台，直接使用坐标
        if(!($sender instanceof Player)){
            return $this->fillArea($sender, $pos1, $pos2, $item, $meta);
        }
        
        // 如果是玩家，可以添加额外信息
        $sender->sendMessage(TextFormat::YELLOW . "正在填充从 " . $this->formatVector($pos1) . " 到 " . $this->formatVector($pos2) . " 的区域...");
        return $this->fillArea($sender, $pos1, $pos2, $item, $meta);
    }
    
    private function showHelp(CommandSender $sender){
        $sender->sendMessage(TextFormat::GOLD . "===== Fill 填充指令帮助 =====");
        $sender->sendMessage(TextFormat::WHITE . "/fill 帮助 - 显示此帮助信息");
        $sender->sendMessage(TextFormat::WHITE . "/fill add1 - 设置填充区域的起点（当前位置）");
        $sender->sendMessage(TextFormat::WHITE . "/fill add2 - 设置填充区域的终点（当前位置）");
        $sender->sendMessage(TextFormat::WHITE . "/fill del - 取消当前选择区域");
        $sender->sendMessage(TextFormat::WHITE . "/fill set <方块ID> - 用指定方块填充选择区域");
        $sender->sendMessage(TextFormat::GRAY . "交互式示例: /fill set stone 或 /fill set 1 或 /fill set 159:11");
        $sender->sendMessage(TextFormat::WHITE . "/fill <x1> <y1> <z1> <x2> <y2> <z2> <方块ID> [数据值] - 直接使用坐标填充");
        $sender->sendMessage(TextFormat::GRAY . "传统示例: /fill 10 64 10 20 70 20 stone 或 /fill 10 64 10 20 70 20 1 0 或 /fill 10 64 10 20 70 20 159:11");
    }
    
    private function fillArea(CommandSender $sender, Vector3 $pos1, Vector3 $pos2, ItemBlock $item, int $meta = 0) : bool {
        $xmin = min($pos1->x, $pos2->x);
        $xmax = max($pos1->x, $pos2->x);
        $ymin = min($pos1->y, $pos2->y);
        $ymax = max($pos1->y, $pos2->y);
        $zmin = min($pos1->z, $pos2->z);
        $zmax = max($pos1->z, $pos2->z);
        
        $level = $sender->getLevel();
        $n = 0;
        $nmax = ($xmax - $xmin + 1) * ($ymax - $ymin + 1) * ($zmax - $zmin + 1);
        
        $sender->sendMessage(TextFormat::YELLOW . "开始清空选择区域...");
        
        // 首先清空选择区域（设置为 AIR）
        for($x = $xmin; $x <= $xmax; $x++){
            for($y = $ymin; $y <= $ymax; $y++){
                for($z = $zmin; $z <= $zmax; $z++){
                    if(!$level->setBlock(new Vector3($x, $y, $z), Item::get(Item::AIR)->getBlock())){
                        // 继续执行而不是返回，尽量完成操作
                    }
                    $n++;
                    
                    if($n % 10000 === 0){
                        $sender->sendMessage(TextFormat::AQUA . "已清空 $n / $nmax 个方块");
                    }
                }
            }
        }
        
        $sender->sendMessage(TextFormat::YELLOW . "开始填充区域...");
        $n = 0; // 重置计数器
        
        // 然后填充新方块
        for($x = $xmin; $x <= $xmax; $x++){
            for($y = $ymin; $y <= $ymax; $y++){
                for($z = $zmin; $z <= $zmax; $z++){
                    if(!$this->setBlock(new Vector3($x, $y, $z), $level, $item, $meta)){
                        $sender->sendMessage(TextFormat::RED . "填充区域时出错，已填充 $n 个方块");
                        return false;
                    }
                    $n++;
                    
                    if($n % 10000 === 0){
                        $sender->sendMessage(TextFormat::AQUA . "已填充 $n / $nmax 个方块，当前位置: $x, $y, $z");
                    }
                }
            }
        }
        
        $sender->sendMessage(TextFormat::GREEN . "填充完成！⏩总共处理了 $nmax 个方块⏪（先清空后填充）");
        return true;
    }
    
    private function formatVector(Vector3 $vector) : string {
        return "(" . $vector->x . ", " . $vector->y . ", " . $vector->z . ")";
    }

    private function setBlock(Vector3 $p, Level $lvl, ItemBlock $b, int $meta = 0) : bool{
        $block = $b->getBlock();
        $block->setDamage($meta);
        return $lvl->setBlock($p, $block);
    }
}
