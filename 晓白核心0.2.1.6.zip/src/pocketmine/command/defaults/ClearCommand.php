<?php

/*
 *  ______   _____    ______  __   __  ______
 * /  ___/  /  ___|  / ___  \ \ \ / / |  ____|
 * | |___  | |      | |___| |  \ / /  | |____
 * \___  \ | |      |  ___  |   / /   |  ____|
 *  ___| | | |____  | |   | |  / / \  | |____
 * /_____/  \_____| |_|   |_| /_/ \_\ |______|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author Sunch233#3226 QQ2125696621 And KKK
 * @link https://github.com/ScaxeTeam/Scaxe/
 *
*/

namespace pocketmine\command\defaults;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\TranslationContainer;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class ClearCommand extends VanillaCommand {

    public function __construct($name){
        parent::__construct(
            $name,
            "清理玩家背包中的物品",
            "/clear [玩家|all] [物品ID[:损伤值]] [数量]",
            ["clearitem"]
        );
        $this->setPermission("pocketmine.command.clear");
    }

    public function execute(CommandSender $sender, $currentAlias, array $args){
        if(!$this->testPermission($sender)){
            return true;
        }

        if(count($args) === 0){
            $this->showHelp($sender);
            return true;
        }

        // 帮助信息
        if(isset($args[0]) && $args[0] === "help"){
            $this->showHelp($sender);
            return true;
        }

        // 如果只有一个参数，认为是清理整个背包
        if(count($args) === 1){
            return $this->clearInventoryCommand($sender, $args);
        }

        // 如果有两个或更多参数，认为是清理特定物品
        return $this->clearItemCommand($sender, $args);
    }

    /**
     * 清理特定物品命令
     */
    private function clearItemCommand(CommandSender $sender, array $args){
        // 参数验证
        if(count($args) < 2){
            $sender->sendMessage(TextFormat::RED . "用法: /clear <玩家|all> <物品ID[:损伤值]> [数量]");
            $sender->sendMessage(TextFormat::GRAY . "示例: /clear Steve 1 - 清理Steve的所有石头");
            $sender->sendMessage(TextFormat::GRAY . "示例: /clear all 159:11 - 清理所有玩家的蓝色粘土");
            return false;
        }

        $targetName = $args[0];
        $itemInput = $args[1];
        $amount = isset($args[2]) ? (int)$args[2] : null;

        // 解析物品ID和损伤值
        $itemData = $this->parseItemInput($itemInput);
        if($itemData === null){
            $sender->sendMessage(TextFormat::RED . "无效的物品格式，请使用 物品ID 或 物品ID:损伤值");
            return false;
        }

        list($itemId, $damage) = $itemData;

        // 验证物品ID
        if($itemId <= 0){
            $sender->sendMessage(TextFormat::RED . "无效的物品ID");
            return false;
        }

        // 验证数量
        if($amount !== null && ($amount <= 0 || $amount > 2304)){
            $sender->sendMessage(TextFormat::RED . "数量必须在1-2304之间");
            return false;
        }

        $clearedPlayers = [];
        $totalCleared = 0;

        // 处理目标玩家
        if(strtolower($targetName) === "all"){
            // 清理所有在线玩家
            foreach($sender->getServer()->getOnlinePlayers() as $player){
                $result = $this->clearPlayerItem($player, $itemId, $damage, $amount);
                if($result['cleared'] > 0){
                    $clearedPlayers[] = $player->getName();
                    $totalCleared += $result['cleared'];
                    
                    // 通知被清理的玩家
                    $player->sendMessage(TextFormat::YELLOW . "管理员清理了你的 " . 
                        $result['item_name'] . TextFormat::YELLOW . " x" . $result['cleared']);
                }
            }
        } else {
            // 清理指定玩家
            $targetPlayer = $sender->getServer()->getPlayer($targetName);
            if($targetPlayer === null){
                $sender->sendMessage(TextFormat::RED . "玩家 " . $targetName . " 不在线或不存在");
                return false;
            }

            $result = $this->clearPlayerItem($targetPlayer, $itemId, $damage, $amount);
            if($result['cleared'] > 0){
                $clearedPlayers[] = $targetPlayer->getName();
                $totalCleared = $result['cleared'];
                
                // 通知被清理的玩家
                $targetPlayer->sendMessage(TextFormat::YELLOW . "管理员清理了你的 " . 
                    $result['item_name'] . TextFormat::YELLOW . " x" . $result['cleared']);
            }
        }

        // 发送结果消息
        if(count($clearedPlayers) > 0){
            $itemName = $this->getItemName($itemId, $damage);
            $message = TextFormat::GREEN . "成功清理 " . implode(", ", $clearedPlayers) . 
                      " 的 " . $itemName . TextFormat::GREEN . " 总计: " . $totalCleared . "个";
            $sender->sendMessage($message);

            // 广播消息（当清理多个玩家时）
            if(count($clearedPlayers) > 1){
                $sender->getServer()->broadcastMessage(
                    TextFormat::AQUA . "[清理] " . TextFormat::WHITE . 
                    "管理员清理了 " . $itemName . " 总计: " . $totalCleared . "个"
                );
            }

            // 记录日志
            $sender->getServer()->getLogger()->info(
                $sender->getName() . " 清理了 " . implode(", ", $clearedPlayers) . 
                " 的 " . $itemName . " x" . $totalCleared
            );
        } else {
            $sender->sendMessage(TextFormat::YELLOW . "没有找到需要清理的物品");
        }

        return true;
    }

    /**
     * 清理整个背包命令
     */
    private function clearInventoryCommand(CommandSender $sender, array $args){
        $targetName = $args[0];
        $clearedPlayers = [];

        // 处理目标玩家
        if(strtolower($targetName) === "all"){
            // 清理所有在线玩家的背包
            foreach($sender->getServer()->getOnlinePlayers() as $player){
                $this->clearPlayerInventory($player);
                $clearedPlayers[] = $player->getName();
                
                // 通知被清理的玩家
                $player->sendMessage(TextFormat::YELLOW . "管理员清理了你的整个背包");
            }
        } else {
            // 清理指定玩家
            $targetPlayer = $sender->getServer()->getPlayer($targetName);
            if($targetPlayer === null){
                $sender->sendMessage(TextFormat::RED . "玩家 " . $targetName . " 不在线或不存在");
                return false;
            }

            $this->clearPlayerInventory($targetPlayer);
            $clearedPlayers[] = $targetPlayer->getName();
            
            // 通知被清理的玩家
            $targetPlayer->sendMessage(TextFormat::YELLOW . "管理员清理了你的整个背包");
        }

        // 发送结果消息
        $message = TextFormat::GREEN . "成功清理 " . implode(", ", $clearedPlayers) . " 的背包";
        $sender->sendMessage($message);

        // 广播消息（当清理多个玩家时）
        if(count($clearedPlayers) > 1){
            $sender->getServer()->broadcastMessage(
                TextFormat::AQUA . "[清理] " . TextFormat::WHITE . 
                "管理员清理了 " . count($clearedPlayers) . " 个玩家的背包"
            );
        }

        // 记录日志
        $sender->getServer()->getLogger()->info(
            $sender->getName() . " 清理了 " . implode(", ", $clearedPlayers) . " 的背包"
        );

        return true;
    }

    /**
     * 显示帮助信息
     */
    private function showHelp(CommandSender $sender){
        $sender->sendMessage(TextFormat::GOLD . "=== Clear命令帮助 ===");
        $sender->sendMessage(TextFormat::GREEN . "/clear [玩家|all]");
        $sender->sendMessage(TextFormat::GRAY . "  - 清理指定玩家或所有玩家的整个背包");
        $sender->sendMessage(TextFormat::GRAY . "  - 示例: /clear Steve - 清理Steve的整个背包");
        $sender->sendMessage(TextFormat::GRAY . "  - 示例: /clear all - 清理所有玩家的整个背包");
        
        $sender->sendMessage(TextFormat::GREEN . "/clear <玩家|all> <物品ID[:损伤值]> [数量]");
        $sender->sendMessage(TextFormat::GRAY . "  - 清理指定玩家或所有玩家的特定物品");
        $sender->sendMessage(TextFormat::GRAY . "  - 示例: /clear Steve 1 - 清理Steve的所有石头");
        $sender->sendMessage(TextFormat::GRAY . "  - 示例: /clear all 159:11 - 清理所有玩家的蓝色粘土");
        $sender->sendMessage(TextFormat::GRAY . "  - 示例: /clear all 264 64 - 清理所有玩家的钻石，最多64个");
        $sender->sendMessage(TextFormat::GOLD . "======================");
    }

    /**
     * 解析物品输入（支持 ID 或 ID:Damage 格式）
     */
    private function parseItemInput(string $input): ?array{
        if(strpos($input, ':') !== false){
            $parts = explode(':', $input);
            if(count($parts) === 2 && is_numeric($parts[0]) && is_numeric($parts[1])){
                return [(int)$parts[0], (int)$parts[1]];
            }
        } elseif(is_numeric($input)){
            return [(int)$input, -1]; // -1 表示不限制损伤值
        }
        
        return null;
    }

    /**
     * 清理玩家背包中的特定物品
     */
    private function clearPlayerItem(Player $player, int $itemId, int $damage = -1, ?int $maxAmount = null): array{
        $inventory = $player->getInventory();
        $clearedAmount = 0;
        
        // 遍历所有物品栏位
        for($i = 0; $i < $inventory->getSize(); $i++){
            $item = $inventory->getItem($i);
            
            // 检查物品ID和损伤值是否匹配
            $matchesId = ($item->getId() === $itemId);
            $matchesDamage = ($damage === -1 || $item->getDamage() === $damage);
            
            if($matchesId && $matchesDamage && $item->getCount() > 0){
                $toClear = $item->getCount();
                
                // 如果指定了最大清理数量
                if($maxAmount !== null){
                    $toClear = min($toClear, $maxAmount - $clearedAmount);
                    if($toClear <= 0) break;
                }
                
                if($toClear === $item->getCount()){
                    // 清理整个堆叠
                    $inventory->setItem($i, Item::get(Item::AIR));
                } else {
                    // 清理部分数量
                    $item->setCount($item->getCount() - $toClear);
                    $inventory->setItem($i, $item);
                }
                
                $clearedAmount += $toClear;
                
                // 如果达到最大清理数量，停止清理
                if($maxAmount !== null && $clearedAmount >= $maxAmount){
                    break;
                }
            }
        }
        
        // 更新玩家库存
        $inventory->sendContents($player);
        
        return [
            'cleared' => $clearedAmount,
            'item_name' => $this->getItemName($itemId, $damage)
        ];
    }

    /**
     * 清理玩家整个背包
     */
    private function clearPlayerInventory(Player $player){
        $inventory = $player->getInventory();
        
        // 清理所有物品栏位
        for($i = 0; $i < $inventory->getSize(); $i++){
            $inventory->setItem($i, Item::get(Item::AIR));
        }
        
        // 清理装备栏
        $this->clearArmorSlot($player, 'setBoots');
        $this->clearArmorSlot($player, 'setLeggings');
        $this->clearArmorSlot($player, 'setChestplate');
        $this->clearArmorSlot($player, 'setHelmet');
        
        // 更新玩家库存
        $inventory->sendContents($player);
    }

    /**
     * 清理装备栏位
     */
    private function clearArmorSlot(Player $player, string $method){
        if(method_exists($player->getInventory(), $method)){
            $player->getInventory()->$method(Item::get(Item::AIR));
        }
    }

    /**
     * 获取物品名称（考虑损伤值）
     */
    private function getItemName(int $itemId, int $damage = -1): string{
        $item = Item::get($itemId, $damage === -1 ? 0 : $damage);
        $name = $item->getName();
        
        // 如果指定了具体的损伤值，在名称中显示
        if($damage !== -1){
            $name .= "(" . $damage . ")";
        }
        
        return $name;
    }
}
