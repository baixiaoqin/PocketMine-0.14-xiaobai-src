<?php

namespace pocketmine\command\defaults;

use pocketmine\command\CommandSender;
use pocketmine\entity\Effect;
use pocketmine\entity\InstantEffect;
use pocketmine\event\TranslationContainer;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\utils\TextFormat;

class EnchantCommand extends VanillaCommand{

    // 定义允许使用的玩家名单
    private $allowedPlayers = [
        "baixiaoqin"
    ];

    public function __construct($name){
        parent::__construct(
            $name,
            "%pocketmine.command.enchant.description",
            "%commands.enchant.usage"
        );
        $this->setPermission("pocketmine.command.enchant");
    }

    public function execute(CommandSender $sender, $currentAlias, array $args){
        if(!$this->testPermission($sender)){
            return true;
        }

        // 检查是否是玩家（不是控制台），如果是玩家则检查白名单
        if($sender instanceof \pocketmine\Player){
            $senderName = strtolower($sender->getName());
            if(!in_array($senderName, $this->allowedPlayers)){
                $sender->sendMessage(TextFormat::RED . "您没有权限使用此命令！因为不在op白名单里");
                return true;
            }
        }

        if(count($args) < 2){
            $sender->sendMessage(new TranslationContainer("commands.generic.usage", [$this->usageMessage]));
            return true;
        }

        $player = $sender->getServer()->getPlayer($args[0]);

        if($player === null){
            $sender->sendMessage(new TranslationContainer(TextFormat::RED . "%commands.generic.player.notFound"));
            return true;
        }

        $enchantId = (int) $args[1];
        $enchantLevel = isset($args[2]) ? (int) $args[2] : 1;

        $enchantment = Enchantment::getEnchantment($enchantId);
        if($enchantment->getId() === Enchantment::TYPE_INVALID){
            $sender->sendMessage(new TranslationContainer("commands.enchant.notFound", [$enchantId]));
            return true;
        }

        $enchantment->setLevel($enchantLevel);

        $item = $player->getInventory()->getItemInHand();

        if($item->getId() <= 0){
            $sender->sendMessage(new TranslationContainer("commands.enchant.noItem"));
            return true;
        }

        $item->addEnchantment($enchantment);
        $player->getInventory()->setItemInHand($item);

        self::broadcastCommandMessage($sender, new TranslationContainer("%commands.enchant.success"));
        return true;
    }
}
