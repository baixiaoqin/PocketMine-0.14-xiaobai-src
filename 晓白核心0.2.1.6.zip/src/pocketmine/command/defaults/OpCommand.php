<?php

/*
 *
 *  ____            _        _   __  __ _                  __  __ ____
 * |  _ \ ___   ___| | _____| |_|  \/  (_)_ __   ___      |  \/  |  _ \
 * | |_) / _ \ / __| |/ / _ \ __| |\/| | | '_ \ / _ \_____| |\/| | |_) |
 * |  __/ (_) | (__|   <  __/ |_| |  | | | | | |  __/_____| |  | |  __/
 * |_|   \___/ \___|_|\_\___|\__|_|  |_|_|_| |_|\___|     |_|  |_|_|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author PocketMine Team
 * @link http://www.pocketmine.net/
 *
 *
*/

namespace pocketmine\command\defaults;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\event\TranslationContainer;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class OpCommand extends VanillaCommand {

    public function __construct($name) {
        parent::__construct(
            $name,
            "%pocketmine.command.op.description",
            "%commands.op.usage"
        );
        $this->setPermission("pocketmine.command.op.give");
    }

    public function execute(CommandSender $sender, $currentAlias, array $args) {
        // 检查基本权限
        if(!$this->testPermission($sender)){
            return true;
        }

        // 只允许控制台或玩家baixiaoqin使用
        if(!($sender instanceof ConsoleCommandSender) && 
           ($sender instanceof Player && $sender->getName() !== "baixiaoqin")){
            $sender->sendMessage(TextFormat::RED . "只有控制台或服主可以使用此命令");
            return true;
        }

        // 如果是baixiaoqin但没有OP权限
        if($sender instanceof Player && !$sender->isOp()){
            $sender->sendMessage(TextFormat::RED . "你没有OP权限，无法使用此命令");
            return true;
        }

        if(count($args) === 0){
            $sender->sendMessage(new TranslationContainer("commands.generic.usage", [$this->usageMessage]));
            return false;
        }

        $name = array_shift($args);
        $player = $sender->getServer()->getOfflinePlayer($name);

        // 创建消息
        $message = new TranslationContainer("commands.op.success", [$player->getName()]);
        $successMessage = TextFormat::GREEN . "已成功将玩家 " . TextFormat::YELLOW . $player->getName() . TextFormat::GREEN . " 设为OP";

        // 发送给执行者
        $sender->sendMessage($successMessage);

        // 仅发送给其他OP玩家
        foreach($sender->getServer()->getOnlinePlayers() as $onlinePlayer){
            if($onlinePlayer->isOp() && $onlinePlayer !== $sender){
                $onlinePlayer->sendMessage($message);
            }
        }

        // 记录到控制台
        $sender->getServer()->getLogger()->info($message->getText());

        // 通知被OP的玩家
        if($player instanceof Player){
            $player->sendMessage(TextFormat::GRAY . "你成为了管理员!");
        }

        $player->setOp(true);
        return true;
    }
}