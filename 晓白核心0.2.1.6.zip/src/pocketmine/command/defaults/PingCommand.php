<?php

namespace pocketmine\command\defaults;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\TranslationContainer;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class PingCommand extends VanillaCommand {

    public function __construct($name) {
        parent::__construct(
            $name,
            "%pocketmine.command.ping.description",
            "%commands.ping.usage",
            ["connection", "延迟"]  // 添加中文别名
        );
        // 移除了 setPermission() 这行，这样就不需要特定权限了
    }

    public function execute(CommandSender $sender, $currentAlias, array $args) {
        // 移除了权限检查部分
        if(!$sender instanceof Player) {
            $sender->sendMessage(TextFormat::RED . "该命令只能在游戏中使用");
            return true;
        }

        $ping = $sender->getPing();
        $quality = $this->getNetworkQuality($ping);
        
        $sender->sendMessage("§a当前延迟: §e{$ping}ms §7- {$quality}");
        return true;
    }
    
    private function getNetworkQuality($ping) {
        if($ping < 50) {
            return TextFormat::GREEN . "极佳";       // 绿色
        } elseif($ping < 100) {
            return TextFormat::DARK_GREEN . "良好"; // 深绿色
        } elseif($ping < 200) {
            return TextFormat::YELLOW . "一般";     // 黄色
        } elseif($ping < 300) {
            return TextFormat::GOLD . "较差";       // 金色
        } elseif($ping < 500) {
            return TextFormat::RED . "糟糕";        // 红色
        } else {
            return TextFormat::DARK_RED . "极差";   // 深红色
        }
    }
}