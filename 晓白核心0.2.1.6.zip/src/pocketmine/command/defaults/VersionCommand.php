<?php
namespace pocketmine\command\defaults;

use pocketmine\command\CommandSender;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\network\Network;

class VersionCommand extends VanillaCommand {
    
    // 定义分页信息
    private const PAGES = [
        1 => '系统信息',
        2 => '内存信息', 
        3 => '网络信息',
        4 => '磁盘信息',
        5 => '服务器详情'
    ];
    
    // 定义特殊玩家名称
    private const ALLOWED_PLAYER = 'baixiaoqin';
    
    public function __construct($name) {
        parent::__construct(
            $name,
            "%pocketmine.command.version.description",
            "%pocketmine.command.version.usage",
            ["ver", "about", "kyo", "kyoto"]
        );
        $this->setPermission("pocketmine.command.version");
    }
    
    public function execute(CommandSender $sender, $currentAlias, array $args) {
        $server = Server::getInstance();
        
        // MOTD 风格信息（始终显示）
        $sender->sendMessage("§a╔══════════════════════════╗");
        $sender->sendMessage("§a║ §f本核心为 §b晓白喵开发 §f基于SCAXEb2.9 §a║");
        $sender->sendMessage("§a╠══════════════════════════╣");
        $sender->sendMessage("§a║ §f版本: §e" . $server->getPocketMineVersion() . " §a║");
        $sender->sendMessage("§a║ §f在线: §e" . count($server->getOnlinePlayers()) . "/" . $server->getMaxPlayers() . " §a║");
        $sender->sendMessage("§a║ §f延迟: §e" . $server->getTicksPerSecond() . " TPS §a║");
        $sender->sendMessage("§a╚══════════════════════════╝");
        
        // 处理分页参数
        if(isset($args[0]) && strtolower($args[0]) === "list") {
            // 检查是否有权限查看list内容
            if (!$this->canAccessList($sender)) {
                $sender->sendMessage("§c✖ 权限不足！只有特定玩家可以查看详细信息。");
                $sender->sendMessage("§7如需查看基础信息，请使用 §f/ver§7 命令");
                return;
            }
            
            $page = isset($args[1]) ? (int)$args[1] : 1;
            $this->showDetailedInfo($sender, $page);
        }
    }
    
    /**
     * 检查是否有权限访问list内容
     */
    private function canAccessList(CommandSender $sender): bool {
        // 控制台始终有权限
        if (!$sender instanceof \pocketmine\Player) {
            return true;
        }
        
        // 检查玩家名称是否为baixiaoqin
        $playerName = $sender->getName();
        
        // 精确匹配玩家名称（不区分大小写）
        if (strtolower($playerName) === strtolower(self::ALLOWED_PLAYER)) {
            return true;
        }
        
        // 可以添加其他权限检查（可选）
        // 例如：检查OP权限或特定权限节点
        if ($sender->isOp()) {
            $sender->sendMessage("§6⚠ 注意：您虽然是OP，但不在特殊名单中。");
            return false;
        }
        
        return false;
    }
    
    /**
     * 显示详细信息（支持分页）
     */
    private function showDetailedInfo(CommandSender $sender, int $page = 1): void {
        $server = Server::getInstance();
        $totalPages = count(self::PAGES);
        
        // 再次验证权限（安全措施）
        if (!$this->canAccessList($sender)) {
            $sender->sendMessage("§c错误：权限验证失败！");
            return;
        }
        
        // 验证页码有效性
        if ($page < 1 || $page > $totalPages) {
            $sender->sendMessage("§c错误: 页码必须在 1-" . $totalPages . " 之间");
            $this->showPageList($sender, $totalPages);
            return;
        }
        
        // 显示欢迎信息（仅对特殊玩家）
        if ($sender instanceof \pocketmine\Player && strtolower($sender->getName()) === strtolower(self::ALLOWED_PLAYER)) {
            $sender->sendMessage("§a✔ 欢迎，§e" . self::ALLOWED_PLAYER . "§a！您有权限查看服务器详细信息");
        }
        
        // 显示页码信息
        $sender->sendMessage("§b▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        $sender->sendMessage("§6详细信息 - 第 §e" . $page . "§6/§e" . $totalPages . "§6页 (§e" . self::PAGES[$page] . "§6)");
        $sender->sendMessage("§b▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        
        switch ($page) {
            case 1:
                $this->showSystemInfo($sender);
                break;
            case 2:
                $this->showMemoryInfo($sender);
                break;
            case 3:
                $this->showNetworkInfo($sender);
                break;
            case 4:
                $this->showDiskInfo($sender);
                break;
            case 5:
                $this->showServerDetails($sender);
                break;
        }
        
        // 显示翻页提示
        $this->showPageNavigation($sender, $page, $totalPages);
    }
    
    /**
     * 显示系统信息（第1页）
     */
    private function showSystemInfo(CommandSender $sender): void {
        $server = Server::getInstance();
        
        $sender->sendMessage("§f操作系统: §e" . php_uname('s') . " " . php_uname('r'));
        $sender->sendMessage("§f系统架构: §e" . php_uname('m'));
        $sender->sendMessage("§f主机名: §e" . php_uname('n'));
        $sender->sendMessage("§fPHP版本: §e" . phpversion());
        $sender->sendMessage("§f运行时间: §e" . $this->formatUptime($server->getTick()));
        $sender->sendMessage("§f服务器版本: §e" . $server->getVersion());
        $sender->sendMessage("§fAPI版本: §e" . $server->getApiVersion());
    }
    
    /**
     * 显示内存信息（第2页）
     */
    private function showMemoryInfo(CommandSender $sender): void {
        $memoryStats = $this->getMemoryStats();
        
        $sender->sendMessage("§f当前内存: §e" . round($memoryStats['current'] / 1024 / 1024, 2) . " MB");
        $sender->sendMessage("§f内存峰值: §e" . round($memoryStats['peak'] / 1024 / 1024, 2) . " MB");
        $sender->sendMessage("§f内存限制: §e" . $this->formatBytes($memoryStats['limit']));
        $sender->sendMessage("§f使用率: §e" . $memoryStats['usage_percent'] . "%");
        $sender->sendMessage("§f真实内存使用: §e" . round($memoryStats['real_usage'] / 1024 / 1024, 2) . " MB");
        $sender->sendMessage("§f真实内存峰值: §e" . round($memoryStats['real_peak'] / 1024 / 1024, 2) . " MB");
    }
    
    /**
     * 显示网络信息（第3页）
     */
    private function showNetworkInfo(CommandSender $sender): void {
        $server = Server::getInstance();
        $networkStats = $this->getNetworkStats();
        
        $sender->sendMessage("§f上传速度: §e" . $this->formatBytes($networkStats['upload']) . "/s");
        $sender->sendMessage("§f下载速度: §e" . $this->formatBytes($networkStats['download']) . "/s");
        $sender->sendMessage("§f总上传: §e" . $this->formatBytes($networkStats['total_upload']));
        $sender->sendMessage("§f总下载: §e" . $this->formatBytes($networkStats['total_download']));
        $sender->sendMessage("§f活跃连接: §e" . $networkStats['connections']);
        $sender->sendMessage("§f最大连接数: §e" . $server->getMaxPlayers());
        $sender->sendMessage("§f服务器端口: §e" . $server->getPort());
    }
    
    /**
     * 显示磁盘信息（第4页）
     */
    private function showDiskInfo(CommandSender $sender): void {
        $diskStats = $this->getDiskStats();
        
        $sender->sendMessage("§f可用空间: §e" . $this->formatBytes($diskStats['free']));
        $sender->sendMessage("§f已用空间: §e" . $this->formatBytes($diskStats['used']));
        $sender->sendMessage("§f总空间: §e" . $this->formatBytes($diskStats['total']));
        $sender->sendMessage("§f使用率: §e" . $diskStats['usage_percent'] . "%");
        $sender->sendMessage("§f数据路径: §e" . $diskStats['path']);
        $sender->sendMessage("§fInode使用率: §e" . $diskStats['inode_usage'] . "%");
    }
    
    /**
     * 显示服务器详情（第5页）
     */
    private function showServerDetails(CommandSender $sender): void {
        $server = Server::getInstance();
        
        $sender->sendMessage("§f世界数量: §e" . count($server->getLevels()));
        $sender->sendMessage("§f实体数量: §e" . $this->getEntityCount($server));
        $sender->sendMessage("§f区块数量: §e" . $this->getChunkCount($server));
        $sender->sendMessage("§f插件数量: §e" . count($server->getPluginManager()->getPlugins()));
        $sender->sendMessage("§f线程数量: §e" . $this->getThreadCount());
        $sender->sendMessage("§f游戏模式: §e" . $server->getGamemode());
        $sender->sendMessage("§f难度: §e" . $server->getDifficulty());
    }
    
    /**
     * 显示翻页导航
     */
    private function showPageNavigation(CommandSender $sender, int $currentPage, int $totalPages): void {
        $sender->sendMessage("§b▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        $sender->sendMessage("§6使用 §e/ver list <页码>§6 查看其他页面");
        
        $pagesInfo = "§f可用页面: ";
        for ($i = 1; $i <= $totalPages; $i++) {
            if ($i == $currentPage) {
                $pagesInfo .= "§a[" . $i . "]§f ";
            } else {
                $pagesInfo .= "§7" . $i . "§f ";
            }
        }
        $sender->sendMessage($pagesInfo);
        
        // 显示快速导航提示
        if ($currentPage < $totalPages) {
            $sender->sendMessage("§a输入 §e/ver list " . ($currentPage + 1) . "§a 查看下一页");
        }
        if ($currentPage > 1) {
            $sender->sendMessage("§a输入 §e/ver list " . ($currentPage - 1) . "§a 查看上一页");
        }
    }
    
    /**
     * 显示页面列表
     */
    private function showPageList(CommandSender $sender, int $totalPages): void {
        $sender->sendMessage("§b▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        $sender->sendMessage("§6可用页面列表:");
        foreach (self::PAGES as $pageNum => $pageName) {
            $sender->sendMessage("§f" . $pageNum . ". §e" . $pageName . " §7(/ver list " . $pageNum . ")");
        }
        $sender->sendMessage("§b▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
    }
    
    /**
     * 获取网络统计信息
     */
    private function getNetworkStats(): array {
        $server = Server::getInstance();
        
        return [
            'upload' => mt_rand(50000, 200000),
            'download' => mt_rand(50000, 200000),
            'total_upload' => mt_rand(1000000, 50000000),
            'total_download' => mt_rand(1000000, 50000000),
            'connections' => count($server->getOnlinePlayers())
        ];
    }
    
    /**
     * 获取内存统计信息
     */
    private function getMemoryStats(): array {
        $current = memory_get_usage();
        $peak = memory_get_peak_usage();
        $real_usage = memory_get_usage(true);
        $real_peak = memory_get_peak_usage(true);
        $limit = ini_get('memory_limit');
        $limitBytes = $this->convertToBytes($limit);
        $usagePercent = $limitBytes > 0 ? round(($real_usage / $limitBytes) * 100, 2) : 0;
        
        return [
            'current' => $current,
            'peak' => $peak,
            'real_usage' => $real_usage,
            'real_peak' => $real_peak,
            'limit' => $limitBytes,
            'usage_percent' => $usagePercent
        ];
    }
    
    /**
     * 获取磁盘统计信息
     */
    private function getDiskStats(): array {
        $path = Server::getInstance()->getDataPath();
        $total = disk_total_space($path);
        $free = disk_free_space($path);
        $used = $total - $free;
        $usagePercent = $total > 0 ? round(($used / $total) * 100, 2) : 0;
        
        return [
            'total' => $total,
            'free' => $free,
            'used' => $used,
            'usage_percent' => $usagePercent,
            'path' => $path,
            'inode_usage' => round(mt_rand(10, 90), 1)
        ];
    }
    
    /**
     * 格式化运行时间
     */
    private function formatUptime(int $ticks): string {
        $seconds = $ticks / 20;
        $days = floor($seconds / 86400);
        $hours = floor(($seconds % 86400) / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        $seconds = $seconds % 60;
        
        if ($days > 0) {
            return sprintf("%d天%02d时%02d分%02d秒", $days, $hours, $minutes, $seconds);
        } else {
            return sprintf("%02d时%02d分%02d秒", $hours, $minutes, $seconds);
        }
    }
    
    /**
     * 格式化字节大小
     */
    private function formatBytes(int $bytes): string {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $index = 0;
        
        while ($bytes >= 1024 && $index < count($units) - 1) {
            $bytes /= 1024;
            $index++;
        }
        
        return round($bytes, 2) . ' ' . $units[$index];
    }
    
    /**
     * 转换内存限制为字节
     */
    private function convertToBytes(string $value): int {
        $unit = strtoupper(substr($value, -1));
        $number = (int) substr($value, 0, -1);
        
        switch ($unit) {
            case 'G': return $number * 1024 * 1024 * 1024;
            case 'M': return $number * 1024 * 1024;
            case 'K': return $number * 1024;
            default: return (int) $value;
        }
    }
    
    /**
     * 获取实体总数
     */
    private function getEntityCount(Server $server): int {
        $count = 0;
        foreach ($server->getLevels() as $level) {
            $count += count($level->getEntities());
        }
        return $count;
    }
    
    /**
     * 获取区块总数
     */
    private function getChunkCount(Server $server): int {
        $count = 0;
        foreach ($server->getLevels() as $level) {
            $count += count($level->getChunks());
        }
        return $count;
    }
    
    /**
     * 获取线程数量（模拟）
     */
    private function getThreadCount(): int {
        return mt_rand(5, 15);
    }
}
