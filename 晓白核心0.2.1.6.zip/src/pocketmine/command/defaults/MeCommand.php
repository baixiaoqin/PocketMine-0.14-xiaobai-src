<?php

/*
 *
 *  ____            _        _   __  __ _                  __  __ ____
 * |  _ \ ___   ___| | _____| |_|  \/  (_)_ __   ___      |  \/  |  _ \
 * | |_) / _ \ / __| |/ / _ \ __| |\/| | | '_ \ / _ \_____| |\/| | |_) |
 * |  __/ (_) | (__|   <  __/ |_| |  | | | | | |  __/_____| |  | |  __/
 * |_|   \___/ \___|_|\_\___|\__|_|  |_|_|_| |_|\___|     |_|  |_|_|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author PocketMine Team
 * @link http://www.pocketmine.net/
 *
 *
*/

namespace pocketmine\command\defaults;

use pocketmine\command\CommandSender;
use pocketmine\event\TranslationContainer;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class MeCommand extends VanillaCommand{

    /** @var array 存储玩家最后发言时间 */
    private static $lastMessageTime = [];
    /** @var int 防刷屏时间间隔（秒） */
    private const ANTISPAM_INTERVAL = 3;
    /** @var int 最大允许的消息长度 */
    private const MAX_MESSAGE_LENGTH = 256;

	public function __construct($name){
		parent::__construct(
			$name,
			"%pocketmine.command.me.description",
			"%commands.me.usage"
		);
		$this->setPermission("pocketmine.command.me");
	}

	public function execute(CommandSender $sender, $currentAlias, array $args){
		if(!$this->testPermission($sender)){
			return true;
		}

		if(count($args) === 0){
			$sender->sendMessage(new TranslationContainer("commands.generic.usage", [$this->usageMessage]));
			return false;
		}

        $message = implode(" ", $args);
        
        // 防刷屏检查
        if(!$this->checkAntiSpam($sender, $message)){
            return false;
        }

		$sender->getServer()->broadcastMessage(new TranslationContainer("chat.type.emote", [$sender instanceof Player ? $sender->getDisplayName() : $sender->getName(), TextFormat::WHITE . $message]));

		return true;
	}

    /**
     * 防刷屏检查
     * @param CommandSender $sender 命令发送者
     * @param string $message 消息内容
     * @return bool 是否通过检查
     */
    private function checkAntiSpam(CommandSender $sender, string $message): bool {
        // 控制台和拥有高级权限的用户不受限制
        if(!$sender instanceof Player || $sender->hasPermission("pocketmine.command.me.bypass")) {
            return true;
        }

        $senderName = $sender->getName();
        $currentTime = time();

        // 检查消息长度
        if(mb_strlen($message) > self::MAX_MESSAGE_LENGTH) {
            $sender->sendMessage(TextFormat::RED . "消息过长，最大允许 " . self::MAX_MESSAGE_LENGTH . " 个字符");
            return false;
        }

        // 检查发言频率
        if(isset(self::$lastMessageTime[$senderName])) {
            $timeDiff = $currentTime - self::$lastMessageTime[$senderName];
            
            if($timeDiff < self::ANTISPAM_INTERVAL) {
                $remainingTime = self::ANTISPAM_INTERVAL - $timeDiff;
                $sender->sendMessage(TextFormat::RED . "发言过于频繁，请等待 {$remainingTime} 秒后再试");
                return false;
            }
        }

        // 更新最后发言时间
        self::$lastMessageTime[$senderName] = $currentTime;

        return true;
    }
}
