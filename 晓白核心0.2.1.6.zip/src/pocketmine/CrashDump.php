<?php

/*
 * 晓白喵 Minecraft 服务端
 * 核心开发: 晓周
 * 技术支持: https://xiaozhou.dev
 * 
 * 本程序是自由软件，你可以根据GNU LGPL许可证条款重新发布和修改
 */

namespace pocketmine;

use pocketmine\network\protocol\Info;
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\PluginLoadOrder;
use pocketmine\utils\Utils;
use pocketmine\utils\VersionString;
use raklib\RakLib;

/**
 * 崩溃报告生成器
 * 当服务器发生错误时，自动生成详细的崩溃报告
 */
class CrashDump {
    
    /** @var Server 服务器实例 */
    private $server;
    
    /** @var resource 文件指针 */
    private $fileHandle;
    
    /** @var int 崩溃时间戳 */
    private $crashTime;
    
    /** @var array 崩溃数据集合 */
    private $crashData = [];
    
    /** @var string|null 编码后的数据 */
    private $encodedData = null;
    
    /** @var string 崩溃报告文件路径 */
    private $reportPath;

    /**
     * 构造函数 - 初始化崩溃报告
     * @param Server $server 服务器实例
     * @throws \RuntimeException 当无法创建崩溃报告文件时抛出
     */
    public function __construct(Server $server) {
        $this->server = $server;
        $this->crashTime = time();
        
        // 生成崩溃报告文件名（包含时间戳）
        $this->reportPath = $this->server->getCrashPath() . "CrashReport_" . date("Y-m-d_H-i-s", $this->crashTime) . ".log";
        
        // 尝试创建崩溃报告文件
        $this->fileHandle = @fopen($this->reportPath, "wb");
        if (!is_resource($this->fileHandle)) {
            throw new \RuntimeException("无法创建崩溃报告文件: " . $this->reportPath);
        }
        
        // 开始收集崩溃信息
        $this->initializeCrashReport();
    }

    /**
     * 初始化崩溃报告基本结构
     */
    private function initializeCrashReport() {
        $this->crashData["time"] = $this->crashTime;
        
        // 写入报告头部
        $this->writeLine("=== 晓白喵服务器崩溃报告 ===");
        $this->writeLine("崩溃时间: " . date("Y年m月d日 H:i:s", $this->crashTime));
        $this->writeLine();
        
        // 收集各类信息
        $this->collectBasicCrashInfo();
        $this->collectSystemInfo();
        $this->collectPluginInfo();
        $this->collectAdditionalData();
    }

    /**
     * 获取崩溃报告文件路径
     * @return string 文件路径
     */
    public function getPath() {
        return $this->reportPath;
    }

    /**
     * 获取编码后的崩溃数据（用于自动上报）
     * @return string|null 编码数据
     */
    public function getEncodedData() {
        return $this->encodedData;
    }

    /**
     * 获取原始崩溃数据
     * @return array 崩溃数据数组
     */
    public function getData() {
        return $this->crashData;
    }

    /**
     * 收集插件信息
     */
    private function collectPluginInfo() {
        if (!class_exists("pocketmine\\plugin\\PluginManager", false)) {
            return;
        }

        $this->writeLine();
        $this->writeLine("=== 已加载的插件 ===");
        
        $this->crashData["plugins"] = [];
        $pluginManager = $this->server->getPluginManager();

        foreach ($pluginManager->getPlugins() as $plugin) {
            $description = $plugin->getDescription();
            
            $pluginInfo = [
                "name" => $description->getName(),
                "version" => $description->getVersion(),
                "authors" => $description->getAuthors(),
                "api" => $description->getCompatibleApis(),
                "enabled" => $plugin->isEnabled(),
                "dependencies" => $description->getDepend(),
                "softDependencies" => $description->getSoftDepend(),
                "mainClass" => $description->getMain(),
                "loadOrder" => $description->getOrder() === PluginLoadOrder::POSTWORLD ? "世界加载后" : "启动时",
                "website" => $description->getWebsite()
            ];
            
            $this->crashData["plugins"][$description->getName()] = $pluginInfo;
            
            // 在报告中显示插件信息
            $status = $plugin->isEnabled() ? "已启用" : "已禁用";
            $this->writeLine(sprintf(
                "%s %s - 作者: %s - 状态: %s",
                $description->getName(),
                $description->getVersion(),
                implode(", ", $description->getAuthors()),
                $status
            ));
        }
    }

    /**
     * 收集额外的系统数据
     */
    private function collectAdditionalData() {
        global $arguments;

        // 根据配置决定是否收集敏感数据
        $sendSettings = $this->server->getProperty("auto-report.send-settings", true);
        
        if ($sendSettings !== false) {
            // 收集启动参数
            $this->crashData["startupArguments"] = (array) $arguments;
            
            // 收集服务器配置（隐藏敏感信息）
            $this->crashData["serverConfig"] = $this->getSanitizedServerProperties();
            $this->crashData["pocketmineConfig"] = @file_get_contents($this->server->getDataPath() . "pocketmine.yml");
        } else {
            $this->crashData["startupArguments"] = [];
            $this->crashData["serverConfig"] = "配置收集已禁用";
            $this->crashData["pocketmineConfig"] = "配置收集已禁用";
        }

        // 收集PHP扩展信息
        $this->crashData["phpExtensions"] = [];
        foreach (get_loaded_extensions() as $extension) {
            $this->crashData["phpExtensions"][$extension] = phpversion($extension);
        }

        // 根据配置决定是否收集PHP信息
        if ($this->server->getProperty("auto-report.send-phpinfo", true) !== false) {
            ob_start();
            phpinfo();
            $this->crashData["phpInfo"] = ob_get_contents();
            ob_end_clean();
        }
    }

    /**
     * 获取处理后的服务器配置（隐藏密码等敏感信息）
     * @return string 处理后的配置内容
     */
    private function getSanitizedServerProperties() {
        $propertiesContent = @file_get_contents($this->server->getDataPath() . "server.properties");
        if ($propertiesContent === false) {
            return "无法读取服务器配置文件";
        }
        
        // 隐藏敏感信息
        $propertiesContent = preg_replace(
            '#^rcon\\.password=(.*)$#m', 
            'rcon.password=******', 
            $propertiesContent
        );
        
        return $propertiesContent;
    }

    /**
     * 收集基本崩溃信息
     */
    private function collectBasicCrashInfo() {
        global $lastExceptionError, $lastError;

        // 获取最后的错误信息
        $error = isset($lastExceptionError) ? $lastExceptionError : (array) error_get_last();
        $error["trace"] = @getTrace(3);

        // 错误类型映射
        $errorTypeMap = [
            E_ERROR => "致命错误",
            E_WARNING => "警告",
            E_PARSE => "解析错误",
            E_NOTICE => "通知",
            E_CORE_ERROR => "核心错误",
            E_CORE_WARNING => "核心警告",
            E_COMPILE_ERROR => "编译错误",
            E_COMPILE_WARNING => "编译警告",
            E_USER_ERROR => "用户错误",
            E_USER_WARNING => "用户警告",
            E_USER_NOTICE => "用户通知",
            E_STRICT => "严格标准",
            E_RECOVERABLE_ERROR => "可恢复错误",
            E_DEPRECATED => "已弃用",
            E_USER_DEPRECATED => "用户已弃用",
        ];

        // 处理错误信息
        $error["fullFile"] = $error["file"];
        $error["file"] = cleanPath($error["file"]);
        $error["type"] = $errorTypeMap[$error["type"]] ?? "未知错误类型";
        
        // 简化错误消息（移除换行）
        if (($newlinePos = strpos($error["message"], "\n")) !== false) {
            $error["message"] = substr($error["message"], 0, $newlinePos);
        }

        // 保存最后错误信息
        if (isset($lastError)) {
            $this->crashData["lastError"] = $lastError;
        }

        // 保存错误数据
        $this->crashData["error"] = $error;
        
        // 在报告中显示错误摘要
        $this->writeLine("=== 错误摘要 ===");
        $this->writeLine("错误信息: " . $error["message"]);
        $this->writeLine("文件: " . $error["file"]);
        $this->writeLine("行号: " . $error["line"]);
        $this->writeLine("错误类型: " . $error["type"]);

        // 分析错误原因（是否是插件引起）
        $this->analyzeErrorCause($error);
        
        // 显示错误上下文代码
        $this->displayErrorContext($error);
        
        // 显示调用栈
        $this->displayStackTrace($error);
    }

    /**
     * 分析错误原因
     * @param array $error 错误信息
     */
    private function analyzeErrorCause($error) {
        $isPluginError = (
            strpos($error["file"], "src/pocketmine/") === false && 
            strpos($error["file"], "src/raklib/") === false && 
            file_exists($error["fullFile"])
        );

        if ($isPluginError) {
            $this->writeLine();
            $this->writeLine("⚠️  此次崩溃可能由插件引起");
            $this->crashData["causedByPlugin"] = true;

            // 尝试定位具体插件
            $responsiblePlugin = $this->findResponsiblePlugin($error);
            if ($responsiblePlugin !== null) {
                $this->crashData["responsiblePlugin"] = $responsiblePlugin->getName();
                $this->writeLine("可能的问题插件: " . $responsiblePlugin->getDescription()->getFullName());
            }
        } else {
            $this->crashData["causedByPlugin"] = false;
            $this->writeLine();
            $this->writeLine("ℹ️  此次崩溃由核心代码引起");
        }
    }

    /**
     * 查找导致错误的插件
     * @param array $error 错误信息
     * @return PluginBase|null 可能的问题插件
     */
    private function findResponsiblePlugin($error) {
        $reflection = new \ReflectionClass(PluginBase::class);
        $fileProperty = $reflection->getProperty("file");
        $fileProperty->setAccessible(true);

        foreach ($this->server->getPluginManager()->getPlugins() as $plugin) {
            $pluginFilePath = \pocketmine\cleanPath($fileProperty->getValue($plugin));
            if (strpos($error["file"], $pluginFilePath) === 0) {
                return $plugin;
            }
        }

        return null;
    }

    /**
     * 显示错误上下文代码
     * @param array $error 错误信息
     */
    private function displayErrorContext($error) {
        $this->writeLine();
        $this->writeLine("=== 错误上下文代码 ===");
        
        $this->crashData["codeContext"] = [];

        if ($this->server->getProperty("auto-report.send-code", true) !== false) {
            $fileLines = @file($error["fullFile"], FILE_IGNORE_NEW_LINES);
            if ($fileLines === false) {
                $this->writeLine("无法读取源文件");
                return;
            }

            $startLine = max(0, $error["line"] - 5);
            $endLine = min(count($fileLines), $error["line"] + 5);

            for ($lineNumber = $startLine; $lineNumber < $endLine; $lineNumber++) {
                $lineContent = @$fileLines[$lineNumber];
                $lineIndicator = ($lineNumber + 1 == $error["line"]) ? ">>> " : "    ";
                $this->writeLine($lineIndicator . "[" . ($lineNumber + 1) . "] " . $lineContent);
                $this->crashData["codeContext"][$lineNumber + 1] = $lineContent;
            }
        }
    }

    /**
     * 显示调用栈跟踪
     * @param array $error 错误信息
     */
    private function displayStackTrace($error) {
        $this->writeLine();
        $this->writeLine("=== 调用栈跟踪 ===");
        
        $this->crashData["stackTrace"] = $error["trace"];
        
        foreach ($error["trace"] as $traceEntry) {
            $this->writeLine($traceEntry);
        }
    }

    /**
     * 收集系统信息
     */
    private function collectSystemInfo() {
        $version = new VersionString();
        
        $this->crashData["systemInfo"] = [
            "serverVersion" => $version->get(false),
            "buildNumber" => $version->getBuild(),
            "protocolVersion" => Info::CURRENT_PROTOCOL,
            "apiVersion" => \pocketmine\API_VERSION,
            "gitCommit" => \pocketmine\GIT_COMMIT,
            "rakLibVersion" => RakLib::VERSION,
            "systemInfo" => php_uname("a"),
            "phpVersion" => phpversion(),
            "zendVersion" => zend_version(),
            "phpOS" => PHP_OS,
            "operatingSystem" => Utils::getOS()
        ];

        $this->writeLine("=== 系统信息 ===");
        $this->writeLine("服务端版本: " . $version->get(false) . " (构建 #" . $version->getBuild() . ")");
        $this->writeLine("协议版本: " . Info::CURRENT_PROTOCOL);
        $this->writeLine("API 版本: " . \pocketmine\API_VERSION);
        $this->writeLine("操作系统: " . Utils::getOS() . " (" . PHP_OS . ")");
        $this->writeLine("PHP 版本: " . phpversion());
        $this->writeLine("系统信息: " . php_uname("a"));
    }

    /**
     * 写入一行到崩溃报告
     * @param string $line 要写入的内容
     */
    public function writeLine($line = "") {
        fwrite($this->fileHandle, $line . PHP_EOL);
    }

    /**
     * 写入内容到崩溃报告（不换行）
     * @param string $content 要写入的内容
     */
    public function write($content) {
        fwrite($this->fileHandle, $content);
    }

    /**
     * 析构函数 - 确保文件被正确关闭
     */
    public function __destruct() {
        if (is_resource($this->fileHandle)) {
            fclose($this->fileHandle);
        }
    }
}
